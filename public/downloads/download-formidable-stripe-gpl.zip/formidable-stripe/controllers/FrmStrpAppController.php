<?php

class FrmStrpAppController {

	/**
	 * Flag to delete the previous pay entry.
	 *
	 * @since 2.08
	 *
	 * @var bool
	 */
	private static $delete_pay_entry = false;

	/**
	 * @return void
	 */
	public static function load_lang() {
		load_plugin_textdomain( 'formidable-stripe', false, FrmStrpAppHelper::plugin_folder() . '/languages/' );
	}

	/**
	 * Include the updater and show the Stripe connect message.
	 *
	 * @return void
	 */
	public static function include_updater() {
		if ( class_exists( 'FrmAddon' ) ) {
			FrmStrpUpdate::load_hooks();

			if ( self::should_show_stripe_connect_message() ) {
				self::maybe_add_stripe_connect_inbox_message();
			}
		}
		self::install();
	}

	/**
	 * Install required tables.
	 *
	 * @param mixed $old_db_version
	 * @return void
	 */
	public static function install( $old_db_version = false ) {
		FrmTransAppController::install( $old_db_version );
	}

	/**
	 * Add a Stripe gateway for the payment action.
	 *
	 * @param array $gateways
	 * @return array
	 */
	public static function add_gateway( $gateways ) {
		$gateways['stripe'] = array(
			'label'      => 'Stripe',
			'user_label' => __( 'Payment', 'formidable-stripe' ),
			'class'      => 'Strp',
			'recurring'  => true,
			'include'    => array(
				'billing_first_name',
				'billing_last_name',
				'credit_card',
				'billing_address',
			),
		);
		return $gateways;
	}

	/**
	 * Add REST API routing for deleting credit cards.
	 */
	public static function add_api_routes() {
		register_rest_route(
			'frm-strp/v1',
			'/card/(?P<id>[a-z0-9 _]+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( 'FrmStrpPaymentsController', 'delete_card' ),
				'permission_callback' => 'is_user_logged_in',
			)
		);
	}

	/**
	 * Check if Stripe connect has been configured for live payments.
	 *
	 * @return bool
	 */
	private static function should_show_stripe_connect_message() {
		$is_setup = FrmStrpConnectHelper::stripe_connect_is_setup( 'live' );
		return ! $is_setup;
	}

	/**
	 * @return void
	 */
	private static function maybe_add_stripe_connect_inbox_message() {
		$url = self::get_stripe_connect_settings_url();
		self::maybe_add_inbox_message(
			array(
				'key'     => 'use_strp_connect',
				'force'   => true,
				'message' => self::get_stripe_connect_message( $url ),
				'subject' => 'Your Stripe keys may not be secure!',
				'icon'    => 'frm_report_problem_icon',
				'cta'     => '<a class="button-secondary frm-button-secondary" href="' . esc_url_raw( $url ) . '">Connect Stripe Now</a>',
			)
		);
	}

	/**
	 * Get a message to show people using API keys.
	 *
	 * @param string $url
	 * @return string
	 */
	private static function get_stripe_connect_message( $url ) {
		return 'Your current Stripe payment connection is out of date and may become insecure. Please connect your Stripe account in the <a href="' . esc_url_raw( $url ) . '">Stripe settings</a>.';
	}

	/**
	 * Get a URL to the Stripe section of the global settings page.
	 *
	 * @return string
	 */
	private static function get_stripe_connect_settings_url() {
		return admin_url( 'admin.php?page=formidable-settings&t=stripe_settings' );
	}

	/**
	 * Add a message to the Formidable Inbox, if it exists.
	 *
	 * @param string $message
	 * @return void
	 */
	private static function maybe_add_inbox_message( $message ) {
		if ( class_exists( 'FrmInbox' ) ) {
			$inbox = new FrmInbox();
			$inbox->add_message( $message );
		}
	}

	/**
	 * Maybe add payment error to the form errors data.
	 *
	 * @since 2.06
	 *
	 * @param array $errors Errors data. Is empty array if no errors found.
	 * @param array $params Form params. See {@FrmForm::get_params()}.
	 * @return array
	 */
	public static function maybe_add_payment_error( $errors, $params ) {
		if ( intval( $params['posted_form_id'] ) !== intval( $params['form_id'] ) ) {
			// Form is not submitted.
			return $errors;
		}

		if ( FrmStrpConnectHelper::$latest_error_from_stripe_connect ) {
			$error_message = FrmStrpConnectHelper::$latest_error_from_stripe_connect;
		} else {
			global $frm_vars;
			$error_message = ! empty( $frm_vars['frm_trans']['error'] ) ? $frm_vars['frm_trans']['error'] : '';
		}

		if ( ! $error_message ) {
			return $errors;
		}

		$cc_field_id = self::get_credit_card_field_id_from_paged_form( $params['form_id'] );
		if ( false === $cc_field_id ) {
			return $errors;
		}

		if ( ! isset( $errors[ 'field' . $cc_field_id ] ) ) {
			// Do not update error message if that field has error already.
			$errors[ 'field' . $cc_field_id ] = $error_message;
			self::setup_form_after_payment_error( (int) $params['form_id'], (int) $params['id'], $errors );
		}

		return $errors;
	}

	/**
	 * Reset a form after a payment fails.
	 *
	 * @since 2.07
	 *
	 * @param int                  $form_id
	 * @param int                  $entry_id
	 * @param array<string,string> $errors
	 * @return void
	 */
	private static function setup_form_after_payment_error( $form_id, $entry_id, $errors ) {
		$form       = FrmForm::getOne( $form_id );
		$save_draft = ! empty( $form->options['save_draft'] );

		global $frm_vars;
		$frm_vars['created_entries'][ $form_id ]['errors'] = $errors;

		$_POST[ 'frm_page_order_' . $form_id ] = true; // Set to true to get FrmProFieldsHelper::get_page_with_error() run

		if ( ! $save_draft ) {
			// If draft saving is not on, delete the entry.
			self::$delete_pay_entry = true;
			return;
		}

		// If draft saving is on, load the draft entry.
		$frm_vars['created_entries'][ $form_id ]['entry_id'] = $entry_id;
		add_action(
			'frm_filter_final_form',
			/**
			 * Set the entry back to draft status after error.
			 *
			 * @param string $html
			 * @param int    $entry_id
			 * @return string
			 */
			function( $html ) use ( $entry_id ) {
				global $wpdb;
				$wpdb->update( $wpdb->prefix . 'frm_items', array( 'is_draft' => 1 ), array( 'id' => $entry_id ) );
				return $html;
			}
		);

	}

	/**
	 * Gets Credit card field ID from a paged form.
	 *
	 * @since 2.06
	 *
	 * @param int $form_id Form ID.
	 * @return int|false Return `false` if form is not paged and there is no Credit card field.
	 */
	private static function get_credit_card_field_id_from_paged_form( $form_id ) {
		$fields      = FrmField::get_all_for_form( $form_id ); // This result is cached and used when showing fields.
		$cc_field_id = false;
		$has_break   = false;

		foreach ( $fields as $field ) {
			if ( 'credit_card' === $field->type ) {
				$cc_field_id = $field->id;
			} elseif ( 'break' === $field->type ) {
				$has_break = true;
			}

			unset( $field );
		}

		if ( ! $has_break ) {
			return false;
		}

		return $cc_field_id;
	}

	/**
	 * Maybe delete the previous pay entry when error occurs.
	 *
	 * @since 2.08
	 *
	 * @param array  $values Entry edit values.
	 * @param object $field  Field object.
	 * @return array
	 */
	public static function maybe_delete_pay_entry( $values, $field ) {
		if ( self::$delete_pay_entry ) {
			self::$delete_pay_entry = false;
			return FrmTransActionsController::fill_entry_from_previous( $values, $field );
		}
		return $values;
	}

	/**
	 * Remove Stripe database items after uninstall.
	 *
	 * @since 2.07
	 *
	 * @return void
	 */
	public static function uninstall() {
		if ( ! current_user_can( 'administrator' ) ) {
			$frm_settings = FrmAppHelper::get_settings();
			wp_die( esc_html( $frm_settings->admin_permission ) );
		}

		$options_to_delete = array(
			FrmStrpEventsController::$events_to_skip_option_name,
			'frm_strp_options',
		);

		$modes            = array( 'test', 'live' );
		$option_name_keys = array( 'account_id', 'client_password', 'server_password', 'details_submitted' );
		foreach ( $modes as $mode ) {
			foreach ( $option_name_keys as $key ) {
				$options_to_delete[] = 'frm_strp_connect_' . $key . '_' . $mode;
			}
		}

		foreach ( $options_to_delete as $option_name ) {
			delete_option( $option_name );
		}
	}
}
