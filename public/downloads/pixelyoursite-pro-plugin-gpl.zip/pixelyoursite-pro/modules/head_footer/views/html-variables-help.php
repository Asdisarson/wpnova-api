<?php

?>
<p>You can use the following variables:</p>
<ul>
    <li><code>[id]</code> - content ID</li>
    <li><code>[title]</code> - content title</li>
    <li><code>[categories]</code> - content categories</li>
    <li><code>[email]</code> - user's email</li>
    <li><code>[hashed_email]</code> - hashed user's email</li>
    <li><code>[first_name]</code> - user's first name</li>
    <li><code>[last_name]</code> - user's last name</li>
</ul>

<p>For the WooCommerce or Easy Digital Downloads Thank You Pages only:</p>
<ul>
    <li><code>[order_number]</code> - order number</li>
    <li><code>[order_subtotal]</code> - order subtotal</li>
    <li><code>[order_total]</code> - order total</li>
    <li><code>[currency]</code> - currency</li>
</ul>