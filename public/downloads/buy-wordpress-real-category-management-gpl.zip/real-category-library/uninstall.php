<?php
/**
 * This file is automatically requested when the uninstalls the plugin.
 *
 * @see https://developer.wordpress.org/plugins/the-basics/uninstall-methods/
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit();
}

// Your uninstall action...
