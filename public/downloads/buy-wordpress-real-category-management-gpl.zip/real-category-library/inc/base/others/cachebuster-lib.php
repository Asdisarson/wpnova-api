<?php
// Cachebusters generated on 2023-08-02 10:22:59
return [
	'@ant-design/icons' => '4.8.0',
	'antd' => '4.24.8',
	'core-js' => '3.29.1',
	'enzyme' => '3.11.0',
	'jquery' => '3.6.4',
	'lodash' => '4.17.21',
	'mobx' => '4.15.7',
	'mobx-react' => '6.3.1',
	'react' => '16.14.0',
	'react-aiot' => '1.8.0',
	'react-dom' => '16.14.0'
];
