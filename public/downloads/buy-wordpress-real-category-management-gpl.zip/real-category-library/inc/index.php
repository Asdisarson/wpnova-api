<?php

namespace DevOwl\RealCategoryLibrary\Vendor;

// Silence is golden.
