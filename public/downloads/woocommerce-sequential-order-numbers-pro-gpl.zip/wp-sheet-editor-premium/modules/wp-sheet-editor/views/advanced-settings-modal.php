<?php defined( 'ABSPATH' ) || exit; ?>

<div class="remodal modal-advanced-settings" data-remodal-id="modal-advanced-settings" data-remodal-options="closeOnOutsideClick: false">

	<div class="modal-content">
		<?php WPSE_Options_Page_Obj()->render_settings_form($provider); ?>
	</div>
</div>