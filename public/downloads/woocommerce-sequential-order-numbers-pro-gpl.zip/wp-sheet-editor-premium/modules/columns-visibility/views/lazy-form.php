<?php defined( 'ABSPATH' ) || exit; ?>

<div data-remodal-id="modal-columns-visibility" data-remodal-options="closeOnOutsideClick: false" class="remodal remodal<?php echo esc_attr( $random_id ); ?> modal-columns-visibility lazy-modal-columns-visibility">

<div class="modal-content">
    
	</div>
</div>
