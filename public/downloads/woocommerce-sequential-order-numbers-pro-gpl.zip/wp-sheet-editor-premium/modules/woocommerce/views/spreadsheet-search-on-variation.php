<?php defined( 'ABSPATH' ) || exit; ?>
<li>
	<label><input type="checkbox" name="search_variations" value="yes" /> <?php _e('Search on variations?', 'vg_sheet_editor' ); ?> <a href="#" data-wpse-tooltip="right" aria-label="<?php esc_attr_e('All the parameters will be used to search on variations instead of the main products.', 'vg_sheet_editor' ); ?>">( ? )</a></label>
</li>