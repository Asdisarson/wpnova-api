<div class="wcpf-filter-notes wcpf-filter-notes-<?php echo esc_attr( $project_id ); ?>">
	<div class="wcpf-note-list"></div>
</div>
