<?php

namespace WooCommerce_Product_Filter_Plugin;

use WC_Widget;
use WooCommerce_Product_Filter_Plugin\Structure\Component_Builder;
use WooCommerce_Product_Filter_Plugin\Widgets\Filter_Notes_Widget;
use WooCommerce_Product_Filter_Plugin\Widgets\Filter_Widget;

/**
 * Class Plugin
 *
 * @package WooCommerce_Product_Filter_Plugin
 */
class Plugin {
	protected $component_register;

	protected $object_register;

	protected $entity_register;

	/**
	 * Plugin constructor.
	 */
	public function __construct() {}

	/**
	 * Initialize the plugin.
	 *
	 * @return void
	 */
	public function init() {
		$this->setup_registers();
		$this->attach_hooks();
		$this->load_components();
	}

	/**
	 * Set up the register objects.
	 *
	 * @return void
	 */
	protected function setup_registers() {
		$this->component_register = new Register();
		$this->object_register = new Register();
		$this->entity_register = new Entity_Register();
	}

	/**
	 * Attach relevant hooks.
	 */
	protected function attach_hooks() {
		add_action( 'plugins_loaded', array( $this, 'load_text_domain' ) );

		add_action( 'init', array( $this, 'on_wp_init' ) );

		add_action( 'widgets_init', array( $this, 'on_widgets_init' ) );

		add_action( 'plugins_loaded', array( $this, 'plugin_support' ) );

		add_action( 'after_setup_theme', array( $this, 'theme_support' ) );

		add_filter( 'plugin_action_links_' . plugin_basename( WC_PRODUCT_FILTER_PLUGIN_FILE ), [ $this, 'plugin_action_links' ] );

		add_action(
			'admin_notices',
			function() {
				$this->maybe_show_admin_notice();
			}
		);
	}

	/**
	 * Set up theme support components.
	 *
	 * @return void
	 */
	public function theme_support() {
		if (
			! defined( 'THE7_VERSION' ) ||
			! defined( 'PRESSCORE_THEME_NAME' ) ||
			PRESSCORE_THEME_NAME !== 'the7'
		) {
			return;
		}

		$component         = Theme_Support\The7::class;
		$component_builder = $this->get_object_register()->get( 'Component_Builder' );
		$component_builder->build( $component );
	}

	/**
	 * Set up component support depending on what other plugins are active.
	 *
	 * @return void
	 */
	public function plugin_support() {
		$components = array();

		if ( class_exists( 'Polylang' ) ) {
			$components[] = Plugin_Support\Polylang::class;
		}

		if ( defined( 'WPML_PLUGIN_PATH' ) ) {
			$components[] = Plugin_Support\Wpml::class;
		}

		if ( class_exists( 'Elementor\\Plugin' ) ) {
			$components[] = Plugin_Support\Elementor::class;
		}

		if ( class_exists( 'Jetpack' ) ) {
			$components[] = Plugin_Support\Jetpack::class;
		}

		if ( class_exists( 'BeRocket_LMP' ) ) {
			$components[] = Plugin_Support\BeRocket_Load_More_Products::class;
		}

		if ( defined( 'GUAVEN_WOO_SEARCH_PLUGIN_PATH' ) ) {
			$components[] = Plugin_Support\Guaven_Woo_Search::class;
		}

		if ( defined( 'YITH_INFS' ) ) {
			$components[] = Plugin_Support\Yith_Infinite_Scrolling::class;
		}

		/** @var Component_Builder $component_builder */
		$component_builder = $this->get_object_register()->get( 'Component_Builder' );

		foreach ( $components as $component ) {
			$component_builder->build( $component );
		}
	}

	/**
	 * Load the plugin components.
	 *
	 * @return void
	 */
	protected function load_components() {
		$component_builder = new Structure\Component_Builder();
		$component_builder->set_plugin( $this );

		$this->get_object_register()->save( 'Component_Builder', $component_builder );

		foreach ( $this->get_components() as $component ) {
			$component_builder->build( $component );
		}
	}

	public function get_component_register() {
		return $this->component_register;
	}

	public function get_object_register() {
		return $this->object_register;
	}

	public function get_entity_register() {
		return $this->entity_register;
	}

	public function load_text_domain() {
		load_plugin_textdomain( WC_PRODUCT_FILTER_INDEX, false, dirname( plugin_basename( WC_PRODUCT_FILTER_PLUGIN_FILE ) ) . '/languages/' );
	}

	public function get_plugin_url() {
		return plugin_dir_url( WC_PRODUCT_FILTER_PLUGIN_FILE );
	}

	public function get_plugin_path() {
		return plugin_dir_path( WC_PRODUCT_FILTER_PLUGIN_FILE );
	}

	public function is_debug_mode() {
		return WP_DEBUG || isset( $_GET[ WC_PRODUCT_FILTER_INDEX . '_debug_mode' ] );
	}

	public function get_resource_url() {
		return $this->get_plugin_url() . 'assets/';
	}

	public function get_assets_url() {
		return $this->get_plugin_url() . 'assets/';
	}

	public function get_assets_path() {
		return $this->get_plugin_path() . 'assets/';
	}

	public function get_plugin_uri() {
		return 'woocommerce-product-filter';
	}

	/**
	 * Register widgets for this plugin with WordPress.
	 *
	 * @return void
	 */
	public function on_widgets_init() {
		if ( class_exists( WC_Widget::class ) ) {
			register_widget( Filter_Widget::class );
			register_widget( Filter_Notes_Widget::class );
		}
	}

	public function on_wp_init() {
		do_action( 'wcpf_register_entities', $this->get_entity_register() );
	}


	/**
	 * Show action links on the plugin screen.
	 *
	 * @param mixed $links Plugin Action links.
	 * @since x.x.x
	 *
	 * @return array
	 */
	public function plugin_action_links( $links ): array {
		$settings_url = add_query_arg(
			[
				'page'    => 'wc-settings',
				'tab'     => 'products',
				'section' => 'woocommerce-product-filters',
			],
			admin_url( 'admin.php' )
		);
		$action_links = [
			'settings' => '<a href="' . $settings_url . '">' . esc_html__( 'Settings', 'woocommerce-product-filters' ) . '</a>',
		];

		return array_merge( $action_links, $links );
	}

	/**
	 * Get the components.
	 *
	 * @return array
	 */
	protected function get_components() {
		$components = array(
			Template_Loader::class,
			Query_Helper::class,
			Activator::class,
			Filters::class,
			Filter\Component_Builder::class,
			Project\Filter_Component_Storage::class,
			Project\Post_Type::class,
			Project\Registration::class,
			Front\Assets::class,
			Front\Product_Loop::class,
			Front\Pagination::class,
			Shortcode::class,
			Field\Common::class,
			Layout\Common::class,
			Woocommerce::class,
		);

		if ( is_admin() ) {
			$components = array_merge(
				array(
					Admin\Page\List_Page::class,
					Admin\Page\Edit_Page::class,
					Admin\Page\New_Page::class,
					Admin\Page\Loader::class,
					Admin\WC_Settings::class,
					Admin\Tools::class,
					Admin\Assets::class,
					Admin\Ajax::class,
					Admin\Editor\Element_Panel\Panel::class,
				),
				$components
			);
		}

		return $components;
	}

	/**
	 * Maybe show an admin notice if WooCommerce wasn't loaded.
	 *
	 * @since x.x.x
	 * @return void
	 */
	private function maybe_show_admin_notice() {
		if ( did_action( 'woocommerce_loaded' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			sprintf(
				// translators: %s is a link to WooCommerce.
				esc_html__( 'WooCommerce Product Filters requires %s to be installed and active.', 'woocommerce-product-filters' ),
				'<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>'
			)
		);
	}
}
