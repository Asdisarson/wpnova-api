<?php
if ( isset( $panel_id ) && 'Project' === $panel_id ) {
	return;
}
?>

<div class="prev-panel-title action-back-panel-on-click">
	<i class="wcpf-icon-left-open-big back-icon"></i>
	<span class="text"><?php echo esc_html__( 'Project', 'woocommerce-product-filters' ); ?></span>
</div>
