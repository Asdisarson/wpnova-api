<div class="panel-navigation">
	<button class="button reset-panel-button disabled" type="button"><?php echo esc_html__( 'Reset', 'woocommerce-product-filters' ); ?></button>
	<button class="button apply-panel-button disabled" type="submit"><?php echo esc_html__( 'Apply', 'woocommerce-product-filters' ); ?></button>
</div>
