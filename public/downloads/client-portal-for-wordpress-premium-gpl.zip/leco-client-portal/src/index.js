/**
 * Import Gutenberg Blocks.
 *
 * @package     ClientPortal\Blocks.
 * @since       4.12
 */

import './utilities/index';

import './login-block/index';

import './register-block/index';
