/**
 * Add Custom Icon for the Client Portal custom category.
 *
 * @package     ClientPortal\Blocks.
 * @since       4.12
 */

import icon from '../assets/icons';

( function () {
	wp.blocks.updateCategory( 'leco-cp-blocks', { icon } );
} )();
