/**
 * Register Register Block
 *
 * @package     ClientPortal\Blocks.
 * @since       4.12
 */

const { __ } = wp.i18n;
const { useBlockProps, InspectorControls } = wp.blockEditor;
const { registerBlockType } = wp.blocks;
const { serverSideRender: ServerSideRender } = wp;
const { PanelBody, TextControl, Tip, ToggleControl } = wp.components;

import PostsDropdownControl from './posts-dropdown-control';

export default registerBlockType(
	'leco-cp/register',
	{
		title: __( 'Register Form', 'leco-cp' ),
		description: __( 'Add the Client Portal registration form.', 'leco-cp' ),
		category: 'leco-cp-blocks',
		icon: 'feedback',
		keywords: [
			__( 'Client Portal Register Form', 'leco-cp' ),
		],
		supports: {
			anchor: true, // allow support for an anchor tag.
			customClassName: true, // allows a custom classname to be added by the user.
			html: false, // allow the html to be edited.
			multiple: false, // allows more than one block of that type on the page.
			reusable: false, // whether block is allowed to be a reusable block.
		},
		attributes: {
			project: {
				type: 'integer',
			},
			template: {
				type: 'integer',
			},
			projectTitle: {
				type: 'string',
				default: __( 'New Project', 'leco-cp' )
			},
			showOrganization: {
				type: 'boolean',
				default: true,
			},
			privacyConsentLabel: {
				type: 'string',
				default: __( 'I agree with the storage and handling of my data by this website.', 'leco-cp' )
			},
		},
		edit: props => {
			const { isSelected, setAttributes } = props;
			let { template, project, projectTitle, showOrganization, privacyConsentLabel } = props.attributes;
			const blockProps = useBlockProps();
			const controls = [
				isSelected && (
					<InspectorControls key="inspector">
						<PanelBody
							title={ __( 'Registration Options', 'leco-cp' ) }
							initialOpen={ true }
						>
							<Tip>{ __( 'When no template and project selected, the default values from Client Portal Settings will be loaded.', 'leco-cp' ) } <br /><br /></Tip>
							<PostsDropdownControl
								label={ __( 'Create New Project', 'leco-cp' ) }
								postType='leco_template'
								value={ template }
								onChange={ ( template ) => setAttributes( { template } ) }
								isHidden={ project }
								defaultOption={ __( 'Don\'t create new project', 'leco-cp' ) }
								help={ __( 'Select a project template and we will create a new project with the client. If you don\'t select one, no new project will be created.', 'leco-cp' ) }
							/>
							<PostsDropdownControl
								label={ __( 'Attach a Project', 'leco-cp' ) }
								postType='leco_client'
								value={ project }
								onChange={ ( project ) => setAttributes( { project } ) }
								isHidden={ template }
								defaultOption={ __( 'Don\'t attach any project', 'leco-cp' ) }
								help={ __( 'You can attach a project to the client.', 'leco-cp' ) }
							/>
							{
								template ? (
									<TextControl
										label={ __( 'New Project Title', 'leco-cp' ) }
										value={ projectTitle }
										help={ __( 'The title of your new project.', 'leco-cp' ) }
										onChange={ ( projectTitle ) => setAttributes( { projectTitle } ) }
									/>
								) : ''
							}
							<ToggleControl
								label={ __( 'Display Organization Field', 'leco-cp' ) }
								checked={ showOrganization }
								onChange={ () => {
									setAttributes( { showOrganization: ! showOrganization } );
								} }
							/>
							<TextControl
								label={ __( 'Privacy Consent Label Text', 'leco-cp' ) }
								value={ privacyConsentLabel }
								help={ __( 'The label text of the Privacy consent checkbox. If left empty, the default text will be used.', 'leco-cp' ) }
								onChange={ ( privacyConsentLabel ) => setAttributes( { privacyConsentLabel } ) }
							/>
						</PanelBody>
					</InspectorControls>
				)
			];

			return [
				controls,
				(
					<div { ...blockProps }>
						<div className="leco-cp-disable-editing">
							<ServerSideRender
								block="leco-cp/register" attributes={ props.attributes }
							/>
						</div>
					</div>
				)
			];
		},
		save: props => {
			return null;
		},
	},
);
