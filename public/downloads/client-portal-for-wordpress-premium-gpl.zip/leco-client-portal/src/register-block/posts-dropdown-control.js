/**
 * The posts dropdown control component. Revised from the link reference blow.
 *
 * @package     ClientPortal\Blocks.
 * @since       4.12
 *
 * @link https://rudrastyh.com/gutenberg/get-posts-in-dynamic-select-control.html
 */

const { __ } = wp.i18n;
const { compose } = wp;
const { withSelect } = wp.data;
const { SelectControl } = wp.components;

const PostsDropdownControl = compose.compose(
	// withSelect allows to get posts for our SelectControl and also to get the post meta value
	withSelect( function ( select, props ) {
		let { postType } = props;

		return {
			posts: select( 'core' ).getEntityRecords( 'postType', postType ),
		}
	} ) )( function ( props ) {

		// options for SelectControl
		let options = [];
		let { label, value, onChange, isHidden, defaultOption, help } = props;

		// if posts found
		if ( props.posts ) {
			options.push( { value: 0, label: defaultOption } );
			props.posts.forEach( ( post ) => { // simple foreach loop
				options.push( { value: post.id, label: post.title.rendered } );
			} );
		} else {
			options.push( { value: 0, label: __( 'Loading...', 'leco-cp' ) } )
		}

		return (
			isHidden ? '' : wp.element.createElement( SelectControl,
				{
					label,
					options,
					onChange: function ( project ) {
						value = project;
						onChange( parseInt( value ) );
					},
					value,
					help
				}
			)
		);

	}
);

export default PostsDropdownControl
