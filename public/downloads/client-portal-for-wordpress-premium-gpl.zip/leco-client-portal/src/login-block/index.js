/**
 * Register Login Block
 *
 * @package     ClientPortal\Blocks.
 * @since       4.12
 */

const { __ } = wp.i18n;
const { useBlockProps } = wp.blockEditor;
const { registerBlockType } = wp.blocks;
const { serverSideRender: ServerSideRender } = wp;

export default registerBlockType(
	'leco-cp/login',
	{
		title: __( 'Login Form', 'leco-cp' ),
		description: __( 'Add the Client Portal login form.', 'leco-cp' ),
		category: 'leco-cp-blocks',
		icon: 'admin-network',
		keywords: [
			__( 'Client Portal Login Form', 'leco-cp' ),
		],
		supports: {
			anchor: true, // allow support for an anchor tag.
			customClassName: true, // allows a custom classname to be added by the user.
			html: false, // allow the html to be edited.
			multiple: false, // allows more than one block of that type on the page.
			reusable: false, // whether block is allowed to be a reusable block.
		},
		edit: props => {
			const { className, isSelected, setAttributes } = props;
			const blockProps = useBlockProps();
			return (
				<div { ...blockProps }>
					<div className="leco-cp-disable-editing">
						<ServerSideRender
							block="leco-cp/login"
						/>
					</div>
				</div>
			);
		},
		save: props => {
			return null;
		},
	},
);
