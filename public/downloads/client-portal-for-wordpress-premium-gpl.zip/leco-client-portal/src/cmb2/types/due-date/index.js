'use strict';

import './styles.scss';

const { __ } = wp.i18n;

window.addEventListener( 'load', () => {
	const datePickers = document.querySelectorAll(
		'.leco-cp-due-date input.cmb2-datepicker'
	);
	const timePickers = document.querySelectorAll(
		'.leco-cp-due-date input.cmb2-timepicker'
	);

	if ( datePickers.length ) {
		datePickers.forEach( ( datePicker ) => {
			const dateLabel = document.createElement( 'label' );
			dateLabel.innerHTML = __( 'Date:', 'leco-cp' );
			dateLabel.setAttribute( 'for', datePicker.getAttribute( 'id' ) );

			datePicker.before( dateLabel );
		} );
	}

	if ( timePickers.length ) {
		timePickers.forEach( ( timePicker ) => {
			const timeLabel = document.createElement( 'label' );
			timeLabel.innerHTML = __( 'Time:', 'leco-cp' );
			timeLabel.setAttribute( 'for', timePicker.getAttribute( 'id' ) );

			timePicker.before( timeLabel );
		} );
	}
} );
