'use strict';

import './styles.scss';

window.addEventListener( 'load', () => {
	const linksAddURL = document.querySelectorAll( '.leco-cp-add-url' );

	const attributeRenamer = ( element, index_or_container ) => {
		let rows;
		let shouldClearInputs = false;

		if ( Number.isInteger( index_or_container ) ) {
			rows = index_or_container + 1;
		} else {
			const $rows = index_or_container.querySelectorAll(
				'.leco-cp-multiple-urls__row'
			);

			rows = $rows.length + 1;
			shouldClearInputs = true;
		}

		element.querySelectorAll( 'label' ).forEach( ( label ) => {
			let regex = /\d_url/;

			if ( label.getAttribute( 'for' ).search( regex ) ) {
				label.setAttribute(
					'for',
					label
						.getAttribute( 'for' )
						.replace( regex, `${ rows }_url` )
				);
			}

			regex = /\d_title/;

			if ( label.getAttribute( 'for' ).search( regex ) ) {
				label.setAttribute(
					'for',
					label
						.getAttribute( 'for' )
						.replace( regex, `${ rows }_title` )
				);
			}
		} );

		element.querySelectorAll( 'input' ).forEach( ( input ) => {
			if ( shouldClearInputs ) {
				input.value = '';
			}

			if ( input.name.includes( '[url]' ) ) {
				let regex = /\[\d]\[url]/;

				input.setAttribute(
					'name',
					input.name.replace( regex, `[${ rows }][url]` )
				);

				regex = /\d_url/;

				input.id = input.id.replace( regex, `${ rows }_url` );
			}

			if ( input.name.includes( '[title]' ) ) {
				let regex = /\[\d]\[title]/;

				input.setAttribute(
					'name',
					input.name.replace( regex, `[${ rows }][title]` )
				);

				regex = /\d_title/;

				input.id = input.id.replace( regex, `${ rows }_title` );
			}
		} );
	};

	const addLink = ( e ) => {
		e.preventDefault();

		const $container = e.target.parentNode;
		const $template = $container.querySelector(
			'.leco-cp-multiple-urls__template'
		);

		const $clone = $template.cloneNode( true );
		$clone.classList.remove( 'leco-cp-multiple-urls__template' );
		$clone.classList.add( 'leco-cp-multiple-urls__row' );

		attributeRenamer( $clone, $container );

		$container.querySelector( '.leco-cp-multiple-urls' ).append( $clone );
		bindLinkRemovalEvents( $clone );
	};

	const removeURL = ( e ) => {
		e.preventDefault();

		const $moduleContainer = e.target.parentNode.parentNode;
		const $fieldset = e.target.parentNode;
		const $rows = [
			...$moduleContainer.querySelectorAll(
				'.leco-cp-multiple-urls__row'
			),
		];

		if (
			$fieldset.classList.contains( 'leco-cp-multiple-urls__template' )
		) {
			const $newTemplate = $rows[ 0 ];

			$newTemplate.classList.add( 'leco-cp-multiple-urls__template' );
			$newTemplate.classList.remove( 'leco-cp-multiple-urls__row' );

			attributeRenamer( $newTemplate, -1 );
			$rows.shift();
		}

		$fieldset.remove();

		$rows.forEach( ( $row, index ) => {
			attributeRenamer( $row, index );
		} );
	};

	const bindLinkRemovalEvents = ( elem ) => {
		const linksRemoveURL = elem.querySelectorAll( '.leco-cp-remove-url' );

		if ( linksRemoveURL.length ) {
			linksRemoveURL.forEach( ( link ) => {
				link.addEventListener( 'click', removeURL );
			} );
		}
	};

	if ( linksAddURL.length ) {
		linksAddURL.forEach( ( link ) => {
			link.addEventListener( 'click', addLink );
		} );
	}
	bindLinkRemovalEvents( document );

	jQuery( '.leco-cp-multiple-urls' ).sortable( {
		cursor: 'move',
	} );
} );
