<?php
/**
 * The class that handles the WooCommerce integration in the frontend template.
 *
 * @since       4.14.1
 * @copyright   Copyright (c) 2022, Laura Elizabeth
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @package     LECO\Client_Portal
 */

namespace LECO\Client_Portal\Templates\Integrations;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WC_Order;
use WC_Order_Item_Product;

/**
 * Class WooCommerce
 *
 * @since   4.14.1
 * @package LECO\Client_Portal
 */
class WooCommerce {

	/**
	 * Holds an instance of the object.
	 *
	 * @since 4.14
	 *
	 * @var WooCommerce
	 **/
	private static $instance = null;

	/**
	 * Returns the running object.
	 *
	 * @since 4.14
	 *
	 * @return WooCommerce
	 **/
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Hooks run when object initialized.
	 *
	 * @since 4.14
	 */
	public function hooks() {

		// Add CP portal information to order items.
		add_action( 'woocommerce_product_meta_start', array( $this, 'action_display_linked_project_data' ) );
		add_action( 'woocommerce_after_cart_item_name', array( $this, 'action_display_linked_project_data' ) );
		add_action( 'woocommerce_order_item_meta_start', array( $this, 'action_display_linked_project_data' ), 10, 2 );
		add_action( 'woocommerce_order_details_after_order_table', array( $this, 'action_woocommerce_order_details_after_order_table' ) );

	}

	/**
	 * Add the linked portal data to the product data.
	 *
	 * @since 4.14
	 *
	 * @param int|array             $product_or_id The product data or ID.
	 * @param WC_Order_Item_Product $item          The order item.
	 *
	 * @return void
	 */
	public function action_display_linked_project_data( $product_or_id = null, $item = null ) {

		if ( ! empty( $item ) ) {
			$product_id = $item->get_product_id();
		} elseif ( ! $product_or_id ) {
			global $post;

			$product_id = $post->ID;
		} elseif ( isset( $product_or_id['product_id'] ) ) {
			$product_id = $product_or_id['product_id'];
		} else {
			return;
		}

		$linked_project = leco_client_portal()->wc->get_linked_project( $product_id );
		if ( empty( $linked_project ) ) {
			return;
		}

		$description = esc_html__( 'You will be granted accesss to %s.', 'leco-cp' );

		switch ( $linked_project[0] ) {
			case 'attach':
				$project = get_post( $linked_project[1] );
				if ( ! is_a( $project, 'WP_Post' ) ) {
					return;
				}

				$description = sprintf( $description, $project->post_title );

				break;
			case 'create':
				$description = sprintf( $description, leco_client_portal()->wc->get_project_title( $product_id ) );

				break;
		}

		echo sprintf(
			'%s%s%s%s%s',
			'<p class="leco-cp-wrapper">',
			! $product_or_id ? '' : '<small>',
			esc_html( $description ),
			! $product_or_id ? '' : '</small>',
			'</p>'
		);

	}

	/**
	 * Display notes from CP in the order confirmation page.
	 *
	 * @since 4.14
	 *
	 * @param WC_Order $order The WooCommerce order.
	 *
	 * @return void
	 */
	public function action_woocommerce_order_details_after_order_table( $order ) {

		if ( ! $this->order_has_linked_projects( $order ) ) {
			return;
		}

		printf(
			'%s%s%s',
			'<p class="leco-cp-wc-order__details">',
			esc_html__( 'You\'ll get an email with instructions to access your project(s) that came with this order.', 'leco-cp' ),
			'</p>'
		);

	}

	/**
	 * Helper function to check if an order has linked CP projects.
	 *
	 * @since 4.14
	 *
	 * @param WC_Order $order The WooCommerce order.
	 *
	 * @return bool
	 */
	private function order_has_linked_projects( $order ) {

		$items = $order->get_items();
		foreach ( $items as $item ) {
			$product_id = $item['product_id'];

			$linked_project = leco_client_portal()->wc->get_linked_project( $product_id );
			if ( ! empty( $linked_project ) ) {
				return true;
			}
		}

		return false;

	}

}
