<?php
/**
 * Signup Form Template.
 *
 * @since   4.12
 * @package LECO\Client_Portal
 *
 * @var int    $project_id
 * @var int    $template_id
 * @var string $project_title
 * @var array  $attributes
 */

// Check if we are in the admin.
$is_admin = defined( 'REST_REQUEST' ) && REST_REQUEST;

$enable_branding = leco_cp_get_option( 'enable_branding', 'yes', 'register-login' ) === 'no' ? '' : ' leco-cp-branding';

global $leco_cp_register_redirect;

$leco_cp_register_redirect = apply_filters( 'leco_cp_register_redirect', leco_cp_get_current_page_url() );

$default_project_template = leco_cp_get_option( 'default_project_template', '', 'register-login' );
$default_project          = leco_cp_get_option( 'default_project', '', 'register-login' );

$register_another_portal = false;

if ( ! $is_admin ) {
	if ( $default_project && ! leco_cp_user_has_access( $default_project, true ) ) {
		$register_another_portal = true;
	}

	if ( ! $register_another_portal ) {
		$register_another_portal = is_user_logged_in() && $project_id;
		$register_another_portal = $register_another_portal && ! leco_cp_user_has_access( $project_id, true );
	}
}
?>

<div class="leco-cp-container<?php echo esc_attr( $enable_branding ); ?>">

	<?php

	if ( leco_client_portal()->session->get( 'leco_cp_registered_user' ) ) :

		printf(
			'<p>%s</p>',
			esc_html__( 'You have been successfully registered. Please check your email inbox for further details.', 'leco-cp' )
		);

		leco_client_portal()->session->set( 'leco_cp_registered_user', null );

	elseif ( is_user_logged_in() && ! $is_admin && ! $register_another_portal ) :

		printf(
			'<p>%s</p>',
			esc_html__( 'You have already registered.', 'leco-cp' )
		);

	else :

		if ( empty( $default_project_template ) && empty( $default_project ) ) {
			printf(
			/* translators: 1. Open strong tag 2. Close strong tag. */
				esc_html__( 'Set a default project template from: %1$sClient Portal Settings - Register/Login%2$s to enable user registration.', 'leco-cp' ),
				'<strong>',
				'</strong>'
			);

			return;
		}

		?>
		<form id="leco_cp_register_form" class="leco-cp-register-form leco-cp-form" action="" method="post">

			<?php do_action( 'leco_cp_print_errors' ); ?>

			<?php
			$value = isset( $_POST['leco_cp_f_name'] ) ? sanitize_text_field( wp_unslash( $_POST['leco_cp_f_name'] ) ) : ( $register_another_portal ? get_user_meta( get_current_user_id(), 'first_name', true ) : '' ); // phpcs:ignore
			printf(
				'<div class="leco-cp-register-f-name"><label for="leco-cp-f-name">%1$s<span class="required" aria-label="%2$s">*</span></label>
				<input type="text" id="leco-cp-f-name" name="leco_cp_f_name" aria-required="true" aria-label="%1$s %2$s" required="required" value="%3$s" /></div>',
				esc_html__( 'First Name', 'leco-cp' ),
				esc_html__( 'Required', 'leco-cp' ),
				esc_attr( $value )
			);

			$value = isset( $_POST['leco_cp_l_name'] ) ? sanitize_text_field( wp_unslash( $_POST['leco_cp_l_name'] ) ) : ( $register_another_portal ? get_user_meta( get_current_user_id(), 'last_name', true ) : '' ); // phpcs:ignore
			printf(
				'<div class="leco-cp-register-l-name"><label for="leco-cp-l-name">%1$s<span class="required" aria-label="%2$s">*</span></label>
				<input type="text" id="leco-cp-l-name" name="leco_cp_l_name" aria-required="true" aria-label="%1$s %2$s" required="required" value="%3$s" /></div>',
				esc_html__( 'Last Name', 'leco-cp' ),
				esc_html__( 'Required', 'leco-cp' ),
				esc_attr( $value )
			);

			$value = isset( $_POST['leco_cp_email'] ) ? sanitize_text_field( wp_unslash( $_POST['leco_cp_email'] ) ) : ( $register_another_portal ? wp_get_current_user()->user_email : '' ); // phpcs:ignore
			printf(
				'<div class="leco-cp-register-email"><label for="leco-cp-email">%1$s<span class="required" aria-label="%2$s">*</span></label>
				<input type="email" id="leco-cp-email" name="leco_cp_email" aria-required="true" aria-label="%1$s %2$s" required="required" value="%3$s" /></div>',
				esc_html__( 'Email', 'leco-cp' ),
				esc_html__( 'Required', 'leco-cp' ),
				esc_attr( $value )
			);

			if ( ! isset( $attributes['showorganization'] ) || filter_var( $attributes['showorganization'], FILTER_VALIDATE_BOOLEAN ) ) {

				$value = isset( $_POST['leco_cp_organization'] ) ? sanitize_text_field( wp_unslash( $_POST['leco_cp_organization'] ) ) : ( $register_another_portal ? get_user_meta( get_current_user_id(), 'leco_cp_user_organization', true ) : '' ); // phpcs:ignore
				printf(
					'<div class="leco-cp-register-organization"><label for="leco-cp-organization">%1$s</label>
					<input type="text" id="leco-cp-organization" name="leco_cp_organization" aria-required="false" aria-label="%1$s %2$s" value="%3$s" /></div>',
					esc_html__( 'Organization', 'leco-cp' ),
					esc_html__( 'Optional', 'leco-cp' ),
					esc_attr( $value )
				);

			}

			printf(
				'<div class="leco-cp-register-privacy"><h3>%1$s <span class="required" aria-label="%2$s">*</span></h3><input type="checkbox" name="leco_cp_privacy" id="leco-cp-privacy" aria-required="true" aria-label="%2$s %3$s" required="required"/>
				<label for="leco-cp-privacy">%2$s%4$s</label></div>',
				esc_html__( 'Privacy', 'leco-cp' ),
				isset( $attributes['privacyconsentlabel'] ) && $attributes['privacyconsentlabel'] ? esc_html( $attributes['privacyconsentlabel'] ) : esc_html__( 'I agree with the storage and handling of my data by this website.', 'leco-cp' ),
				esc_html__( 'Required', 'leco-cp' ),
				get_privacy_policy_url() ? ' <a href="' . esc_url( get_privacy_policy_url() ) . '">' . esc_html__( 'Read the Privacy Policy.', 'leco-cp' ) . '</a>' : ''
			);

			do_action( 'leco_cp_register_form_fields_before_submit' );

			printf(
				'<div class="leco-cp-register-submit"><input type="submit" id="leco-cp-register-submit--btn" class="button button-primary" name="leco_cp_register_submit" value="%s"/></div>',
				esc_html__( 'Complete Registration', 'leco-cp' )
			);

			?>

			<input type="hidden" name="leco_cp_honeypot" value=""/>
			<input type="hidden" name="leco_cp_action" value="register"/>
			<input type="hidden" name="leco_cp_redirect" value="<?php echo esc_url( $leco_cp_register_redirect ); ?>"/>
			<?php if ( $project_id ) { ?>
				<input type="hidden" name="leco_cp_project" value="<?php echo esc_attr( $project_id ); ?>"/>
			<?php } ?>
			<?php if ( $template_id ) { ?>
				<input type="hidden" name="leco_cp_template" value="<?php echo esc_attr( $template_id ); ?>"/>
			<?php } ?>
			<?php if ( $template_id && $project_title ) { ?>
				<input type="hidden" name="leco_cp_project_title" value="<?php echo esc_attr( $project_title ); ?>"/>
			<?php } ?>

		</form>

	<?php endif; ?>

</div>
