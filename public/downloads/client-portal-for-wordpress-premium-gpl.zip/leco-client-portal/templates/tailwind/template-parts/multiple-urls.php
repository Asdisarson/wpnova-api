<?php
/**
 * Multiple URLs lity box.
 *
 * @var string $number The phase number.
 * @var string $key    The module key.
 * @var array  $module The module data.
 * @var string $type   The module type.
 *
 * @package LECO\Client_Portal
 */

?>
<div class="lity-hide" id="module_<?php echo esc_attr( $number ) . '_' . esc_attr( $key ); ?>">
	<div class="module <?php echo esc_attr( $module['status'] ); ?>">
												<span class="ico-area">
												<span class="iconset"><?php echo leco_cp_get_module_icon( $module['icon'], $key, $number ); // phpcs:ignore. ?></span>
											</span>
		<span class="title"><?php echo esc_html( $module['title'] ); ?></span>
		<span class="desc"><?php echo ( isset( $module['description'] ) ) ? wp_kses( $module['description'], 'post' ) : ''; ?></span>
	</div>

	<ul class="multiple-urls">
		<?php
		$links = array();

		if ( 'multiple-urls' === $type ) {
			$links = $module['multiple_urls'];
		}

		foreach ( $links as $_link ) {
			$_title = ! empty( $_link['title'] ) ? $_link['title'] : $_link['url'];
			?>
			<li>
				<a href="<?php echo esc_attr( $_link['url'] ); ?>" target="_blank">
					<?php echo esc_html( $_title ); ?>
					<span class="icon-download">
					<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
							viewBox="0 0 48 48" style="enable-background:new 0 0 48 48;" xml:space="preserve">
					<g id="Arrow_-_Right">
						<line class="st0" x1="4" y1="24" x2="43" y2="24"/>
						<polyline class="st0" points="23.5,43.5 43,24 23.5,4.5 	"/>
					</g>
					</svg>
				 </span>
				</a>
			</li>
		<?php } ?>
	</ul>

</div>
