<?php
/**
 * Block styles for Gutenberg Blocks
 *
 * @since       4.12
 */

// Get colors from CP settings.
$pc  = leco_cp_get_option( 'primary_color', '#52cdf5' );
$ptc = leco_cp_get_option( 'primary_text_color', '#ffffff' );
$sc  = leco_cp_get_option( 'secondary_color', '#ff5f5f' );
$stc = leco_cp_get_option( 'secondary_text_color', '#ffffff' );
$tc  = leco_cp_get_option( 'tertiary_color', '#3c5063' );
$ttc = leco_cp_get_option( 'tertiary_text_color', '#ffffff' );

?>

<style>
	.leco-cp-branding {
		--primary-color: <?php echo ( empty( $pc ) ) ? 'transparent' : $pc; ?>;
		--primary-text-color: <?php echo ( empty( $ptc ) ) ? 'transparent' : $ptc; ?>;
		--secondary-color: <?php echo ( empty( $sc ) ) ? 'transparent' : $sc; ?>;
		--secondary-text-color: <?php echo ( empty( $stc ) ) ? 'transparent' : $stc; ?>;
		--tertiary-color: <?php echo ( empty( $tc ) ) ? 'transparent' : $tc; ?>;
		--tertiary-text-color: <?php echo ( empty( $ttc ) ) ? 'transparent' : $ttc; ?>;
		--leco-cp-form-max-width: 700px;
	}
</style>
