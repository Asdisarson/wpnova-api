<?php
/**
 * Email Body
 *
 * @since   4.9
 * @package LECO Client Portal/Templates/Emails
 * @author  Laura Elizabeth
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly.

// {email} is replaced by the content entered in Settings > Notifications

?>
{email}
