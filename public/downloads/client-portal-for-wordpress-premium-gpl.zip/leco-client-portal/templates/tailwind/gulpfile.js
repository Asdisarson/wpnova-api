var gulp = require('gulp'),
    less = require('gulp-less'),
    postcss = require('gulp-postcss'),
    tailwindcss = require('tailwindcss'),
    cssTask = function () {
        return gulp.src('src/style.less')
        // ...
            .pipe(less())
            .pipe(postcss([
                // ...
                tailwindcss('./tailwind.config.js'),
                require('autoprefixer'),
                // ...
            ]))
            // ...
            .pipe(gulp.dest('build/'));
    },
    blocksCss = function () {
        return gulp.src('src/blocks.less')
            // ...
            .pipe(less())
            .pipe(postcss([
                // ...
                tailwindcss('./tailwind.config.js'),
                require('autoprefixer'),
                // ...
            ]))
            // ...
            .pipe(gulp.dest('build/'));
    };

gulp.task('css', cssTask);

gulp.task('css', blocksCss);

gulp.task('watch', function () {
    gulp.watch(['src/*.less', 'src/**/*.less', 'tailwind.config.js'], cssTask);
    gulp.watch(['src/*.less', 'src/**/*.less', 'tailwind.config.js'], blocksCss);
});
