<?php
/**
 * Plugin Name:     Client Portal by Laura Elizabeth
 * Plugin URI:      https://client-portal.io/
 * Description:     A super simple, lightweight WordPress plugin to keep your client deliverables in one place.
 * Version:         4.16.5
 * Author:          Laura Elizabeth
 * Author URI:      http://lauraelizabeth.co/
 * License:         GPL-3.0+
 * Text Domain:     leco-cp
 * Domain Path:     /languages
 *
 * ------------------------------------------------------------------------
 * Copyright 2016-2020 Laurium Design Ltd.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses.
 *
 * @package LECO\Client_Portal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LECO_CP_MAIN_FILE', __FILE__ );

if ( ! class_exists( 'LECO_Client_Portal' ) ) {
	require 'class-leco-client-portal.php';
}

/**
 * The main function responsible for returning the one true LECO_Client_Portal
 * instance to functions everywhere
 *
 * @since  1.0.0
 * @return LECO_Client_Portal The one true LECO_Client_Portal
 */
function leco_client_portal() {
	return LECO_Client_Portal::instance();
}

leco_client_portal();

/**
 * The activation hook is called outside of the singleton because WordPress doesn't
 * register the call from within the class, since we are preferring the plugins_loaded
 * hook for compatibility, we also can't reference a function inside the plugin class
 * for the activation function. If you need an activation function, put it here.
 *
 * @since       1.0.0
 * @return      void
 */
function leco_cp_activation() {
	leco_client_portal()->create_login_page();
	leco_cp_register_post_type();
	leco_client_portal()->endpoint();

	flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'leco_cp_activation' );

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
