<?php
/**
 * Process all login-ish stuff.
 *
 * @since       4.11
 * @copyright   Copyright (c) 2021, Laura Elizabeth
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @package     LECO\Client_Portal
 */

namespace LECO\Client_Portal;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Post;
use WP_User;

/**
 * Class Login
 *
 * @since   4.11
 * @package LECO\Client_Portal
 */
class Login {

	/**
	 * Get the default login page.
	 *
	 * @since 4.12
	 *
	 * @return int
	 */
	public static function default_login_page() {

		$if_has_client_login_page = get_page_by_path( 'client-portal-login' );
		if ( isset( $if_has_client_login_page->ID ) ) {
			return $if_has_client_login_page->ID;
		} else {
			return 0;
		}

	}

	/**
	 * Check if the current page is the login page.
	 *
	 * @since 4.12
	 *
	 * @param WP_Post|string $post_or_url The post object or redirect URL.
	 *
	 * @return bool
	 */
	public static function is_login_page( $post_or_url = null ) {

		if ( $post_or_url === null ) {
			global $post;
			$post_or_url = $post;
		}

		$login_page = leco_cp_get_option( 'client_portal_login', self::default_login_page(), 'register-login' );

		if ( is_a( $post_or_url, 'WP_Post' ) ) {
			if ( isset( $post_or_url->post_name ) && 'client-portal-login' == $post_or_url->post_name ) {
				return true;
			} elseif ( $post_or_url->ID == $login_page ) {
				return true;
			}
		} else {
			$login_page = get_post( $login_page );

			if ( isset( $login_page->post_name ) && strstr( $post_or_url, $login_page->post_name ) ) {
				return true;
			}
		}

		return false;

	}

	/**
	 * Get the login url. Migrated from leco_cp_login_url().
	 *
	 * @since 4.11
	 *
	 * @param string $redirect     The redirection URL.
	 * @param false  $force_reauth If we should force reauth.
	 *
	 * @return string
	 */
	public static function login_url( $redirect = '', $force_reauth = false ) {

		$login_page = leco_cp_get_option( 'client_portal_login', self::default_login_page(), 'register-login' );
		$login_url  = trailingslashit( get_permalink( $login_page ) );

		if ( ! empty( $redirect ) ) {
			$login_url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $login_url );
		}

		if ( $force_reauth ) {
			$login_url = add_query_arg( 'reauth', '1', $login_url );
		}

		/**
		 * Filters the login URL.
		 *
		 * @since 4.6
		 *
		 * @param string $redirect     The path to redirect to on login, if supplied.
		 * @param bool   $force_reauth Whether to force reauthorization, even if a cookie is present.
		 *
		 * @param string $login_url    The login URL. Not HTML-encoded.
		 */
		return apply_filters( 'leco_cp_login_url', $login_url, $redirect, $force_reauth );

	}

	/**
	 * Get the (re)set password URL.
	 *
	 * @param WP_User $user The user object.
	 *
	 * @return string
	 */
	public static function set_password_url( $user ) {

		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) {
			return leco_cp_login_url();
		}

		if ( ! user_can( $user, 'leco_client' ) ) {
			return network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user->user_login ), 'login' );
		}

		return leco_cp_login_url() . "?action=rp&key=$key&login=" . rawurlencode( $user->user_login );

	}

}
