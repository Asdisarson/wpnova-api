<?php
/**
 * Register Shortcodes / Blocks
 *
 * @package     ClientPortal\Shortcode.
 * @since       4.12
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Callback function for Login Block and Login Shortcode.
 *
 * @since 4.12
 *
 * @param array $attributes  Attributes from block or shortcode options (currently none).
 *
 * @return string Rendered HTML.
 */
function leco_cp_render_login_form( $attributes ) {

	ob_start();

	$enable_branding = leco_cp_get_option( 'enable_branding', 'yes', 'register-login' );

	$class = $enable_branding === 'no' ? '' : ' leco-cp-branding';

	if ( 'no' !== $enable_branding ) {
		include LECO_CLIENT_PORTAL_DIR . '/templates/tailwind/block-header.php';
	}

	echo leco_cp_login_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	$login = ob_get_contents();

	ob_end_clean();

	return $login;
}

add_shortcode( 'client_portal_login', 'leco_cp_render_login_form' );

/**
 * Callback function for Register Block and Register Shortcode.
 *
 * @since 4.12
 *
 * @param array $attributes  Attributes from block or shortcode options (currently none).
 *
 * @return string Rendered HTML.
 */
function leco_cp_render_register_form( $attributes ) {

	ob_start();

	$enable_branding = leco_cp_get_option( 'enable_branding', 'yes', 'register-login' );

	if ( 'no' !== $enable_branding ) {
		include LECO_CLIENT_PORTAL_DIR . '/templates/tailwind/block-header.php';
	}

	// Lowercase all the attribute keys and remove symbols.
	$attributes = array_change_key_case( (array) $attributes, CASE_LOWER );

	$project_id = isset( $attributes['project'] ) ? intval( $attributes['project'] ) : 0;
	if ( $project_id && get_post_type( $project_id ) !== 'leco_client' ) {
		$project_id = 0;
	}
	$template_id = isset( $attributes['template'] ) ? intval( $attributes['template'] ) : 0;
	if ( $template_id && get_post_type( $template_id ) !== 'leco_template' ) {
		$template_id = 0;
	}
	$project_title = isset( $attributes['projecttitle'] ) ? sanitize_text_field( $attributes['projecttitle'] ) : esc_html__( 'New Project', 'leco-cp' );
	$project_title = isset( $attributes['project_title'] ) ? sanitize_text_field( $attributes['project_title'] ) : $project_title;

	include LECO_CLIENT_PORTAL_DIR . '/templates/tailwind/template-parts/register-form.php';

	$register_form = ob_get_contents();

	ob_end_clean();

	return $register_form;
}

add_shortcode( 'client_portal_register', 'leco_cp_render_register_form' );
