<?php
/**
 * The class that handles the WooCommerce integration.
 *
 * @since       4.14
 * @copyright   Copyright (c) 2022, Laura Elizabeth
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @package     LECO\Client_Portal
 */

namespace LECO\Client_Portal\Integrations;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LECO\Client_Portal\Project;
use LECO\Client_Portal\User;
use WC_Admin_Meta_Boxes;
use WC_Order;
use WP_User;

/**
 * Class WooCommerce
 *
 * @since   4.14
 * @package LECO\Client_Portal
 */
class WooCommerce {

	/**
	 * Holds an instance of the object.
	 *
	 * @since 4.14
	 *
	 * @var WooCommerce
	 **/
	private static $instance = null;

	/**
	 * The metabox prefix.
	 *
	 * @since 4.14
	 *
	 * @var string $prefix
	 */
	private $prefix = 'leco_cp_';

	/**
	 * The paid statuses.
	 *
	 * @since 4.14
	 *
	 * @var string[]
	 */
	private $is_paid_statuses;

	/**
	 * Returns the running object.
	 *
	 * @since 4.14
	 *
	 * @return WooCommerce
	 **/
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();

			self::$instance->is_paid_statuses = wc_get_is_paid_statuses();
		}

		return self::$instance;
	}

	/**
	 * Hooks run when object initialized.
	 *
	 * @since 4.14
	 */
	public function hooks() {

		add_filter( 'woocommerce_product_data_tabs', array( $this, 'add_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'add_panel' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_meta' ) );

		foreach ( $this->is_paid_statuses as $status ) {
			add_action( 'woocommerce_order_status_' . $status, array( $this, 'action_link_project' ), 10, 2 );
		}

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

		add_filter( 'leco_cp_user_has_access', array( $this, 'filter_leco_cp_user_has_access' ), 10, 3 );

	}

	/**
	 * Add custom JS to the WooCommerce product admin.
	 *
	 * @since 4.14
	 *
	 * @return void
	 */
	public function admin_scripts() {

		$screen = get_current_screen();

		wp_register_script( 'leco-cp-woocommerce', LECO_CLIENT_PORTAL_URL . 'assets/js/woocommerce.js', array(), LECO_CLIENT_PORTAL_VER, true );
		wp_register_style( 'leco-cp-woocommerce', LECO_CLIENT_PORTAL_URL . 'assets/css/woocommerce.css', array(), LECO_CLIENT_PORTAL_VER );

		if ( $screen->id === 'product' ) {
			wp_enqueue_script( 'leco-cp-woocommerce' );
			wp_enqueue_style( 'leco-cp-woocommerce' );
		}

	}


	/**
	 * Add the Related Projects tab.
	 *
	 * @since 4.14
	 *
	 * @param array $tabs The tabs array.
	 *
	 * @return array
	 */
	public function add_tab( $tabs ) {

		$tabs['leco_cp'] = array(
			'label'    => esc_html__( 'Linked Client Portal', 'leco-cp' ),
			'target'   => $this->prefix . 'project',
//			'class'    => array( 'show_if_virtual' ),
			'priority' => 41,
		);

		return $tabs;

	}

	/**
	 * Add the Related Projects panel.
	 *
	 * @since 4.14
	 */
	public function add_panel() {

		echo '<div id="' . $this->prefix . 'project" class="panel woocommerce_options_panel hidden">';

		printf(
			'<p class="leco-cp-wc-metabox__description">%s</p>',
			esc_html__( 'You can link a Client Portal project to this product. When a customer purchases this product, an existing project or a new project will be created and attached to them.', 'leco-cp' )
		);

		$is_reg_enable   = apply_filters( 'woocommerce_checkout_registration_enabled', 'yes' === get_option( 'woocommerce_enable_signup_and_login_from_checkout' ) );
		$is_reg_required = apply_filters( 'woocommerce_checkout_registration_required', 'yes' !== get_option( 'woocommerce_enable_guest_checkout' ) );

		if ( ! $is_reg_required || ! $is_reg_enable ) {
			printf(
				'<p class="leco-cp-wc-metabox__description--warning">%s</p>',
				sprintf( esc_html__( 'Please adjust your Guest Checkout and Account Creation settings in WooCommerce Settings to properly enable this feature. %1$sRead more%2$s.', 'leco-cp' ), '<a href="https://client-portal.io/client/client-portal-support/module/woocommerce-support/" target="_blank">',
					'</a>' )
			);
		}

		$projects = array_replace( array( '0' => esc_html__( 'Don\'t attach any project', 'leco-cp' ) ), Project::get_all() );

		woocommerce_wp_select(
			array(
				'id'          => $this->prefix . 'template',
				'value'       => get_post_meta( get_the_ID(), $this->prefix . 'template', true ),
//			'wrapper_class' => 'show_if_downloadable',
				'label'       => esc_html__( 'Create New project', 'leco-cp' ),
				'options'     => leco_cp_get_project_template_options( esc_html__( 'Don\'t create new project', 'leco-cp' ) ),
				'description' => esc_html__( 'Select a template to create a new project.', 'leco-cp' ),
				'desc_tip'    => true,
			)
		);

		woocommerce_wp_checkbox(
			array(
				'id'          => $this->prefix . 'skip_if_purchased',
				'value'       => get_post_meta( get_the_ID(), $this->prefix . 'skip_if_purchased', true ),
				'label'       => esc_html__( 'Skip Project Creation', 'leco-cp' ),
				'description' => esc_html__( 'Do not create a new project if the customer already has a project created from this template', 'leco-cp' ),
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'          => $this->prefix . 'project_title',
				'value'       => get_post_meta( get_the_ID(), $this->prefix . 'project_title', true ),
				'label'       => esc_html__( 'New Project Title', 'leco-cp' ),
				'description' => esc_html__( 'The title of the new project. Supported template tags: {first_name} and {last_name}.', 'leco-cp' ),
				'desc_tip'    => true,
			)
		);

		woocommerce_wp_select(
			array(
				'id'          => $this->prefix . 'project',
				'value'       => get_post_meta( get_the_ID(), $this->prefix . 'project', true ),
//			'wrapper_class' => 'show_if_downloadable',
				'label'       => esc_html__( 'Attach a project', 'leco-cp' ),
				'options'     => $projects,
				'description' => esc_html__( 'Select a project to attach to this product.', 'leco-cp' ),
				'desc_tip'    => true,
			)
		);

		echo '</div>';

	}

	/**
	 * Save the data to meta.
	 *
	 * @since 4.14
	 * @since 4.16.3 Added the `leco_cp_skip_if_purchased` meta.
	 *
	 * @param int $post_id The post ID.
	 */
	public function save_meta( $post_id ) {

		if ( isset( $_POST[ "{$this->prefix}template" ] ) ) { // phpcs:ignore.

			if ( $_POST[ "{$this->prefix}template" ] !== '0' && empty( $_POST[ "{$this->prefix}project_title" ] ) ) { // phpcs:ignore.
				WC_Admin_Meta_Boxes::add_error( esc_html__( 'You need to set up a project title in the Linked Client Portal tab.', 'leco-cp' ) );

				return;
			}

			update_post_meta( $post_id, "{$this->prefix}template", intval( $_POST[ "{$this->prefix}template" ] ) ); // phpcs:ignore.
			update_post_meta( $post_id, "{$this->prefix}project_title", sanitize_text_field( $_POST[ "{$this->prefix}project_title" ] ) ); // phpcs:ignore.

		}

		if ( isset( $_POST[ "{$this->prefix}project" ] ) ) { // phpcs:ignore.
			update_post_meta( $post_id, "{$this->prefix}project", intval( $_POST[ "{$this->prefix}project" ] ) ); // phpcs:ignore.
		}

		if ( isset( $_POST[ "{$this->prefix}skip_if_purchased" ] ) ) { // phpcs:ignore.
			update_post_meta( $post_id, "{$this->prefix}skip_if_purchased", $_POST[ "{$this->prefix}skip_if_purchased" ] ); // phpcs:ignore.
		} else {
			delete_post_meta( $post_id, "{$this->prefix}skip_if_purchased" );
		}

	}

	/**
	 * Link the project to the order after it is completed.
	 *
	 * @since 4.14
	 *
	 * @param int      $order_id The WooCommerce order ID.
	 * @param WC_Order $order    The WooCommerce order object.
	 *
	 * @return void
	 */
	public function action_link_project( $order_id, $order ) {

		// If the user is not logged in, bail out.
		if ( ! is_user_logged_in() ) {
			return;
		}

		if ( class_exists( 'WC_Subscriptions' ) ) {
			// Do not link the project if the order is a subscription renewal.
			if ( wcs_order_contains_subscription( $order, array( 'renewal', 'resubscribe', 'switch' ) ) ) {
				return;
			}
		}

		$user_id = get_current_user_id();

		$projects_created = (array) get_post_meta( $order_id, "{$this->prefix}projects_created", true );

		// Get the product from the order. If no CP portal linked, bail out.
		$items = $order->get_items();
		foreach ( $items as $item ) {
			$product_id = $item['product_id'];
			// Later when we need the variation id, we can use this: $item['variation_id'].

			$linked_project = $this->get_linked_project( $product_id );
			if ( empty( $linked_project ) ) {
				continue;
			}

			// Check if the linked marker is set.
			if ( in_array( $product_id, $projects_created, true ) ) {
				return;
			}

			// Add the user role "leco_client".
			if ( ! user_can( $user_id, 'leco_client' ) ) {
				User::add_role( $user_id );
			}

			// If the user has been linked to the project, bail out.
			if ( $linked_project[0] === 'attach' ) {
				$projects = leco_cp_get_projects_by_client( $user_id );
				if ( in_array( $linked_project[1], $projects ) ) {
					continue;
				}
			}

			// Create a project or add user to the existing project set in the product meta.
			switch ( $linked_project[0] ) {
				case 'create':
					$project_id = Project::create(
						array(
							'template_id' => $linked_project[1],
							'post_title'  => $this->get_project_title( $product_id ),
							'client_id'   => $user_id,
						)
					);

					update_post_meta( $project_id, 'wc_orders',
						array(
							array(
								'order_id'   => $order_id,
								'product_id' => $product_id,
							),
						)
					);
					break;

				case 'attach':
					User::attach_project( $user_id, $linked_project[1] );

					$wc_orders   = (array) get_post_meta( $linked_project[1], 'wc_orders', true );
					$wc_orders[] = array(
						'order_id'   => $order_id,
						'product_id' => $product_id,
					);
					update_post_meta( $linked_project[1], 'wc_orders', $wc_orders );
					break;
			}

			// Set a marker to the order to indicate the project has been linked.
			$projects_created[] = $product_id;
			update_post_meta( $order_id, "{$this->prefix}projects_created", $projects_created );
		}

	}

	/**
	 * Check the user access based on a WC Order statas.
	 *
	 * @since 4.14
	 *
	 * @param bool $has_access   If the user can access the project.
	 * @param int  $project_id   Project ID.
	 * @param bool $ignore_admin If we should ignore the admin caps check.
	 *
	 * @return bool
	 */
	public function filter_leco_cp_user_has_access( $has_access, $project_id, $ignore_admin ) {

		if ( ! $has_access || ( ! $ignore_admin && current_user_can( 'edit_posts' ) ) ) {
			return $has_access;
		}

		$wc_orders = get_post_meta( $project_id, 'wc_orders', true );

		if ( ! $wc_orders ) {
			return $has_access;
		}

		$user_id              = get_current_user_id();
		$should_remove_access = true;

		foreach ( $wc_orders as $order_data ) {

			if ( ! isset( $order_data['order_id'] ) || ! isset( $order_data['product_id'] ) ) {
				continue;
			}

			$order_id   = $order_data['order_id'];
			$product_id = $order_data['product_id'];

			$order = wc_get_order( $order_id );

			// If not the current user's order, bail out.
			if ( ! $order || $user_id !== $order->get_user_id() ) {
				continue;
			}

			// Check if it's the user has active subscription.
			if ( class_exists( 'WC_Subscriptions' ) && \WC_Subscriptions_Product::is_subscription( $product_id ) ) {

				if ( wcs_user_has_subscription( $user_id, $product_id, array( 'active', 'pending-cancel' ) ) ) {
					$should_remove_access = false;
				}

			} else {
				// Check the order status.
				if ( in_array( $order->get_status(), $this->is_paid_statuses ) ) {
					$should_remove_access = false;
				}
			}

		}

		if ( $should_remove_access ) {
			$this->remove_user_access( $user_id, $project_id );

			return false;
		}

		return $has_access;

	}

	/**
	 * Get the linked portal from a product. Returned format is an array, first element is the action and the second is the portal or template ID.
	 *
	 * @since 4.14
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return array
	 */
	public function get_linked_project( $product_id ) {

		$template_id = get_post_meta( $product_id, "{$this->prefix}template", true );

		if ( $template_id ) {
			if ( $this->maybe_skip_project_creation( $product_id ) ) {
				return array();
			}

			return array( 'create', $template_id );
		}

		$project_id = get_post_meta( $product_id, "{$this->prefix}project", true );

		if ( $project_id ) {
			return array( 'attach', $project_id );
		}

		return array();

	}

	/**
	 * Set up the default value for a project title.
	 *
	 * @since 1.0
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return string
	 */
	public function get_project_title( $product_id ) {

		$project_title = get_post_meta( $product_id, "{$this->prefix}project_title", true );

		if ( ! $project_title ) {
			$project_title = esc_html__( 'New Project', 'leco-cp' );
		} elseif ( is_user_logged_in() ) {
			add_filter( 'leco_cp_email_user', array( $this, 'filter_get_user' ) );
			$project_title = leco_client_portal()->emails->parse_tags( $project_title );
			remove_filter( 'leco_cp_email_user', array( $this, 'filter_get_user' ) );
		}

		return $project_title;

	}

	/**
	 * Filter to get a WP_User object.
	 *
	 * @since 4.16.3
	 *
	 * @return WP_User
	 */
	public function filter_get_user() {

		return new WP_User( get_current_user_id() );

	}

	/**
	 * Remove user's access to a project.
	 *
	 * @since 4.14
	 *
	 * @param int $user_id    The user ID.
	 * @param int $project_id The project ID.
	 *
	 * @return void
	 */
	private function remove_user_access( $user_id, $project_id ) {

		$projects = leco_cp_get_projects_by_client( $user_id );

		if ( ! empty( $projects ) ) {
			if ( ( $key = array_search( $project_id, $projects ) ) !== false ) {
				unset( $projects[ $key ] );
				update_user_meta( $user_id, 'leco_cp_project', $projects );
			}
		}

		$clients = get_post_meta( $project_id, 'leco_cp_client', true );
		if ( $clients ) {
			if ( ( $key = array_search( $user_id, $clients ) ) !== false ) {
				unset( $clients[ $key ] );
				update_post_meta( $project_id, 'leco_cp_client', $clients );
			}
		}

	}

	/**
	 * Skip project creation if the user already has a project created from this template.
	 *
	 * @since 4.16.3
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return bool
	 */
	private function maybe_skip_project_creation( $product_id ) {

		$user_id = get_current_user_id();

		$skip_project_creation = get_post_meta( $product_id, "{$this->prefix}skip_if_purchased", true );

		if ( 'yes' === $skip_project_creation ) {
			// Check if the user already has a project created from this template.
			$user_projects = leco_cp_get_projects_by_client( $user_id );

			foreach ( $user_projects as $project ) {
				$project_template = get_post_meta( $project, "{$this->prefix}template", true );

				if ( ! $project_template ) {
					continue;
				}

				if ( $project_template == get_post_meta( $product_id, "{$this->prefix}template", true ) ) {
					return true;
				}
			}
		}

		return false;

	}

}
