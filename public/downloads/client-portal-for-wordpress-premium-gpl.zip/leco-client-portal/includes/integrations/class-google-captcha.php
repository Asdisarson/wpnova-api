<?php
/**
 * The class that handles the reCaptcha by BestWebSoft integration.
 *
 * @since       4.14.2
 * @copyright   Copyright (c) 2022, Laura Elizabeth
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @package     LECO\Client_Portal
 */

namespace LECO\Client_Portal\Integrations;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Google_Captcha
 *
 * @since   4.14.2
 * @package LECO\Client_Portal
 */
class Google_Captcha {

	/**
	 * Holds an instance of the object.
	 *
	 * @since 4.14.2
	 *
	 * @var Google_Captcha
	 **/
	private static $instance = null;

	/**
	 * Returns the running object.
	 *
	 * @since 4.14.2
	 *
	 * @return Google_Captcha
	 **/
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Add hooks.
	 *
	 * @since 4.14.2
	 *
	 * @return void
	 */
	public function hooks() {

		add_filter( 'gglcptch_add_custom_form', array( $this, 'filter_add_custom_recaptcha_forms' ) );
		add_action( 'leco_cp_process_register_form', array( $this, 'action_leco_cp_process_register_form' ) );
		add_action( 'leco_cp_register_form_fields_before_submit', array( $this, 'action_add_recaptcha' ) );

	}

	/**
	 * Add our register form to custom forms.
	 *
	 * @since 4.14.2
	 *
	 * @param array $forms The forms array.
	 *
	 * @return array
	 */
	public function filter_add_custom_recaptcha_forms( $forms ) {

		$forms['leco_cp_register'] = array( 'form_name' => 'Client Portal Register Form' );

		return $forms;

	}

	/**
	 * Check the recaptcha result in form processing.
	 *
	 * @since 4.14.2
	 *
	 * @return void
	 */
	public function action_leco_cp_process_register_form() {

		if ( ! $this->is_recaptcha_enabled() ) {
			return;
		}

		$check_result = apply_filters( 'gglcptch_verify_recaptcha', true, 'string', 'leco_cp_register' );
		if ( true !== $check_result ) {
			leco_cp_set_error( 'error_gglcptch_verify_recaptcha', esc_html__( 'The Google Recaptcha has failed.', 'leco-cp' ) );
		}

	}

	/**
	 * Add ReCaptcha.
	 *
	 * @since 4.14.2
	 *
	 * @return void
	 */
	public function action_add_recaptcha() {

		if ( ! $this->is_recaptcha_enabled() ) {
			return;
		}

		echo apply_filters( 'gglcptch_display_recaptcha', '', 'leco_cp_register' );

	}

	/**
	 * If the recaptcha is enabled.
	 *
	 * @since 4.14.2
	 *
	 * @return bool
	 */
	private function is_recaptcha_enabled() {

		global $gglcptch_options;

		return ! empty( $gglcptch_options['leco_cp_register'] );

	}

}
