<?php
/**
 * Notification Digest Settings.
 *
 * Defines a Notification Digest Settings object in Client Portal.
 *
 * @since      4.15
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2022, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications\Digest;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use CMB2;

/**
 * LECO CP Notification Digest Settings object.
 *
 * @since 4.15
 */
final class Settings {

	/**
	 * The cmb2 object.
	 *
	 * @since 4.15
	 *
	 * @var CMB2
	 */
	private $cmb;

	/**
	 * The group field id for the Digest settings.
	 *
	 * @since 4.15
	 *
	 * @var string
	 */
	private $group_field_id;

	/**
	 * Create Digest Settings.
	 *
	 * @since 4.15
	 *
	 * @param CMB2 $cmb The CMB2 object.
	 */
	public function __construct( $cmb ) {

		$this->cmb = $cmb;

		$this->group_field_id = $this->cmb->add_field(
			array(
				'id'         => 'digest',
				'desc'       => esc_html__( 'Digest settings for notifications.', 'leco-cp' ),
				'type'       => 'group',
				'repeatable' => false,
				'options'    => array(
					'group_title' => esc_html__( 'Digest', 'leco-cp' ),
				),
				'show_on_cb' => array( leco_cp_settings(), 'get_active_section' ),
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id,
			array(
				'name' => esc_html__( 'Digest Configuration', 'leco-cp' ),
				'desc' => sprintf( esc_html__( 'Send notifications as daily or weekly digests. %1$sYou have to select recipients to receive digests in each event\'s settings%2$s.', 'leco-cp' ), '<strong>', '</strong>' ),
				'id'   => 'title',
				'type' => 'title',
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id,
			array(
				'name'    => esc_html__( 'Schedule on Day', 'leco-cp' ),
				'desc'    => esc_html__( 'Send notifications in a digest email on the selected day.', 'leco-cp' ),
				'id'      => 'schedule_on_day',
				'type'    => 'select',
				'options' => array(
					'none' => esc_html__( 'None', 'leco-cp' ),
					'*'    => esc_html__( 'Everyday', 'leco-cp' ),
					'1'    => esc_html__( 'Monday', 'leco-cp' ),
					'2'    => esc_html__( 'Tuesday', 'leco-cp' ),
					'3'    => esc_html__( 'Wednesday', 'leco-cp' ),
					'4'    => esc_html__( 'Thursday', 'leco-cp' ),
					'5'    => esc_html__( 'Friday', 'leco-cp' ),
					'6'    => esc_html__( 'Saturday', 'leco-cp' ),
					'7'    => esc_html__( 'Sunday', 'leco-cp' ),
				),
				'default' => 'everyday',
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id,
			array(
				'name'        => esc_html__( 'Schedule on Time', 'leco-cp' ),
				'desc'        => esc_html__( 'Select the time for the digest to be sent.', 'leco-cp' ),
				'id'          => 'schedule_on_time',
				'type'        => 'text_time',
				'time_format' => 'H:i', // Set to 24hr format.
				'default'     => '00:00',
			)
		);

		$this->add_email_fields();

	}

	/**
	 * Return the group field ID.
	 *
	 * @since 4.15
	 *
	 * @return string
	 */
	public function group_field_id() {
		return $this->group_field_id;
	}

	/**
	 * Return defaults for some fields.
	 *
	 * @since 4.15
	 *
	 * @return array
	 */
	public static function defaults() {

		return array(
			'subject' => esc_html__( 'Client Portal - Latest activity', 'leco-cp' ),
			'content' => 'Howdy,

Here\'s the latest activity from Client Portal on {sitename}:

{latest_activity}

Regards,
All at {sitename}
{siteurl}',
		);

	}

	/**
	 * Add email related settings fields.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	private function add_email_fields() {

		$this->cmb->add_group_field(
			$this->group_field_id(),
			array(
				'name'          => '',
				'id'            => 'preview-digest',
				'action'        => 'preview-digest',
				'type'          => 'button',
				'render_row_cb' => array( leco_cp_settings(), 'render_row_cb_actions' ),
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id(),
			array(
				'name'    => esc_html__( 'Email Subject', 'leco-cp' ),
				'desc'    => esc_html__( 'The email subject of this notification.', 'leco-cp' ),
				'id'      => 'subject',
				'type'    => 'text',
				'default' => $this->defaults()['subject'],
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id(),
			array(
				'name'    => esc_html__( 'Email Content', 'leco-cp' ),
				'desc'    => sprintf( esc_html__( 'The email content of this notification. Supported template tags:
		%1$s%2$s{sitename}%3$s - the name of the website.
		%1$s%2$s{siteurl}%3$s - the URL of the website.
		%1$s%2$s{login_url}%3$s - the login URL of the website.
		%1$s%2$s{username}%3$s - the CP Client account\'s username, required for logged in.
		%1$s%2$s{first_name}%3$s or %2$s{name}%3$s - the recipient\'s first name.
		%1$s%2$s{last_name}%3$s - the recipient\'s last name.
		%1$s%2$s{latest_activity}%3$s - latest activity from notification events.', 'leco-cp' ), '<br />', '<code>', '</code>' ),
				'id'      => 'content',
				'type'    => 'wysiwyg',
				'default' => $this->defaults()['content'],
				'options' => array(
					'textarea_rows' => 10,
				),
			)
		);

	}

	/**
	 * Get the scheduled events options.
	 *
	 * @since 4.15
	 *
	 * @return array The scheduled events options.
	 */
	private function get_scheduled_events_options() {

		$options = array();

		foreach ( leco_client_portal()->notifications()->get_all() as $notification ) {

			foreach ( $notification->settings()->recipients_options() as $k => $recipient ) {
				$options[ $notification->event() . "_$k" ] = $notification->name() . " - $recipient";
			}
		}

		return $options;

	}

}
