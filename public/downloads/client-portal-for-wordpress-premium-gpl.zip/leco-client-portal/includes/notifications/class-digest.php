<?php
/**
 * Processing notification digest.
 *
 * @since      4.15
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2022, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications;

use LECO\Client_Portal\Project;
use ActionScheduler_Action;
use ActionScheduler;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LECO CP Digest object.
 *
 * @since 4.15
 */
final class Digest {

	/**
	 * Send notification digest.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	public function send() {

		$actions = $this->get_actions();

		if ( empty( $actions ) ) {
			return;
		}

		$this->send_admin_digest( $actions );

		$actions_for_client = $this->get_actions_for_clients( $actions );

		if ( $actions_for_client ) {
			$this->send_client_digest( $actions_for_client );
		}

		$store           = ActionScheduler::store();
		$deleted_actions = array();
		foreach ( $actions as $recipient_actions ) {
			foreach ( $recipient_actions as $action_id => $action ) {
				$is_reminder = $this->get_event( $action->get_hook() ) === 'module_due';
				if ( $is_reminder ) {
					$args = $action->get_args();

					$due_date = Project::get_module_due_date( $args[0], $args[1], $args[2] );
					if ( $due_date <= 0 ) {
						$is_reminder = false;
					}
				}

				if ( ! in_array( $action_id, $deleted_actions ) && ! $is_reminder ) {
					$store->delete_action( $action_id );
					$deleted_actions[] = $action_id;
				}
			}
		}

	}

	/**
	 * Send admin digest.
	 *
	 * @since 4.15
	 *
	 * @param array $actions The AS actions.
	 *
	 * @return void
	 */
	private function send_admin_digest( $actions ) {

		if ( ! isset( $actions['admin'] ) ) {
			return;
		}

		$latest_activity = $this->get_latest_activity( $actions['admin'] );
		if ( empty( $latest_activity ) ) {
			return;
		}

		/**
		 * Filter the notification digest subject.
		 *
		 * @since 4.15
		 *
		 * @param string
		 */
		$subject = apply_filters( 'leco_cp_admin_digest_subject', leco_cp_settings()->get_notification( 'digest', '', 'subject' ) );

		$admin_email = apply_filters( 'leco_cp_admin_digest_email', get_option( 'admin_email' ) );

		$email_data = array(
			'admin_email'     => $admin_email,
			'latest_activity' => $latest_activity,
		);

		/**
		 * Filters the body of the digest email.
		 *
		 * @since 4.15
		 *
		 * @param string $email_text Text in the email.
		 * @param array  $email_data .
		 */
		$content = apply_filters( 'leco_cp_send_admin_digest_content', leco_cp_settings()->get_notification( 'digest', '', 'content' ), $email_data );

		$emails = leco_client_portal()->emails;

		$emails->__set( 'data', $email_data );
		$emails->send( $email_data['admin_email'], $subject, $content );

	}

	/**
	 * Send admin digest.
	 *
	 * @since 4.15
	 *
	 * @param array $actions The AS actions.
	 *
	 * @return void
	 */
	private function send_client_digest( $actions ) {

		/**
		 * Filter the notification digest subject.
		 *
		 * @since 4.15
		 *
		 * @param string
		 */
		$subject = apply_filters( 'leco_cp_client_digest_subject', leco_cp_settings()->get_notification( 'digest', '', 'subject' ) );

		foreach ( $actions as $user_id => $user_actions ) {

			$latest_activity = $this->get_latest_activity( $user_actions, 'client' );
			if ( empty( $latest_activity ) ) {
				continue;
			}

			$email_data = array(
				'latest_activity' => $latest_activity,
			);
			$user       = get_user_by( 'id', $user_id );

			/**
			 * Filters the body of the digest email.
			 *
			 * @since 4.15
			 *
			 * @param string $email_text Text in the email.
			 * @param array  $email_data .
			 */
			$content = apply_filters( 'leco_cp_send_client_digest_content', leco_cp_settings()->get_notification( 'digest', '', 'content' ), $email_data );

			$emails = leco_client_portal()->emails;

			$emails->__set( 'data', $email_data );
			$emails->__set( 'user', $user );

			$emails->send( $user->user_email, $subject, $content );

		}

	}

	/**
	 * Get all queued actions from Action Scheduler.
	 *
	 * @since 4.15
	 *
	 * @return array
	 */
	private function get_actions() {

		$actions = array(
			'admin'        => array(),
			'client'       => array(),
			'no_recipient' => array(),
		);

		// The scheduled actions would be "failed" as there was no action run for those hooks.
		$scheduled_actions = as_get_scheduled_actions(
			array(
				'group'  => 'leco-client-portal',
				'order'  => 'DESC',
				'status' => 'failed',
			)
		);

		foreach ( $scheduled_actions as $action_id => $action ) {

			if ( 'leco_cp_notification_digest_cron' === $action->get_hook() ) {
				continue;
			}

			$args = $action->get_args();
			if ( ! Project::is_valid( $args[0] ) ) {
				continue;
			}

			/**
			 * The AS Action.
			 *
			 * @var ActionScheduler_Action $action
			 */
			$event = $this->get_event( $action->get_hook() );

			if ( 'module_due' === $event ) {
				$event = 'reminder';
			}

			$recipients = leco_cp_settings()->get_notification( $event, array(), 'digest_recipients' );
			if ( ! $recipients ) {
				$actions['no_recipient'][ $action_id ] = $action;

				continue;
			}

			foreach ( $recipients as $recipient ) {

				$actions[ $recipient ][ $action_id ] = $action;

			}

		}

		return array_filter( $actions );

	}

	/**
	 * Sort the actions for clients.
	 *
	 * @since 4.15
	 *
	 * @param array $actions The queued actions.
	 *
	 * @return array
	 */
	private function get_actions_for_clients( $actions ) {

		if ( ! isset( $actions['client'] ) ) {
			return array();
		}

		$notifications = array();

		foreach ( $actions['client'] as $action_id => $action ) {

			/**
			 * The AS Action.
			 *
			 * @var ActionScheduler_Action $action
			 */
			$event = $this->get_event( $action->get_hook() );
			$args  = $action->get_args();

			switch ( $event ) {

				case 'project_created':
					$notifications[ $args[1] ][ $action_id ] = $action;

					break;

				case 'module_activated':
				case 'module_completed':
				case 'module_due_date_reminder_set':
					$project_id = $args[0];

					$client_id = get_post_meta( $project_id, 'leco_cp_client', true );

					if ( leco_cp_is_public_portal( $project_id ) ) {
						continue 2;
					}

					if ( is_string( $client_id ) ) {
						$client_id = array( $client_id );
					}

					foreach ( $client_id as $user_id ) {
						$notifications[ $user_id ][ $action_id ] = $action;
					}

					break;

			}

		}

		return $notifications;

	}

	/**
	 * Get the history of project created actions.
	 *
	 * @since 4.15
	 *
	 * @param array  $actions The queued actions.
	 * @param string $type    The recipient type.
	 *
	 * @return string
	 */
	private function get_latest_activity( $actions, $type = 'admin' ) {

		$activity = array();

		foreach ( $actions as $action ) {

			$activity[] = $this->get_activity( $action, $type );

		}

		$activity = array_filter( $activity );

		if ( empty( $activity ) ) {
			return '';
		}

		return sprintf( '<ul><li>%1$s</li></ul>', implode( '</li><li>', $activity ) );

	}

	/**
	 * Get the notification event name from a hook name.
	 *
	 * @since 4.15
	 *
	 * @param string $hook The hook name.
	 *
	 * @return string
	 */
	private function get_event( $hook ) {

		$arr = explode( '_', $hook );

		$event = implode( '_', array_slice( $arr, 2, 2 ) );

		return 'registered_user' === $event ? 'client_created' : $event;

	}

	/**
	 * Get the activity text.
	 *
	 * @since 4.15
	 *
	 * @param ActionScheduler_Action $action The AS Action.
	 * @param string                 $type   The recipient type.
	 *
	 * @return string
	 */
	private function get_activity( $action, $type = 'admin' ) {

		$event = $this->get_event( $action->get_hook() );
		$args  = $action->get_args();

		switch ( $event ) {

			case 'client_created':
				if ( 'admin' !== $type ) {
					return '';
				}

				$user = get_user_by( 'id', $args[0] );

				return sprintf( esc_html__( 'User %1$s has been created.', 'leco-cp' ), $user->display_name );

			case 'project_created':
				$project_title = get_the_title( $args[0] );
				$project_url   = Project::get_project_url( $args[0], 'admin' );

				$user_text = '';
				if ( 'admin' === $type ) {
					$user      = get_user_by( 'id', $args[1] );
					$user_text = sprintf( esc_html__( ' for %s', 'leco-cp' ), $user->display_name );
				}

				return sprintf( esc_html__( 'Project %1$s%2$s%3$s has been created%4$s.', 'leco-cp' ), sprintf( '<a href="%s">', $project_url ), $project_title, '</a>', $user_text );

			case 'module_activated':
			case 'module_completed':
			case 'client_uploaded':
			case 'module_due':
				$project_title = get_the_title( $args[0] );
				$project_url   = Project::get_project_url( $args[0], 'admin' );
				$phase_title   = Project::get_phase_title( $args[0], $args[1] );
				$module_title  = Project::get_module( $args[0], $args[1], $args[2],
				'title');

				if ( 'module_activated' === $event || 'module_completed' === $event ) {
					$action_text = 'module_activated' === $event ? esc_html__( 'activated', 'leco-cp' ) : esc_html__( 'marked as completed', 'leco-cp' );

					return sprintf( esc_html__( 'Module "%1$s" in "Phase %2$s - %3$s, %4$s%5$s%6$s" has been %7$s.', 'leco-cp' ), $module_title, ( $args[1] + 1 ), $phase_title, sprintf( '<a href="%s">', $project_url ), $project_title, '</a>', $action_text );
				}

				if ( 'client_uploaded' === $event ) {
					if ( 'admin' !== $type ) {
						return '';
					}

					return sprintf( esc_html__( 'Client has changed files in Module "%1$s" in "Phase %2$s - %3$s, %4$s%5$s%6$s".', 'leco-cp' ), $module_title, ( $args[1] + 1 ), $phase_title, sprintf( '<a href="%s">', $project_url ), $project_title, '</a>' );
				}

				$modules = get_post_meta( $args[0], "leco_cp_part_{$args[1]}_module", true );
				if ( isset( $modules[ $args[2] ] ) && 'active' !== $modules[ $args[2] ]['status'] ) {
					return '';
				}

				$due_date = Project::get_module_due_date( $args[0], $args[1], $args[2] );
				if ( $due_date <= 0 || $due_date > time() + DAY_IN_SECONDS * 30 ) {
					return '';
				}

				$due_date = Project::get_module_due_date( $args[0], $args[1], $args[2], true );

				return sprintf( esc_html__( 'Module "%1$s" in "Phase %2$s - %3$s, %4$s%5$s%6$s" will be due on %7$s.', 'leco-cp' ), $module_title, ( $args[1] + 1 ), $phase_title, sprintf( '<a href="%s">', $project_url ), $project_title, '</a>', $due_date );

		}

		return '';

	}

}
