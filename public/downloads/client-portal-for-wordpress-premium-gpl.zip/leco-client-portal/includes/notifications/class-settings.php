<?php
/**
 * Notifications Settings.
 *
 * This class defines notifications settings in Client Portal.
 *
 * @since      4.15
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2022, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use CMB2;
use LECO\Client_Portal\Notifications;
use LECO\Client_Portal\Notifications\Digest\Settings as Digest_Settings;
use LECO\Client_Portal\Notifications\Reminder\Settings as Reminder_Settings;
use Webmozart\Assert\Assert;

/**
 * LECO CP Notifications Settings class.
 *
 * @since 4.15
 */
class Settings {

	/**
	 * The CMB2 instance.
	 *
	 * @since 4.15
	 *
	 * @var CMB2
	 */
	private $cmb;

	/**
	 * The notification settings.
	 *
	 * @since 4.15
	 *
	 * @var Notification\Settings[]
	 */
	private $settings;

	/**
	 * Notifications.
	 *
	 * @since 4.15
	 *
	 * @var Notifications
	 */
	private $notifications;

	/**
	 * The field groups.
	 *
	 * It uses the event key as its key, and field group ID as its value.
	 *
	 * @since 4.15
	 *
	 * @var array
	 */
	private $groups;

	/**
	 * The current event to create notification fields.
	 *
	 * @since 4.15
	 *
	 * @var string
	 */
	private $current_event;

	/**
	 * Constructor.
	 *
	 * @since 4.15
	 *
	 * @param Notifications $notifications The notifications object.
	 */
	public function __construct( &$notifications ) {

		$this->notifications = &$notifications;
		$events              = $notifications->get_events();

		$this->settings = [
			new Notification\Settings(
				[
					'description'            => esc_html__( 'You can send a notification to the newly created CP Client and let them set up their login password.', 'leco-cp' ),
					'recipients_description' => sprintf( esc_html__( 'Check "Clients" if you would like new users registered from the %1$s[client_portal_login]%2$s shortcode or the Client Portal Login Form block receive the notification.', 'leco-cp' ), '<code>', '</code>' ),
					'recipients_options'     => $this->get_recipients_options(),
					'defaults'               => [
						'subject'           => esc_html__( 'Client Portal - Your account has been created', 'leco-cp' ),
						'content'           => $this->get_default_email_content( $events[0] ),
						'recipients'        => array( 'admin', 'client' ),
						'digest_recipients' => array(),
					],
				]
			),
			new Notification\Settings(
				[
					'description'            => esc_html__( 'Notifications will be sent to the clients when they are assigned to a project.', 'leco-cp' ),
					'recipients_description' => esc_html__( 'Select "Clients" if you would like to send this notification.', 'leco-cp' ),
					'recipients_options'     => $this->get_recipients_options( [ 'client' ] ),
					'defaults'               => [
						'subject'           => esc_html__( 'Client Portal - New Project "{project}" has been created', 'leco-cp' ),
						'content'           => $this->get_default_email_content( $events[1] ),
						'recipients'        => array( 'client' ),
						'digest_recipients' => array(),
					],
				]
			),
			new Notification\Settings(
				[
					'description'            => esc_html__( 'Notifications will be sent when a module is activated in the project.', 'leco-cp' ),
					'recipients_description' => esc_html__( 'Select "Clients" if you would like to enable this notification. Clients will only get notifications if the module is marked active by the admin.', 'leco-cp' ),
					'recipients_options'     => $this->get_recipients_options( [ 'client' ] ),
					'defaults'               => [
						'subject'           => esc_html__( 'Client Portal - Module "{module}" is Activated', 'leco-cp' ),
						'content'           => $this->get_default_email_content( $events[2] ),
						'recipients'        => array( 'client' ),
						'digest_recipients' => array(),
					],
				]
			),
			new Notification\Settings(
				[
					'description'            => esc_html__( 'Notifications will be sent when a module is completed in the project.', 'leco-cp' ),
					'recipients_description' => esc_html__( 'Select the email recipients.', 'leco-cp' ),
					'recipients_options'     => $this->get_recipients_options(),
					'defaults'               => [
						'subject'           => esc_html__( 'Client Portal - Module "{module}" Marked As Completed', 'leco-cp' ),
						'content'           => $this->get_default_email_content( $events[3] ),
						'recipients'        => array( 'admin', 'client' ),
						'digest_recipients' => array(),
					],
				]
			),
			new Notification\Settings(
				[
					'description'            => esc_html__( 'Notifications will be sent when client uploaded files are changed (uploaded or deleted) to the portal.', 'leco-cp' ) . '<br />' . esc_html__( 'The notification will be sent after 10 minutes of the last edit (add or delete files).', 'leco-cp' ),
					'recipients_description' => esc_html__( 'Select the email recipients.', 'leco-cp' ),
					'recipients_options'     => $this->get_recipients_options( [ 'admin' ] ),
					'defaults'               => [
						'subject'           => esc_html__( 'Client Portal - Your Client has changed some files', 'leco-cp' ),
						'content'           => $this->get_default_email_content( $events[4] ),
						'recipients'        => array( 'admin' ),
						'digest_recipients' => array(),
					],
				]
			),
		];

		foreach ( $this->notifications->get_all() as $index => $notification ) {

			$notification->add_settings( $this->settings[ $index ] );

		}

	}

	/**
	 * Add all the settings fields.
	 *
	 * @since 4.15
	 *
	 * @param CMB2 $cmb The CMB2 instance.
	 *
	 * @return void
	 */
	public function add_groups( $cmb ) {

		$this->cmb = $cmb;

		new Digest_Settings( $this->cmb );
		new Reminder_Settings( $this->cmb );

		foreach ( $this->notifications->get_all() as $notification ) {
			$this->groups[ $notification->event() ] = $this->add_group( $notification->event() );

			$this->add_fields();
		}

	}

	/**
	 * Add the CMB settings group field.
	 *
	 * @since 4.15
	 *
	 * @param string $event The event key.
	 *
	 * @return false|string The field group ID.
	 */
	private function add_group( $event ) {

		$this->current_event = $event;
		$notification        = $this->get_notification( $event );

		if ( ! $notification ) {
			return false;
		}

		return $this->cmb->add_field(
			array(
				'id'         => $event,
				'desc'       => $notification->settings()->description(),
				'type'       => 'group',
				'repeatable' => false,
				'options'    => array(
					'group_title' => $notification->name(),
				),
				'show_on_cb' => array( leco_cp_settings(), 'get_active_section' ),
			)
		);

	}

	/**
	 * Get the notification by its event.
	 *
	 * @since 4.15
	 *
	 * @param string $event The notification event.
	 *
	 * @return false|Notification
	 */
	private function get_notification( $event ) {

		foreach ( $this->notifications->get_all() as $notification ) {
			if ( $notification->event() === $event ) {
				return $notification;
			}
		}

		return false;

	}

	/**
	 * Add settings fields to the current group.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	private function add_fields() {

		$this->add_buttons();
		$this->add_subject_field();
		$this->add_content_field();
		$this->add_recipients_field();
		$this->add_digest_recipients_field();

	}

	/**
	 * Add buttons.
	 *
	 * @return void
	 */
	private function add_buttons() {

		Assert::NotNull( $this->current_event );

		$this->cmb->add_group_field(
			$this->groups[ $this->current_event ],
			array(
				'name'          => '',
				'id'            => "preview-$this->current_event",
				'action'        => "preview-$this->current_event",
				'type'          => 'button',
				'render_row_cb' => array( leco_cp_settings(), 'render_row_cb_actions' ),
			)
		);

	}

	/**
	 * Add the subject field.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	private function add_subject_field() {

		Assert::NotNull( $this->current_event );

		$this->cmb->add_group_field(
			$this->groups[ $this->current_event ],
			array(
				'name'    => esc_html__( 'Email Subject', 'leco-cp' ),
				'desc'    => esc_html__( 'The email subject of this notification.', 'leco-cp' ),
				'id'      => 'subject',
				'type'    => 'text',
				'default' => leco_cp_settings()->get_defaults( 'notifications', $this->current_event, 'subject' ),
			)
		);

	}

	/**
	 * Add the content field.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	private function add_content_field() {

		Assert::NotNull( $this->current_event );

		$this->cmb->add_group_field(
			$this->groups[ $this->current_event ],
			array(
				'name'    => esc_html__( 'Email Content', 'leco-cp' ),
				'desc'    => leco_cp_settings()->get_email_content_description(),
				'id'      => 'content',
				'type'    => 'wysiwyg',
				'default' => leco_cp_settings()->get_defaults( 'notifications', $this->current_event, 'content' ),
				'options' => array(
					'textarea_rows' => 10,
				),
			)
		);

	}

	/**
	 * Get the recipients options.
	 *
	 * @since 4.15
	 *
	 * @param array $include_options Specify the options to include.
	 *
	 * @return array
	 */
	private function get_recipients_options( $include_options = [] ) {

		$options = [
			'admin'  => esc_html__( 'Administration Email Address', 'leco-cp' ),
			'client' => esc_html__( 'Clients', 'leco-cp' ),
		];

		if ( ! $include_options ) {
			return $options;
		}

		return array_filter( $options, function ( $key ) use ( $include_options ) {
			return in_array( $key, $include_options, true );
		}, ARRAY_FILTER_USE_KEY );

	}

	/**
	 * Add the recipients field.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	private function add_recipients_field() {

		Assert::NotNull( $this->current_event );

		$notification = $this->get_notification( $this->current_event );

		Assert::notFalse( $notification );

		$option_exists = get_option( 'leco_cp_options_notifications' );

		// When none option is checked in a multicheck field, it will load the default which causes buggy results.
		$args = array(
			'name'     => esc_html__( 'Real-time Recipient(s)', 'leco-cp' ),
			/* translators: 1. Open code tag 2. Close code tag */
			'desc'     => $notification->settings()->recipients_description(),
			'id'       => 'recipients',
			'type'     => 'multicheck',
			'multiple' => true, // Store values in individual rows.
			'options'  => $notification->settings()->recipients_options(),
		);
		if ( empty( $_POST['submit-cmb'] ) ) { // phpcs:ignore.
			$recipients      = leco_cp_settings()->get_notification( $this->current_event, array(), 'recipients' );
			$args['default'] = isset( $option_exists[ $this->current_event ] ) ? $recipients : array_keys( $args['options'] );
		}

		$this->cmb->add_group_field(
			$this->groups[ $this->current_event ],
			$args
		);

	}

	/**
	 * Add the digest recipients field.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	private function add_digest_recipients_field() {

		Assert::NotNull( $this->current_event );

		$notification = $this->get_notification( $this->current_event );

		Assert::notFalse( $notification );

		$option_exists = get_option( 'leco_cp_options_notifications' );

		// It doesn't make sense to send Client Created notification to the Client as digest, remove it.
		$recipients = $notification->settings()->recipients_options();
		if ( $this->current_event === 'client_created' ) {
			unset( $recipients['client'] );
		} elseif ( $this->current_event === 'project_created' ) {
			$recipients = $this->get_recipients_options( [ 'admin', 'client' ] );
		}

		// When none option is checked in a multicheck field, it will load the default which causes buggy results.
		$args = array(
			'name'     => esc_html__( 'Digest Recipient(s)', 'leco-cp' ),
			/* translators: 1. Open code tag 2. Close code tag */
			'desc'     => esc_html__( 'Select the recipient(s) to receive digest emails.', 'leco-cp' ),
			'id'       => 'digest_recipients',
			'type'     => 'multicheck',
			'multiple' => true, // Store values in individual rows.
			'options'  => $recipients,
			'default'  => leco_cp_settings()->get_notification( $this->current_event, array(), 'digest_recipients' ),
		);

		$this->cmb->add_group_field(
			$this->groups[ $this->current_event ],
			$args
		);

	}

	/**
	 * Get the default email content.
	 *
	 * @since 4.15
	 *
	 * @param string $event The event key.
	 *
	 * @return string
	 */
	private function get_default_email_content( $event ) {

		switch ( $event ) {
			case 'client_created':
				return 'Howdy,
		
Your account {username} has been created on {sitename}, please go ahead and set up your password here:

{set_password_url}

You can log in and access your projects once you\'re ready: {login_url}.

Regards,
All at {sitename}
{siteurl}';
			case 'project_created':
				return 'Howdy,

A new project "{project}" has been created for you on {sitename},

You can view this project here:

{project_url}

Regards,
All at {sitename}
{siteurl}';
			case 'module_activated':
				return 'Howdy,

A module has been activated in your Client Portal on {sitename}:

Project: {project}
Phase: {phase}
Module: {module}

You can view this project here:

{project_url}

Regards,
All at {sitename}
{siteurl}';
			case 'module_completed':
				return 'Howdy,

A module has been marked as completed in your Client Portal on {sitename}:

Project: {project}
Phase: {phase}
Module: {module}

You can view and manage this project here:

{project_admin_url}

Regards,
All at {sitename}
{siteurl}';
			case 'client_uploaded':
				return 'Howdy,

Your client has changed some files to the Client Portal on {sitename}:

Project: {project}
Phase: {phase}
Module: {module}

The client uploads:
{file_list}

You can view and manage this project here:

{project_admin_url}

Regards,
All at {sitename}
{siteurl}';

		}

		return '';

	}

}
