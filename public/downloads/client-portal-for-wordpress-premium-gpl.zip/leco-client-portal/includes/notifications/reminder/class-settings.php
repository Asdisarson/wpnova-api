<?php
/**
 * Notification Reminder Settings.
 *
 * Defines a Notification Reminder Settings object in Client Portal.
 *
 * @since      4.16
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2023, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications\Reminder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use CMB2;

/**
 * LECO CP Notification Reminder Settings object.
 *
 * @since 4.16
 */
final class Settings {

	/**
	 * The cmb2 object.
	 *
	 * @since 4.16
	 *
	 * @var CMB2
	 */
	private $cmb;

	/**
	 * The group field id for the Reminder settings.
	 *
	 * @since 4.16
	 *
	 * @var string
	 */
	private $group_field_id;

	/**
	 * Create Reminder Settings.
	 *
	 * @since 4.16
	 *
	 * @param CMB2 $cmb The CMB2 object.
	 */
	public function __construct( $cmb ) {

		$this->cmb = $cmb;

		$this->group_field_id = $this->cmb->add_field(
			array(
				'id'         => 'reminder',
				'desc'       => esc_html__( 'Reminder settings for notifications.', 'leco-cp' ),
				'type'       => 'group',
				'repeatable' => false,
				'options'    => array(
					'group_title' => esc_html__( 'Reminder', 'leco-cp' ),
				),
				'show_on_cb' => array( leco_cp_settings(), 'get_active_section' ),
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id,
			array(
				'name'    => esc_html__( 'Send Before Due Date', 'leco-cp' ),
				'desc'    => esc_html__( 'By default, the reminder will be sent 1 day before the due date. This setting is used to change the default value in each Project.', 'leco-cp' ),
				'id'      => 'send_before_due_date',
				'type'    => 'select',
				'options' => array(
					'0'  => 'None',
					'1'  => '1 Hour before',
					'2'  => '2 Hours before',
					'12' => '12 Hours before',
					'24' => '1 Day before',
					'48' => '2 Days before',
				),
				'default' => '24',
			)
		);

		$this->add_email_fields();

	}

	/**
	 * Return the group field ID.
	 *
	 * @since 4.16
	 *
	 * @return string
	 */
	public function group_field_id() {
		return $this->group_field_id;
	}

	/**
	 * Return defaults for some fields.
	 *
	 * @since 4.16
	 *
	 * @return array
	 */
	public static function defaults() {

		return array(
			'send_before_due_date' => '24',
			'subject'              => esc_html__( 'Client Portal - Module "{module}" Will Be Due Soon', 'leco-cp' ),
			'content'              => 'Howdy,

A module will be due on {module_due_date} in your Client Portal on {sitename}:

Project: {project}
Phase: {phase}
Module: {module}

Please mark it as completed before it\'s due. You can visit the project at: {project_admin_url}

Regards,
All at {sitename}
{siteurl}',
			'recipients'           => array( 'admin', 'client' ),
			'digest_recipients'    => array( 'admin', 'client' ),
		);

	}

	/**
	 * Add email related settings fields.
	 *
	 * @since 4.16
	 *
	 * @return void
	 */
	private function add_email_fields() {

		$this->cmb->add_group_field(
			$this->group_field_id(),
			array(
				'name'          => '',
				'id'            => 'preview-reminder',
				'action'        => 'preview-reminder',
				'type'          => 'button',
				'render_row_cb' => array( leco_cp_settings(), 'render_row_cb_actions' ),
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id(),
			array(
				'name'    => esc_html__( 'Email Subject', 'leco-cp' ),
				'desc'    => esc_html__( 'The email subject of this notification.', 'leco-cp' ),
				'id'      => 'subject',
				'type'    => 'text',
				'default' => $this->defaults()['subject'],
			)
		);

		$this->cmb->add_group_field(
			$this->group_field_id(),
			array(
				'name'    => esc_html__( 'Email Content', 'leco-cp' ),
				'desc'    => sprintf( esc_html__( 'The email content of this notification. Supported template tags:
		%1$s%2$s{sitename}%3$s - the name of the website.
		%1$s%2$s{siteurl}%3$s - the URL of the website.
		%1$s%2$s{login_url}%3$s - the login URL of the website.
		%1$s%2$s{project_admin_url}%3$s - the project admin URL in your WP Dashboard. It will be replaced with {project_url} when the notification is sent to clients.
		%1$s%2$s{username}%3$s - the CP Client account\'s username, required for logged in.
		%1$s%2$s{first_name}%3$s or %2$s{name}%3$s - the recipient\'s first name.
		%1$s%2$s{last_name}%3$s - the recipient\'s last name.
		%1$s%2$s{module_due_date}%3$s - the due date of a module.', 'leco-cp' ), '<br />', '<code>', '</code>' ),
				'id'      => 'content',
				'type'    => 'wysiwyg',
				'default' => $this->defaults()['content'],
				'options' => array(
					'textarea_rows' => 10,
				),
			)
		);

		$option_exists = get_option( 'leco_cp_options_notifications' );

		// When none option is checked in a multicheck field, it will load the default which causes buggy results.
		$args = array(
			'name'     => esc_html__( 'Reminder Recipient(s)', 'leco-cp' ),
			'desc'     => esc_html__( 'Select the recipient(s) of the due date reminders.', 'leco-cp' ),
			'id'       => 'recipients',
			'type'     => 'multicheck',
			'multiple' => true, // Store values in individual rows.
			'options'  => array(
				'admin'  => esc_html__( 'Administration Email Address', 'leco-cp' ),
				'client' => esc_html__( 'Clients', 'leco-cp' ),
			),
		);
		if ( empty( $_POST['submit-cmb'] ) ) { // phpcs:ignore.
			$recipients      = leco_cp_settings()->get_notification( 'reminder', array(), 'recipients' );
			$args['default'] = isset( $option_exists['reminder'] ) ? $recipients : array_keys( $args['options'] );
		}

		$this->cmb->add_group_field(
			$this->group_field_id(),
			$args
		);

		$args['name'] = esc_html__( 'Digest Recipient(s)', 'leco-cp' );
		$args['id']   = 'digest_recipients';
		$args['desc'] = esc_html__( 'Select the recipient(s) to receive digest emails.', 'leco-cp' );
		if ( empty( $_POST['submit-cmb'] ) ) { // phpcs:ignore.
			$recipients      = leco_cp_settings()->get_notification( 'reminder', array(), 'digest_recipients' );
			$args['default'] = isset( $option_exists['reminder'] ) ? $recipients : array_keys( $args['options'] );
		}

		$this->cmb->add_group_field(
			$this->group_field_id(),
			$args
		);

	}

}
