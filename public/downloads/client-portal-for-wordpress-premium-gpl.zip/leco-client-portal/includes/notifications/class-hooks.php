<?php
/**
 * Notification Hooks.
 *
 * Defines Notification Hooks object in Client Portal.
 *
 * @since      4.15
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2022, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LECO\Client_Portal\Project;
use WP_User;

/**
 * LECO CP Notification Hooks object.
 *
 * @since 4.15
 */
final class Hooks {

	/**
	 * The digest processor.
	 *
	 * @since 4.15
	 *
	 * @var Digest
	 */
	private $digest;

	/**
	 * The reminder object.
	 *
	 * @since 4.16
	 *
	 * @var Reminder
	 */
	private $reminder;

	/**
	 * Add hooks.
	 *
	 * @since 4.15
	 */
	public function __construct() {

		$this->digest   = new Digest();
		$this->reminder = new Reminder();

		// AJAX hooks.
		add_action( 'wp_ajax_leco_cp_mark_as_complete', array( $this, 'mark_as' ) );
		add_action( 'wp_ajax_leco_cp_mark_as_active', array( $this, 'mark_as' ) );

		// Client created notification.
		add_action( 'leco_cp_registered_user', array( $this, 'add_to_digest_queue' ) );
		add_action( 'leco_cp_registered_user', array( $this, 'maybe_send_new_user_notifications' ) );
		add_action( 'wpmu_new_user', array( $this, 'send_client_new_user_notification' ) );

		add_action( 'leco_cp_project_created', array( $this, 'add_to_digest_queue' ), 10, 2 );
		add_action( 'leco_cp_project_created', array( $this, 'send_project_created_notification' ), 10, 2 );
		add_action( 'leco_cp_module_activated', array( $this, 'add_to_digest_queue' ), 10, 3 );
		add_action( 'leco_cp_module_activated', array( $this, 'send_module_activated_notification' ), 10, 3 );
		add_action( 'leco_cp_module_completed', array( $this, 'add_to_digest_queue' ), 10, 3 );
		add_action( 'leco_cp_module_completed', array( $this, 'send_module_completed_notification' ), 10, 3 );

		// Client uploads notification.
		add_action( 'leco_cp_client_uploaded', array( $this, 'add_to_digest_queue' ), 10, 4 );
		add_action( 'leco_cp_client_uploaded', array( $this, 'schedule_client_uploaded_notification' ), 10, 4 );
		add_action( 'leco_cp_client_uploaded_notification', array( $this, 'client_uploaded_notification' ), 10, 4 );

		// Sending the digest.
		add_action( 'leco_cp_notification_digest_cron', array( $this->digest, 'send' ) );

		// Schedule due date reminder.
		add_action( 'leco_cp_due_date_scheduler_updater', array( $this->reminder, 'schedule' ), 10, 3 );

		// Send the reminder.
		add_action( Reminder::SCHEDULER_HOOK, array( $this->reminder, 'send' ), 10, 3 );

		add_action( 'leco_cp_module_due_date_reminder_set', array( $this, 'add_to_digest_queue' ), 10, 3 );

	}

	/**
	 * AJAX helper function to send module activated/completed notifications.
	 *
	 * @since 4.9.0
	 * @since 4.15  Migrated to the Hooks class.
	 */
	public function mark_as() {

		$current_filter = explode( '_', current_filter() );
		$status         = end( $current_filter );

		switch ( $status ) {

			case 'complete':
				$status = 'completed';
				$event  = 'completed';
				break;

			case 'active':
				$event = 'activated';
				break;

		}

		check_ajax_referer( 'leco_cp_ajax_nonce' );

		extract( $_POST ); // phpcs:ignore.
		$post_id = intval( $post_id );

		if ( 'leco_client' !== get_post_type( $post_id ) ) {
			wp_die( esc_html__( 'Not a Client Portal project, bail out.', 'leco-cp' ) );
		}

		$phase = intval( $phase );
		$key   = intval( $key );

		if ( 'completed' === $status ) {
			-- $phase;
			-- $key;
		}

		// If the module status does not match, bail.
		$modules = $this->check_module_status( $post_id, $phase, $key, 'module_' . $event );

		/**
		 * Run custom actions when a module has been updated to the status.
		 *
		 * @since 4.15
		 *
		 * @param int $post_id Project ID.
		 * @param int $phase   Phase.
		 * @param int $key     The module.
		 */
		do_action( "leco_cp_module_$event", $post_id, $phase, $key );

		$modules[ $key ]['status'] = $status;
		update_post_meta( $post_id, "leco_cp_part_{$phase}_module", $modules );

		wp_die( $post_id ); // phpcs:ignore.

	}

	/**
	 * Add the data to the digest queue.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	public function add_to_digest_queue() {

		$event = str_replace( 'leco_cp_', '', current_filter() );
		$hook  = "leco_cp_{$event}_notification_digest";

		$scheduled_actions = as_get_scheduled_actions(
			array(
				'hook' => $hook,
				'args' => func_get_args(),
			)
		);

		if ( ! $scheduled_actions ) {
			as_schedule_single_action( time() + 10, $hook, func_get_args(), 'leco-client-portal' );
		}

	}

	/**
	 * Notify the clients that a module has been activated.
	 *
	 * @since 4.9
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $post_id Project ID.
	 * @param int $phase   Phase.
	 * @param int $module  Module.
	 *
	 * @return void
	 */
	public function send_module_activated_notification( $post_id, $phase, $module ) {

		$modules = Project::get_modules( $post_id, $phase );

		// Return if there's no recipients.
		$recipients = leco_cp_settings()->get_notification( 'module_activated', array(), 'recipients' );

		if ( ! $recipients || ! in_array( 'client', $recipients ) ) {
			return;
		}

		$subject     = leco_cp_settings()->get_notification( 'module_activated', '', 'subject' );
		$admin_email = apply_filters( 'leco_cp_admin_email_to', get_option( 'admin_email' ), $post_id, $phase, $module );

		$email_data = array(
			'post_id'           => $post_id,
			'modules'           => $modules,
			'phase'             => $phase,
			'module'            => $module,
			'project_admin_url' => Project::get_project_url( $post_id, 'admin' ),
			'project_url'       => Project::get_project_url( $post_id ),
			'admin_email'       => $admin_email,
		);

		$content = leco_cp_settings()->get_notification( 'module_activated', '', 'content' );

		$emails = leco_client_portal()->emails;

		$emails->__set( 'data', $email_data );

		$sent = $emails->send_to_client( $post_id, $subject, $content );

		if ( ! $sent ) {
			wp_die( esc_html__( 'The notification could not be sent. Please check your mail server.', 'leco-cp' ) );
		}

	}

	/**
	 * Notify the site administrator via email when a module marked as completed.
	 *
	 * Without this, the admin would have to manually check the site to see if any
	 * action was needed on their part yet.
	 *
	 * @since 4.3.0
	 * @since 4.9   Support notifications settings.
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $post_id Project ID.
	 * @param int $phase   Phase.
	 * @param int $module  Module.
	 *
	 * @return void True if email sent successfully, false otherwise.
	 */
	public function send_module_completed_notification( $post_id, $phase, $module ) {

		$modules = Project::get_modules( $post_id, $phase );

		$subject = leco_cp_settings()->get_notification( 'module_completed', '', 'subject' );
		$subject = apply_filters( 'leco_cp_send_admin_module_completed_subject', $subject, $post_id, $phase, $module );
		// Function name changed since 4.9.
		$subject = apply_filters( 'leco_cp_send_module_completed_subject', $subject, $post_id, $phase, $module );

		/**
		 * Filters the recipient of Client Portal admin notifications.
		 *
		 * In a Multisite environment, this will default to the email address of the
		 * network admin because, by default, single site admins do not have the
		 * capabilities required to process requests. Some networks may wish to
		 * delegate those capabilities to a single-site admin, or a dedicated person
		 * responsible for managing privacy requests.
		 *
		 * @since 4.3
		 *
		 * @param string $admin_email The email address of the notification recipient.
		 * @param int    $post_id     Post ID.
		 * @param int    $phase       Phase.
		 * @param int    $module      Module.
		 */
		$admin_email = apply_filters( 'leco_cp_admin_email_to', get_option( 'admin_email' ), $post_id, $phase, $module );

		$email_data = array(
			'post_id'           => $post_id,
			'modules'           => $modules,
			'phase'             => $phase,
			'module'            => $module,
			'project_admin_url' => Project::get_project_url( $post_id, 'admin' ),
			'project_url'       => Project::get_project_url( $post_id ),
			'admin_email'       => $admin_email,
		);

		$email_text = leco_cp_settings()->get_notification( 'module_completed', '', 'content' );

		/**
		 * Filters the body of the module marked as completed email.
		 *
		 * The email is sent to an administrator when a module marked as completed.
		 * The following strings have a special meaning and will get replaced dynamically:
		 *
		 * {sitename}          The name of the site.
		 * {project}           The project title.
		 * {phase}             The phase the module belongs to.
		 * {module}            The module.
		 * {project_admin_url} The URL to manage requests.
		 * {siteurl}           The URL to the site.
		 *
		 * @since 4.3
		 *
		 * @param string $email_text Text in the email.
		 * @param array  $email_data .
		 */
		$content = apply_filters( 'leco_cp_send_admin_module_completed_content', $email_text, $email_data );
		// Function name changed since 4.9.
		$content = apply_filters( 'leco_cp_send_module_completed_content', $content, $email_data );

		$emails = leco_client_portal()->emails;

		$emails->__set( 'data', $email_data );

		$recipients = leco_cp_settings()->get_notification( 'module_completed', array(), 'recipients' );
		$sent       = false;

		foreach ( $recipients as $recipient ) {
			if ( $recipient === 'admin' ) {
				$emails->__set( 'user', wp_get_current_user() );

				$sent = $emails->send( $email_data['admin_email'], $subject, $content );
			}

			if ( $recipient === 'client' ) {
				$sent = $emails->send_to_client( $post_id, $subject, $content );
			}
		}

		if ( $recipients && ! $sent ) {
			wp_die( -1 );
		}

	}

	/**
	 * Notify the clients that a new project is created.
	 *
	 * @since 4.9
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $post_id Project ID.
	 * @param int $user_id The client's user ID.
	 *
	 * @return void|bool True if email sent successfully, false otherwise.
	 */
	public function send_project_created_notification( $post_id, $user_id ) {
		// Return if there's no recipients.
		$recipients = leco_cp_settings()->get_notification( 'project_created', array(), 'recipients' );
		if ( empty( $recipients ) ) {
			return;
		}

		$subject     = leco_cp_settings()->get_notification( 'project_created', '', 'subject' );
		$admin_email = apply_filters( 'leco_cp_admin_email_to', get_option( 'admin_email' ), $post_id, '', '' );

		$email_data = array(
			'post_id'           => $post_id,
			'project_admin_url' => Project::get_project_url( $post_id, 'admin' ),
			'project_url'       => Project::get_project_url( $post_id ),
			'admin_email'       => $admin_email,
		);

		$content = leco_cp_settings()->get_notification( 'project_created', '', 'content' );

		$emails = leco_client_portal()->emails;

		$emails->__set( 'data', $email_data );

		$sent = false;

		if ( ! leco_cp_is_public_portal( $post_id ) ) {
			$content = str_replace( '{project_admin_url}', '{project_url}', $content );

			$client = get_user_by( 'id', $user_id );
			if ( isset( $client->user_email ) ) {
				$emails->__set( 'user', $client );

				$sent = $emails->send( $client->user_email, $subject, $content );
			}
		}

		return $sent;

	}

	/**
	 * Send new user notification if set.
	 *
	 * @since 4.12
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $user_id The user ID.
	 *
	 * @return void
	 */
	public function maybe_send_new_user_notifications( $user_id ) {

		$recipients = leco_cp_settings()->get_notification( 'client_created', array(), 'recipients' );
		if ( empty( $recipients ) ) {
			return;
		}

		if ( in_array( 'admin', $recipients ) ) {
			wp_send_new_user_notifications( $user_id, '' );
		}

		if ( in_array( 'client', $recipients ) ) {
			$this->send_client_new_user_notification( $user_id );
		}

	}

	/**
	 * Send new user notification to client.
	 *
	 * @since 4.14.3
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $user_id The user ID.
	 *
	 * @return void
	 */
	public function send_client_new_user_notification( $user_id ) {

		add_filter( 'allow_password_reset', '__return_true', 11 );
		wp_send_new_user_notifications( $user_id, 'user' );
		remove_filter( 'allow_password_reset', '__return_true', 11 );

	}

	/**
	 * Schedule the client upload notification.
	 *
	 * @since 4.9.6
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $post_id Project ID.
	 * @param int $phase   Phase.
	 * @param int $module  Module.
	 * @param int $user_id The user ID.
	 */
	public function schedule_client_uploaded_notification( $post_id, $phase, $module, $user_id ) {

		$cron_args = array( $post_id, $phase, $module, $user_id );

		if ( wp_next_scheduled( 'leco_cp_client_uploaded_notification', $cron_args ) ) {
			wp_clear_scheduled_hook( 'leco_cp_client_uploaded_notification', $cron_args );
		}

		wp_schedule_single_event( time() + leco_client_portal()->notifications()->get_notification_delay(), 'leco_cp_client_uploaded_notification', $cron_args );

	}

	/**
	 * The task to run after the client uploads some files.
	 *
	 * @since 4.9
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $post_id Project ID.
	 * @param int $phase   Phase.
	 * @param int $module  Module.
	 * @param int $user_id The user ID.
	 *
	 * @return void
	 */
	public function client_uploaded_notification( $post_id, $phase, $module, $user_id ) {

		// Check if a sent mark is set.
		$last_sent = get_post_meta( $post_id, "leco_cp_last_notification_time_{$phase}_$module", true );

		if ( $last_sent && ( time() - $last_sent < leco_client_portal()->notifications()->get_notification_delay() * 2 ) ) {
			return;
		}

		// Send the notification.
		$r = $this->send_client_uploaded_notification( $post_id, $phase, $module, $user_id );

		if ( $r ) {
			// Set the sent mark.
			update_post_meta( $post_id, "leco_cp_last_notification_time_{$phase}_$module", time() );
		}

	}

	/**
	 * Notify the site administrator via email when the client uploads some files.
	 *
	 * @since 4.9
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications\Hooks.
	 *
	 * @param int $post_id Project ID.
	 * @param int $phase   Phase.
	 * @param int $module  Module.
	 * @param int $user_id The user ID.
	 *
	 * @return bool True if email sent successfully, false otherwise.
	 */
	private function send_client_uploaded_notification( $post_id, $phase, $module, $user_id ) {

		$modules = get_post_meta( $post_id, "leco_cp_part_{$phase}_module", true );

		$subject = leco_cp_settings()->get_notification( 'client_uploaded', '', 'subject' );

		$admin_email = apply_filters( 'leco_cp_admin_email_to', get_option( 'admin_email' ), $post_id, $phase, $module );

		$email_data = array(
			'post_id'           => $post_id,
			'modules'           => $modules,
			'phase'             => $phase,
			'module'            => $module,
			'project_admin_url' => Project::get_project_url( $post_id, 'admin' ),
			'project_url'       => Project::get_project_url( $post_id ),
			'admin_email'       => $admin_email,
		);

		$content = leco_cp_settings()->get_notification( 'client_uploaded', '', 'content' );

		$emails = leco_client_portal()->emails;

		$emails->__set( 'data', $email_data );

		$recipients = leco_cp_settings()->get_notification( 'client_uploaded', array(), 'recipients' );
		$sent       = false;

		foreach ( $recipients as $recipient ) {
			if ( $recipient === 'admin' ) {
				$emails->__set( 'user', new WP_User( $user_id ) );

				$sent = $emails->send( $email_data['admin_email'], $subject, $content );
			}
		}

		return $sent;

	}

	/**
	 * Check module status.
	 *
	 * @since 4.15
	 *
	 * @param int    $post_id Project ID.
	 * @param int    $phase   Phase.
	 * @param int    $module  Module.
	 * @param string $status  Status.
	 *
	 * @return array
	 */
	private function check_module_status( $post_id, $phase, $module, $status ) {

		$modules = Project::get_modules( $post_id, $phase );

		if ( ! in_array( $status, array( 'module_completed', 'module_activated' ) ) ) {
			return $modules;
		}

		switch ( $status ) {

			default:
			case 'module_completed':
				$status      = 'completed';
				$status_i18n = esc_html__( 'completed', 'leco-cp' );
				break;

			case 'module_activated':
				$status      = 'active';
				$status_i18n = esc_html__( 'activated', 'leco-cp' );
				break;

		}

		if ( $status === $modules[ $module ]['status'] ) {
			wp_die( sprintf( esc_html__( 'The module has been %s. Cannot send the notification again.', 'leco-cp' ), $status_i18n ) ); // phpcs:ignore.
		}

		return $modules;

	}

}
