<?php
/**
 * Notification Settings.
 *
 * Defines a Notification Settings object in Client Portal.
 *
 * @since      4.15
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2022, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications\Notification;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LECO CP Notification Settings object.
 *
 * @since 4.15
 */
final class Settings {

	/**
	 * The notification settings description.
	 *
	 * @since 4.15
	 *
	 * @var string
	 */
	private $description;

	/**
	 * The notification recipients setting description.
	 *
	 * @since 4.15
	 *
	 * @var string
	 */
	private $recipients_description;

	/**
	 * The notification recipients setting options.
	 *
	 * @since 4.15
	 *
	 * @var array
	 */
	private $recipients_options;

	/**
	 * The notification settings default.
	 *
	 * @since 4.15
	 *
	 * @var array
	 */
	private $defaults;

	/**
	 * Constructor.
	 *
	 * @since 4.15
	 *
	 * @param array $args                          {
	 *                                             Array of the arguments to create a notification.
	 *
	 * @type string $description                   The notification description.
	 * @type string $recipients_description        The notification recipients description.
	 * @type array  $recipients_options            The notification recipients options.
	 * @type array  $defaults                      The notification settings default values.
	 * }
	 */
	public function __construct( $args ) {

		$this->description            = $args['description'];
		$this->recipients_description = $args['recipients_description'];
		$this->recipients_options     = $args['recipients_options'];
		$this->defaults               = $args['defaults'];

	}

	/**
	 * Get the notification settings description.
	 *
	 * @since 4.15
	 *
	 * @return string
	 */
	public function description() {
		return $this->description;
	}

	/**
	 * Get the notification recipients setting description.
	 *
	 * @since 4.15
	 *
	 * @return string
	 */
	public function recipients_description() {
		return $this->recipients_description;
	}

	/**
	 * Get the notification recipients setting options.
	 *
	 * @since 4.15
	 *
	 * @return array
	 */
	public function recipients_options() {
		return $this->recipients_options;
	}

	/**
	 * Get the notification settings default values.
	 *
	 * @since 4.15
	 *
	 * @return array
	 */
	public function defaults() {
		return $this->defaults;
	}

}
