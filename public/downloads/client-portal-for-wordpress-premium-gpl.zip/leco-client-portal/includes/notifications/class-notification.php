<?php
/**
 * Notification.
 *
 * Defines a Notification object in Client Portal.
 *
 * @since      4.15
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2022, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LECO CP Notification object.
 *
 * @since 4.15
 */
final class Notification {

	/**
	 * The notification event.
	 *
	 * @since 4.15
	 *
	 * @var string
	 */
	private $event;

	/**
	 * The notification name.
	 *
	 * @since 4.15
	 *
	 * @var string
	 */
	private $name;

	/**
	 * The notification settings.
	 *
	 * @since 4.15
	 *
	 * @var Notification\Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @since 4.15
	 *
	 * @param string $event The Notification event key.
	 * @param string $name  The Notification name.
	 */
	public function __construct( $event, $name ) {

		$this->event = $event;
		$this->name  = $name;

	}

	/**
	 * Get the notification event.
	 *
	 * @since 4.15
	 *
	 * @return string
	 */
	public function event() {
		return $this->event;
	}

	/**
	 * Get the notification name.
	 *
	 * @since 4.15
	 *
	 * @return string
	 */
	public function name() {
		return $this->name;
	}

	/**
	 * Get the notification settings.
	 *
	 * @return Notification\Settings|null
	 */
	public function settings() {
		return $this->settings;
	}

	/**
	 * Add settings to a notification.
	 *
	 * @since 4.15
	 *
	 * @param Notification\Settings $settings The notification settings.
	 *
	 * @return void
	 */
	public function add_settings( $settings ) {
		$this->settings = $settings;
	}

}
