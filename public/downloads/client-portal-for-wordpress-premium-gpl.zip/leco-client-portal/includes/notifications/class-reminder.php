<?php
/**
 * Processing the due date reminder.
 *
 * @since      4.16
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2023, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal\Notifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_User;
use LECO\Client_Portal\CMB2\Types\Due_Date;
use LECO\Client_Portal\Project;

/**
 * LECO CP Reminder object.
 *
 * @since 4.16
 */
final class Reminder {

	const SCHEDULER_HOOK = 'leco_cp_due_date_reminder';

	/**
	 * Update the reminder scheduler.
	 *
	 * @since 4.16
	 *
	 * @param int          $project_id The project ID.
	 * @param string|int   $phase      The phase index.
	 * @param string|array $modules    The modules data.
	 *
	 * @return void
	 */
	public static function update_scheduler( $project_id, $phase, $modules ) {

		$cron_args = array( $project_id, $phase, $modules );

		if ( wp_next_scheduled( 'leco_cp_due_date_scheduler_updater', $cron_args ) ) {
			wp_clear_scheduled_hook( 'leco_cp_due_date_scheduler_updater', $cron_args );
		}

		wp_schedule_single_event( time() + 10, 'leco_cp_due_date_scheduler_updater', $cron_args );

	}

	/**
	 * Schedule the reminder for each module.
	 *
	 * @since 4.16
	 *
	 * @param int          $project_id The project ID.
	 * @param string|int   $phase      The phase index.
	 * @param string|array $modules    The modules data.
	 *
	 * @return void
	 */
	public function schedule( $project_id, $phase, $modules ) {

		$phase   = intval( $phase );
		$modules = is_string( $modules ) ? maybe_unserialize( $modules ) : $modules;

		foreach ( $modules as $k => $module ) {
			$has_due_date = Project::get_module_due_date( $project_id, $phase, $k );

			if ( $has_due_date <= 0 ) {
				continue;
			}

			$cron_args = array( $project_id, $phase, $k );

			$reminder = intval( $module['due_date']['reminder'] ) * HOUR_IN_SECONDS;

			// Always clear the existing hook.
			wp_clear_scheduled_hook( self::SCHEDULER_HOOK, $cron_args );

			if ( ! $reminder ) {
				continue;
			}

			$utc_time = Due_Date::date_create_from_format( $module['due_date'], wp_timezone() );

			if ( $utc_time ) {
				$timestamp = $utc_time->getTimestamp();

				if ( $timestamp < time() ) {
					continue;
				}

				wp_schedule_single_event( $timestamp - $reminder, self::SCHEDULER_HOOK, $cron_args );

				/**
				 * Run custom actions when a module's due date reminder is set.
				 *
				 * @since 4.16
				 *
				 * @param int $post_id Project ID.
				 * @param int $phase   Phase.
				 * @param int $k       The module.
				 */
				do_action( 'leco_cp_module_due_date_reminder_set', $project_id, $phase, $k );
			}
		}

	}

	/**
	 * Send the reminder.
	 *
	 * @since 4.16
	 *
	 * @param int $project_id The project ID.
	 * @param int $phase      The phase index.
	 * @param int $module     The module index.
	 *
	 * @return void
	 */
	public function send( $project_id, $phase, $module ) {

		if ( ! Project::is_valid( $project_id ) ) {
			return;
		}

		$due_date = Project::get_module_due_date( $project_id, $phase, $module, true );
		if ( is_numeric( $due_date ) && $due_date <= 0 ) {
			return;
		}

		$modules = get_post_meta( $project_id, "leco_cp_part_{$phase}_module", true );
		if ( isset( $modules[ $module ] ) && 'active' !== $modules[ $module ]['status'] ) {
			return;
		}

		$subject = leco_cp_settings()->get_notification( 'reminder', '', 'subject' );

		$admin_email = apply_filters( 'leco_cp_admin_email_to', get_option( 'admin_email' ), $project_id, $phase, $module );

		$email_data = array(
			'post_id'           => $project_id,
			'phase'             => $phase,
			'module'            => $module,
			'modules'           => $modules,
			'project_admin_url' => Project::get_project_url( $project_id, 'admin' ),
			'project_url'       => Project::get_project_url( $project_id ),
			'admin_email'       => $admin_email,
			'module_due_date'   => $due_date,
		);

		$content = leco_cp_settings()->get_notification( 'reminder', '', 'content' );

		$emails = leco_client_portal()->emails;

		$emails->__set( 'data', $email_data );

		$recipients = leco_cp_settings()->get_notification( 'reminder', array(), 'recipients' );

		foreach ( $recipients as $recipient ) {
			if ( $recipient === 'admin' ) {
				$admin_user = get_user_by( 'email', $email_data['admin_email'] );
				if ( $admin_user instanceof WP_User ) {
					$emails->__set( 'user', wp_get_current_user() );
				}

				$emails->send( $email_data['admin_email'], $subject, $content );
			} elseif ( $recipient === 'client' ) {
				$emails->send_to_client( $project_id, $subject, $content );
			}
		}

	}

}
