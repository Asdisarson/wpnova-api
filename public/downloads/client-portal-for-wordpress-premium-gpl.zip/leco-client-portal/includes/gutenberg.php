<?php
/**
 * Register Custom Blocks
 *
 * @package     ClientPortal\Shortcode.
 * @since       4.12
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filters the default array of categories for block types.
 *
 * @since 4.12
 *
 * @param array  $block_categories     Array of Block Categories.
 * @param string $block_editor_context (WP_Block_Editor_Context) The current block editor context.
 *
 * @return array
 */
function leco_cp_add_custom_gutenberg_category( $block_categories, $block_editor_context ) {
	if ( ! empty( $editor_context->post ) ) {
		$block_categories[] = array(
			'slug'  => 'leco-cp-blocks',
			'title' => __( 'Client Portal', 'leco-cp' ),
			'icon'  => null,
		);
	}
	return $block_categories;
}

add_filter( 'block_categories_all', 'leco_cp_add_custom_gutenberg_category', 10, 2 );



/**
 * Serverside Registration of Form Blocks.
 *
 * @since 4.12
 *
 * @return void
 */
function leco_cp_gutenberg_blocks() {

	// Login Block.
	register_block_type(
		'leco-cp/login',
		array(
			'api_version'     => 2,
			'editor_script'   => 'leco-cp-gutenberg-blocks-script',
			'editor_style'    => 'leco-cp-blocks-css',
			'render_callback' => 'leco_cp_render_login_form',
		)
	);

	// Register Block.
	register_block_type(
		'leco-cp/register',
		array(
			'api_version'     => 2,
			'editor_script'   => 'leco-cp-gutenberg-blocks-script',
			'editor_style'    => 'leco-cp-blocks',
			'render_callback' => 'leco_cp_render_register_form',
			'attributes'      => array(
				'project'             => array( 'type' => 'integer' ),
				'template'            => array( 'type' => 'integer' ),
				'projectTitle'        => array( 'type' => 'string' ),
				'showOrganization'    => array( 'type' => 'boolean' ),
				'privacyConsentLabel' => array( 'type' => 'string' ),
			),
		)
	);
}

add_action( 'init', 'leco_cp_gutenberg_blocks' );
