<?php
/**
 * Register Custom Post Type
 *
 * @package     LECO\Client_Portal
 * @since       1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register a client post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function leco_cp_register_post_type() {
	$rewrite = defined( 'LECO_CP_DISABLE_REWRITE' ) && LECO_CP_DISABLE_REWRITE ? false : array(
		'slug'       => leco_cp_get_slug(),
		'with_front' => false,
	);

	$labels = array(
		'name'               => _x( 'CP Projects', 'post type general name', 'leco-cp' ),
		'singular_name'      => _x( 'CP Project', 'post type singular name', 'leco-cp' ),
		'menu_name'          => _x( 'Client Portal', 'admin menu', 'leco-cp' ),
		'name_admin_bar'     => _x( 'CP Project', 'add new on admin bar', 'leco-cp' ),
		'add_new'            => _x( 'Add New', 'project', 'leco-cp' ),
		'add_new_item'       => __( 'Add New CP Project', 'leco-cp' ),
		'new_item'           => __( 'New CP Project', 'leco-cp' ),
		'edit_item'          => __( 'Edit CP Project', 'leco-cp' ),
		'view_item'          => __( 'View CP Project', 'leco-cp' ),
		'all_items'          => __( 'All CP Projects', 'leco-cp' ),
		'search_items'       => __( 'Search CP Projects', 'leco-cp' ),
		'not_found'          => __( 'No CP projects found.', 'leco-cp' ),
		'not_found_in_trash' => __( 'No CP projects found in Trash.', 'leco-cp' ),
	);

	$args = array(
		'labels'              => $labels,
		'public'              => true,
		'publicly_queryable'  => true,
		'exclude_from_search' => false,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_rest'        => current_user_can( 'manage_options' ),
		'query_var'           => true,
		'rewrite'             => array(
			'slug'       => leco_cp_get_slug(),
			'with_front' => false,
		),
		'capability_type'     => 'post',
		'has_archive'         => true,
		'hierarchical'        => false,
		'menu_position'       => null,
		'menu_icon'           => "data:image/svg+xml;base64,Cjxzdmcgd2lkdGg9IjI2NHB4IiBoZWlnaHQ9IjI2NHB4IiB2aWV3Qm94PSIwIDAgMjY0IDI2NCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4KICAgIDxnIGlkPSJQYWdlLTEiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJjcCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMC4wMDM4MDcsIDAuMDAyOTUxKSIgZmlsbD0iIzlDQTFBOCI+CiAgICAgICAgICAgIDxwYXRoIGQ9Ik0xOTQuODQ2MTkzLDY5LjQ1NzA0ODYgTDEzNi42NzYxOTMsMTI3LjYyNzA0OSBDMTM1LjQzNjQ5NCwxMjguODY3MjkxIDEzMy43NTQ3NzYsMTI5LjU2NDA5NyAxMzIuMDAxMTkzLDEyOS41NjQwOTcgQzEzMC4yNDc2MSwxMjkuNTY0MDk3IDEyOC41NjU4OTEsMTI4Ljg2NzI5MSAxMjcuMzI2MTkzLDEyNy42MjcwNDkgTDEyNy4zMjYxOTMsMTI3LjYyNzA0OSBMMTExLjkxNjE5MywxMTIuMjE3MDQ5IEMxMTAuNjc2NDk0LDExMC45NzY4MDYgMTA4Ljk5NDc3NiwxMTAuMjggMTA3LjI0MTE5MywxMTAuMjggQzEwNS40ODc2MSwxMTAuMjggMTAzLjgwNTg5MSwxMTAuOTc2ODA2IDEwMi41NjYxOTMsMTEyLjIxNzA0OSBMMTAyLjU2NjE5MywxMTIuMjE3MDQ5IEw4Ny41NjYxOTI1LDEyNy4yMTcwNDkgQzg2LjMyNjU1NzksMTI4LjQ1NTAzOSA4NS42MywxMzAuMTM1MTAyIDg1LjYzLDEzMS44ODcwNDkgQzg1LjYzLDEzMy42Mzg5OTUgODYuMzI2NTU3OSwxMzUuMzE5MDU4IDg3LjU2NjE5MjUsMTM2LjU1NzA0OSBMODcuNTY2MTkyNSwxMzYuNTU3MDQ5IEwxMjcuMzU2MTkzLDE3Ni4zNDcwNDkgQzEyOC41OTU4OTEsMTc3LjU4NzI5MSAxMzAuMjc3NjEsMTc4LjI4NDA5NyAxMzIuMDMxMTkzLDE3OC4yODQwOTcgQzEzMy43ODQ3NzYsMTc4LjI4NDA5NyAxMzUuNDY2NDk0LDE3Ny41ODcyOTEgMTM2LjcwNjE5MywxNzYuMzQ3MDQ5IEwxMzYuNzA2MTkzLDE3Ni4zNDcwNDkgTDIxOS4yNTYxOTMsOTMuNzk3MDQ4NiBDMjIwLjQ5NjQzNSw5Mi41NTczNDk5IDIyMS4xOTMyNDEsOTAuODc1NjMxNSAyMjEuMTkzMjQxLDg5LjEyMjA0ODYgQzIyMS4xOTMyNDEsODcuMzY4NDY1NiAyMjAuNDk2NDM1LDg1LjY4Njc0NzIgMjE5LjI1NjE5Myw4NC40NDcwNDg2IEwyMTkuMjU2MTkzLDg0LjQ0NzA0ODYgTDIwNC4yNTYxOTMsNjkuNDQ3MDQ4NiBDMjAxLjY5MTY0OSw2Ni44NTAzODM2IDE5Ny41MDkzMjcsNjYuODE5MDcyMSAxOTQuOTA2MTkzLDY5LjM3NzA0ODYgTDE5NC44NDYxOTMsNjkuNDU3MDQ4NiBaIiBpZD0iUGF0aCI+PC9wYXRoPgogICAgICAgICAgICA8cGF0aCBkPSJNMS45MzYxOTI1NCwxMzYuNjc3MDQ5IEwxMjcuMzE2MTkzLDI2Mi4wNTcwNDkgQzEyOC41NTU4OTEsMjYzLjI5NzI5MSAxMzAuMjM3NjEsMjYzLjk5NDA5NyAxMzEuOTkxMTkzLDI2My45OTQwOTcgQzEzMy43NDQ3NzYsMjYzLjk5NDA5NyAxMzUuNDI2NDk0LDI2My4yOTcyOTEgMTM2LjY2NjE5MywyNjIuMDU3MDQ5IEwxMzYuNjY2MTkzLDI2Mi4wNTcwNDkgTDI2Mi4wNTYxOTMsMTM2LjY3NzA0OSBDMjYzLjI5NjQzNSwxMzUuNDM3MzUgMjYzLjk5MzI0MSwxMzMuNzU1NjMyIDI2My45OTMyNDEsMTMyLjAwMjA0OSBDMjYzLjk5MzI0MSwxMzAuMjQ4NDY2IDI2My4yOTY0MzUsMTI4LjU2Njc0NyAyNjIuMDU2MTkzLDEyNy4zMjcwNDkgTDI2Mi4wNTYxOTMsMTI3LjMyNzA0OSBMMjQ3LjA1NjE5MywxMTIuMzI3MDQ5IEMyNDUuODE2NDk0LDExMS4wODY4MDYgMjQ0LjEzNDc3NiwxMTAuMzkgMjQyLjM4MTE5MywxMTAuMzkgQzI0MC42Mjc2MSwxMTAuMzkgMjM4Ljk0NTg5MSwxMTEuMDg2ODA2IDIzNy43MDYxOTMsMTEyLjMyNzA0OSBMMjM3LjcwNjE5MywxMTIuMzI3MDQ5IEwxMzYuNzA2MTkzLDIxMy4zMjcwNDkgQzEzNS40NjY0OTQsMjE0LjU2NzI5MSAxMzMuNzg0Nzc2LDIxNS4yNjQwOTcgMTMyLjAzMTE5MywyMTUuMjY0MDk3IEMxMzAuMjc3NjEsMjE1LjI2NDA5NyAxMjguNTk1ODkxLDIxNC41NjcyOTEgMTI3LjM1NjE5MywyMTMuMzI3MDQ5IEwxMjcuMzU2MTkzLDIxMy4zMjcwNDkgTDUwLjY4NjE5MjUsMTM2LjY3NzA0OSBDNDkuNDQ1OTUwNCwxMzUuNDM3MzUgNDguNzQ5MTQ0LDEzMy43NTU2MzIgNDguNzQ5MTQ0LDEzMi4wMDIwNDkgQzQ4Ljc0OTE0NCwxMzAuMjQ4NDY2IDQ5LjQ0NTk1MDQsMTI4LjU2Njc0NyA1MC42ODYxOTI1LDEyNy4zMjcwNDkgTDUwLjY4NjE5MjUsMTI3LjMyNzA0OSBMMTI3LjMxNjE5Myw1MC42OTcwNDg2IEMxMjguNTU1ODkxLDQ5LjQ1NjgwNjUgMTMwLjIzNzYxLDQ4Ljc2IDEzMS45OTExOTMsNDguNzYgQzEzMy43NDQ3NzYsNDguNzYgMTM1LjQyNjQ5NCw0OS40NTY4MDY1IDEzNi42NjYxOTMsNTAuNjk3MDQ4NiBMMTM2LjY2NjE5Myw1MC42OTcwNDg2IEwxNTIuMDg2MTkzLDY2LjA5NzA0ODYgQzE1My4zMjU4OTEsNjcuMzM3MjkwNyAxNTUuMDA3NjEsNjguMDM0MDk3MiAxNTYuNzYxMTkzLDY4LjAzNDA5NzIgQzE1OC41MTQ3NzYsNjguMDM0MDk3MiAxNjAuMTk2NDk0LDY3LjMzNzI5MDcgMTYxLjQzNjE5Myw2Ni4wOTcwNDg2IEwxNjEuNDM2MTkzLDY2LjA5NzA0ODYgTDE3Ni40MzYxOTMsNTEuMDk3MDQ4NiBDMTc3LjY3NjQzNSw0OS44NTczNDk5IDE3OC4zNzMyNDEsNDguMTc1NjMxNSAxNzguMzczMjQxLDQ2LjQyMjA0ODYgQzE3OC4zNzMyNDEsNDQuNjY4NDY1NiAxNzcuNjc2NDM1LDQyLjk4Njc0NzIgMTc2LjQzNjE5Myw0MS43NDcwNDg2IEwxNzYuNDM2MTkzLDQxLjc0NzA0ODYgTDEzNi42NzYxOTMsMS45MzcwNDg1OCBDMTM1LjQzNjQ5NCwwLjY5NjgwNjQ2NyAxMzMuNzU0Nzc2LDAgMTMyLjAwMTE5MywwIEMxMzAuMjQ3NjEsMCAxMjguNTY1ODkxLDAuNjk2ODA2NDY3IDEyNy4zMjYxOTMsMS45MzcwNDg1OCBMMTI3LjMyNjE5MywxLjkzNzA0ODU4IEwxLjkzNjE5MjU0LDEyNy4zMTcwNDkgQzAuNjk2NTU3ODYyLDEyOC41NTUwMzkgMCwxMzAuMjM1MTAyIDAsMTMxLjk4NzA0OSBDMCwxMzMuNzM4OTk1IDAuNjk2NTU3ODYyLDEzNS40MTkwNTggMS45MzYxOTI1NCwxMzYuNjU3MDQ5IEwxLjkzNjE5MjU0LDEzNi42NzcwNDkgWiIgaWQ9IlBhdGgiPjwvcGF0aD4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==",
		'supports'            => array( 'title', 'author' ),
	);

	register_post_type( 'leco_client', apply_filters( 'leco_cpt_args', $args, 'leco_client' ) );

	$labels = array(
		'name'               => _x( 'CP Project Templates', 'post type general name', 'leco-cp' ),
		'singular_name'      => _x( 'CP Project Template', 'post type singular name', 'leco-cp' ),
		'menu_name'          => _x( 'CP Project Templates', 'admin menu', 'leco-cp' ),
		'name_admin_bar'     => _x( 'CP Project Template', 'add new on admin bar', 'leco-cp' ),
		'add_new'            => _x( 'Add New', 'project template', 'leco-cp' ),
		'add_new_item'       => __( 'Add New CP Project Template', 'leco-cp' ),
		'new_item'           => __( 'New CP Project Template', 'leco-cp' ),
		'edit_item'          => __( 'Edit CP Project Template', 'leco-cp' ),
		'view_item'          => __( 'View CP Project Template', 'leco-cp' ),
		'all_items'          => __( 'All CP Project Templates', 'leco-cp' ),
		'search_items'       => __( 'Search CP Project Templates', 'leco-cp' ),
		'not_found'          => __( 'No CP project templates found.', 'leco-cp' ),
		'not_found_in_trash' => __( 'No CP project templates found in Trash.', 'leco-cp' ),
	);

	$args = array(
		'labels'              => $labels,
		'public'              => false,
		'publicly_queryable'  => true,
		'exclude_from_search' => true,
		'show_ui'             => true,
		'show_in_menu'        => 'edit.php?post_type=leco_client',
		'show_in_rest'        => current_user_can( 'manage_options' ),
		'show_in_nav_menus'   => false,
		'query_var'           => true,
		'rewrite'             => array(
			'slug'       => 'project-template',
			'with_front' => false,
		),
		'capability_type'     => 'post',
		'has_archive'         => false,
		'hierarchical'        => false,
		'menu_position'       => null,
		'supports'            => array( 'title', 'author' ),
	);

	register_post_type( 'leco_template', apply_filters( 'leco_cpt_args', $args, 'leco_template' ) );

	$labels = array(
		'name'               => _x( 'Content Pages', 'post type general name', 'leco-cp' ),
		'singular_name'      => _x( 'Content Page', 'post type singular name', 'leco-cp' ),
		'menu_name'          => _x( 'Content Pages', 'admin menu', 'leco-cp' ),
		'name_admin_bar'     => _x( 'Content Page', 'add new on admin bar', 'leco-cp' ),
		'add_new'            => _x( 'Add New', 'content page', 'leco-cp' ),
		'add_new_item'       => __( 'Add New Content Page', 'leco-cp' ),
		'new_item'           => __( 'New Content Page', 'leco-cp' ),
		'edit_item'          => __( 'Edit Content Page', 'leco-cp' ),
		'view_item'          => __( 'View Content Page', 'leco-cp' ),
		'all_items'          => __( 'All Content Pages', 'leco-cp' ),
		'search_items'       => __( 'Search Content Pages', 'leco-cp' ),
		'parent_item_colon'  => __( 'Parent Content Page:', 'leco-cp' ),
		'not_found'          => __( 'No content pages found.', 'leco-cp' ),
		'not_found_in_trash' => __( 'No content pages found in Trash.', 'leco-cp' ),
	);

	$args = array(
		'labels'              => $labels,
		'public'              => false,
		'publicly_queryable'  => false,
		'exclude_from_search' => true,
		'show_ui'             => true,
		'show_in_menu'        => 'edit.php?post_type=leco_client',
		'show_in_nav_menus'   => false,
		'query_var'           => true,
		'rewrite'             => false,
		'capability_type'     => 'post',
		'has_archive'         => false,
		'hierarchical'        => false,
		'menu_position'       => null,
		'supports'            => array( 'title', 'editor', 'author', 'revisions' ),
	);

	register_post_type( 'leco_content_page', apply_filters( 'leco_cpt_args', $args, 'leco_content_page' ) );

	do_action( 'leco_cp_after_register_post_type' );
}
add_action( 'init', 'leco_cp_register_post_type' );

/**
 * Flush rewrite rules when needed
 */
function leco_cp_flush_rewrite_rules() {
	if ( leco_cp_get_slug() !== get_option( 'leco_cp_flush_rewrite_rules' ) ) {
		update_option( 'leco_cp_flush_rewrite_rules', leco_cp_get_slug() );

		flush_rewrite_rules();
	}

	if ( ! get_option( 'leco_cp_set_closedpostboxes' ) ) {
		update_option( 'leco_cp_set_closedpostboxes', '4.2.0' ); // Use version number so later on we can do this by comparing version.

		// update closed metabox option.
		if ( is_user_logged_in() ) {
			$metaboxes = array(
				'leco_cp_custom_branding',
				'leco_cp_info',
				'leco_cp_part_0',
				'leco_cp_part_1',
				'leco_cp_part_2',
				'leco_cp_part_3',
				'leco_cp_part_4',
				'leco_cp_part_5',
			);
			update_user_meta( get_current_user_id(), 'closedpostboxes_leco_client', $metaboxes );
			update_user_meta( get_current_user_id(), 'closedpostboxes_leco_template', $metaboxes );
		}
	}
}
add_action( 'leco_cp_after_register_post_type', 'leco_cp_flush_rewrite_rules' );

/**
 * Get permalink settings for Client Portal.
 *
 * This function is derived from WooCommerce.
 *
 * @since  4.10
 * @return array
 */
function leco_cp_get_permalink_structure() {
	$saved_permalinks = (array) get_option( 'leco_cp_permalinks', array() );
	$permalinks       = wp_parse_args(
		array_filter( $saved_permalinks ),
		array(
			'project_base' => _x( 'client', 'slug', 'leco-cp' ),
		)
	);

	if ( $saved_permalinks !== $permalinks ) {
		update_option( 'leco_cp_permalinks', $permalinks );
	}

	$permalinks['project_rewrite_slug'] = untrailingslashit( $permalinks['project_base'] );

	return $permalinks;
}
