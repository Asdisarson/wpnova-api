<?php
/**
 * Helper functions for the Client Portal plugin.
 *
 * @package LECO\Client_Portal
 */

/**
 * Wrapper function around cmb2_get_option.
 *
 * @since 0.1.0
 * @since 4.9   Support tabs.
 *
 * @param string $key     Options array key.
 * @param string $default Default value when option is empty.
 * @param string $tab     The tab.
 *
 * @return mixed Option value
 */
function leco_cp_get_option( $key = '', $default = '', $tab = '' ) {

	return leco_cp_settings()->get_option( $key, $default, $tab );
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @return bool             True if metabox should show
 */
function leco_cp_show_if_add_client() {
	global $pagenow;
	// Don't show this metabox if it's updating post.
	if ( 'post-new.php' !== $pagenow ) {
		return false;
	}

	return true;
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @return bool             True if metabox should show
 */
function leco_cp_show_if_update_client() {
	global $pagenow;
	// Don't show this metabox if it's creating a new post.
	if ( 'post-new.php' === $pagenow || isset( $_GET['cp-action'] ) ) { // phpcs:ignore
		return false;
	}

	return true;
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @return bool             True if metabox should show
 */
function leco_cp_show_if_manage_phases() {
	global $pagenow;
	// Show this metabox if it's the manage phases screen.
	if ( 'post.php' === $pagenow && isset( $_GET['cp-action'] ) ) { // phpcs:ignore
		return true;
	}

	return false;
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @return bool             True if metabox should show
 */
function leco_cp_show_if_not_manage_phases() {
	global $pagenow;
	// Show this metabox if it's the manage phases screen.
	if ( ( 'post.php' === $pagenow || 'post-new.php' === $pagenow ) && ! isset( $_GET['cp-action'] ) ) { // phpcs:ignore
		return true;
	}

	return false;
}

/**
 * A little helper function to remove the .svg from our icon json
 *
 * @param string $file The file name.
 *
 * @return bool|string
 */
function leco_cp_remove_dotsvg( $file ) {
	return substr( $file, 0, - 4 );
}

/**
 * Check the post password.
 *
 * @param WP_Post|null $post The post object.
 *
 * @return bool
 */
function leco_cp_check_post_password( $post = null ) {
	require_once( ABSPATH . WPINC . '/class-phpass.php' );

	if ( ! isset( $_COOKIE[ 'wp-postpass_' . COOKIEHASH ] ) ) {
		return false;
	}

	$post   = get_post( $post );
	$hasher = new PasswordHash( 8, true );
	$passed = false;

	if ( ! empty( $post->post_password ) ) {
		$hash = wp_unslash( $_COOKIE[ 'wp-postpass_' . COOKIEHASH ] ); // phpcs:ignore
		if ( 0 !== strpos( $hash, '$P$B' ) ) {
			$passed = false;
		} else {
			$passed = $hasher->CheckPassword( $post->post_password, $hash );
		}
	}

	return $passed;
}

/**
 * If the project content can be displayed.
 *
 * @since 4.7.0
 *
 * @return bool
 */
function leco_cp_can_display_project() {
	if ( current_user_can( 'edit_posts' ) || ( ( is_user_logged_in() && leco_cp_user_has_access( get_the_ID() ) ) ) || leco_cp_check_post_password( get_the_ID() ) || leco_cp_is_public_portal( get_the_ID() ) ) {
		return true;
	}

	return false;
}

/**
 * Get projects by client (user id by default)
 *
 * @since unknown
 * @since 4.4     Added checking new user meta "leco_cp_project".
 *
 * @param int          $user_id   User ID.
 * @param string|array $post_type Post types.
 *
 * @return int[] An array of post IDs.
 */
function leco_cp_get_projects_by_client( $user_id = 0, $post_type = 'leco_client' ) {
	if ( ! $user_id ) {
		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
		}
	}

	if ( ! $user_id ) {
		return array();
	}

	$projects = maybe_unserialize( get_user_meta( $user_id, 'leco_cp_project', true ) );

	if ( empty( $projects ) ) {
		$projects = get_posts(
			array(
				'post_type'  => $post_type,
				'meta_query' => array(
					'relation' => 'AND',
					array(
						'key'   => 'leco_cp_client',
						'value' => $user_id,
					),
					array(
						'key'     => 'leco_cp_public_portal',
						'value'   => 'yes',
						'compare' => '!=',
					),
				),
			)
		);
		$projects = wp_list_pluck( $projects, 'ID' );
	}

	return ( empty( $projects ) ) ? array() : $projects;
}

/**
 * Check if current user can access Client Portal
 *
 * @return bool
 */
function leco_cp_user_role_allowed() {
	if ( ! function_exists( 'wp_get_current_user' ) ) {
		require( ABSPATH . WPINC . '/pluggable.php' );
	}

	$roles      = apply_filters( 'leco_cp_client_roles', array( 'leco_client' ) );
	$is_allowed = false;
	foreach ( $roles as $role ) {
		if ( current_user_can( $role ) ) {
			$is_allowed = true;
		}
	}

	return $is_allowed;
}

/**
 * Check if the user can access a project (is the client or can edit the project).
 *
 * @since 4.4
 * @since 4.6.1  $project_id can be null.
 * @since 4.12.2 Added $ignore_admin to support the registration form shortocde/block.
 *
 * @param int  $project_id   Project ID.
 * @param bool $ignore_admin If we should ignore the admin caps check.
 *
 * @return bool
 */
function leco_cp_user_has_access( $project_id = null, $ignore_admin = false ) {
	if ( null === $project_id ) {
		$project    = get_post();
		$project_id = $project->ID;
	}

	$projects = leco_cp_get_projects_by_client( get_current_user_id() );

	if ( in_array( $project_id, $projects ) || ( ! $ignore_admin && current_user_can( 'edit_posts' ) ) ) {
		$has_access = true;
	} else {
		$has_access = false;
	}

	/**
	 * Filter the user access to a project.
	 *
	 * @since 4.14
	 *
	 * @param bool $has_access   If the user can access the project.
	 * @param int  $project_id   Project ID.
	 * @param bool $ignore_admin If we should ignore the admin caps check.
	 */
	return apply_filters( 'leco_cp_user_has_access', $has_access, $project_id, $ignore_admin );
}

/**
 * Check if it's a public portal.
 *
 * @param int $post_id Post ID.
 *
 * @return bool
 */
function leco_cp_is_public_portal( $post_id ) {
	$public_portal = get_post_meta( $post_id, 'leco_cp_public_portal', true );

	if ( 'yes' === $public_portal ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if a module can be mark as complete by the client.
 *
 * @param array $module  Module data.
 * @param int   $post_id Project ID.
 *
 * @return bool
 */
function leco_cp_can_mark_as_complete( $module, $post_id ) {

	$user_can_mark = leco_cp_user_role_allowed() || current_user_can( 'administrator' );
	if ( ! $user_can_mark ) {
		return false;
	}

	$module_status = $module['status'];
	if ( 'active' !== $module_status ) {
		return false;
	}

	$post_show_mark_as_complete = get_post_meta( $post_id, 'leco_cp_show_mark_as_complete', true );
	$site_show_mark_as_complete = get_option( 'show_mark_as_complete' );
	$show_mark_as_complete      = false === $post_show_mark_as_complete ? $site_show_mark_as_complete : $post_show_mark_as_complete;

	if ( 'show' === $show_mark_as_complete ) {
		return true;
	} elseif ( 'show_with_due_date' === $show_mark_as_complete ) {
		$module_due_date = isset( $module['due_date'] ) && $module['due_date']['enabled'] && $module['due_date']['date'] && $module['due_date']['time'];

		if ( $module_due_date ) {
			return true;
		}
	}

	return false;
}

/**
 * Check if showing the upload icon.
 *
 * @since 4.8
 *
 * @param array $module  The module data.
 * @param int   $post_id The post ID.
 *
 * @return bool
 */
function leco_cp_can_upload( $module, $post_id ) {
	if ( isset( $module['type'] ) && 'client-uploads' === $module['type'] && leco_cp_user_has_access( $post_id ) && ( leco_cp_user_role_allowed() || current_user_can( 'administrator' ) ) ) {
		return true;
	}

	return false;
}

/**
 * Set user projects by posted meta value of leco_cp_client.
 *
 * @since 4.4
 *
 * @param string $value      Value.
 * @param int    $project_id Project ID.
 * @param bool   $remove     Remove user projects or not.
 */
function leco_cp_set_user_projects( $value, $project_id, $remove = false ) {
	$value = maybe_unserialize( $value );

	if ( ! is_array( $value ) ) {
		$value = array( $value );
	}

	if ( ! $remove ) {
		// Attach project to user.
		foreach ( $value as $user_id ) {
			$projects = leco_cp_get_projects_by_client( $user_id );

			if ( ! in_array( $project_id, $projects ) || empty( $projects ) ) {
				$projects[] = $project_id;
				update_user_meta( $user_id, 'leco_cp_project', $projects );

				do_action( 'leco_cp_project_created', $project_id, (int) $user_id );
			}
		}
	} else {
		// Check current meta value.
		$_value = maybe_unserialize( get_post_meta( $project_id, 'leco_cp_client', true ) );
		if ( is_string( $_value ) ) {
			$_value = array( $_value );
		}

		foreach ( $_value as $old_client ) {
			if ( ! in_array( $old_client, $value, true ) || empty( $value ) || doing_action( 'delete_post_meta' ) ) {
				$projects = leco_cp_get_projects_by_client( $old_client );

				if ( ! empty( $projects ) ) {
					$key = array_search( $project_id, $projects );
					if ( false !== $key ) {
						unset( $projects[ $key ] );
						update_user_meta( $old_client, 'leco_cp_project', $projects );
					}
				}
			}
		}
	}
}

/**
 * Checks whether function is disabled.
 *
 * Borrowed from EDD.
 *
 * @since 4.6
 *
 * @param string $function Name of the function.
 *
 * @return bool Whether or not function is disabled.
 */
function leco_cp_is_func_disabled( $function ) {
	$disabled = explode( ',', ini_get( 'disable_functions' ) );

	return in_array( $function, $disabled, true );
}

/**
 * Retrieves the login URL.
 *
 * @since 4.6
 * @since 4.11 Updated to use LECO\Client_Portal\Login::login_url().
 *
 * @param string $redirect     Path to redirect to on log in.
 * @param bool   $force_reauth Whether to force reauthorization, even if a cookie is present.
 *                             Default false.
 *
 * @return string The login URL. Not HTML-encoded.
 */
function leco_cp_login_url( $redirect = '', $force_reauth = false ) {

	return \LECO\Client_Portal\Login::login_url( $redirect, $force_reauth );

}

/**
 * Deregister and dequeue styles from themes.
 *
 * @since 4.7
 */
function leco_cp_remove_theme_css_js() {
	global $wp_styles, $wp_scripts;
	$theme_enqueued = array(
		'style'  => $wp_styles,
		'script' => $wp_scripts,
	);
	foreach ( $theme_enqueued as $type => $enqueued ) {
		foreach ( $enqueued->registered as $handle => $data ) {
			// CP works as template so we don't need anything from the "theme".
			// But we want to load styles and scripts from the "plugins".
			if ( strpos( $data->src, 'themes' ) ) {
				// otherwise remove it.
				if ( 'style' === $type ) {
					wp_dequeue_style( $handle );
					wp_deregister_style( $handle );
				} else {
					wp_dequeue_script( $handle );
					wp_deregister_script( $handle );
				}
			}
		}
	}
}

/**
 * Get the module icon.
 *
 * @since 4.9.3
 *
 * @param string     $icon   The icon name.
 * @param string|int $module The module ID.
 * @param string|int $phase  The Phase ID.
 *
 * @return false|string
 */
function leco_cp_get_module_icon( $icon, $module, $phase ) {

	// Backward compatibility.
	if ( $icon === 'Wranch' ) {
		$icon = 'Wrench';
	}

	$icon_path_set = LECO_CLIENT_PORTAL_DIR . 'assets/icon/caviar/' . strtolower( $icon ) . '.svg';

	/**
	 * Filter to allow the icon being changed. Allow SVG icons only.
	 *
	 * @since 4.9.3
	 *
	 * @param string     $icon_path The icon path.
	 * @param string     $icon      The icon name.
	 * @param string|int $module    The module ID.
	 * @param string|int $phase     The Phase ID.
	 */
	$icon_path = apply_filters( 'leco_cp_module_icon', $icon_path_set, $icon, $module, $phase );
	if ( has_filter( 'leco_cp_module_icon' ) && ! file_exists( $icon_path ) ) {
		$icon_path = $icon_path_set;
	}

	return file_get_contents( $icon_path );
}

/**
 * Get Client Portal CPT slug.
 *
 * @since 4.10
 *
 * @return string
 */
function leco_cp_get_slug() {

	$permalinks = get_option( 'leco_cp_permalinks' );
	$slug       = $permalinks ? trim( $permalinks['project_base'], '/' ) : '';

	return ( empty( $slug ) ) ? 'client' : $slug;

}

/**
 * Sanitize permalink values before insertion into DB.
 *
 * Borrowed from WooCommerce's wc_sanitize_permalink().
 *
 * @since  4.10
 *
 * @param  string $value Permalink.
 *
 * @return string
 */
function leco_cp_sanitize_permalink( $value ) {
	global $wpdb;

	$value = $wpdb->strip_invalid_text_for_column( $wpdb->options, 'option_value', $value );

	if ( is_wp_error( $value ) ) {
		$value = '';
	}

	$value = esc_url_raw( trim( $value ) );
	$value = str_replace( 'http://', '', $value );
	return untrailingslashit( $value );
}

/**
 * Get project template as options.
 *
 * @since 4.11
 *
 * @param string $default_option The default option.
 *
 * @return array|null
 */
function leco_cp_get_project_template_options( $default_option = '' ) {

	if ( empty( $default_option ) ) {
		$default_option = esc_html__( 'Don\'t use a Template', 'leco-cp' );
	}

	$templates        = get_posts(
		array(
			'post_type'   => 'leco_template',
			'numberposts' => - 1,
		)
	);
	$template_options = ( empty( $templates ) ) ? array() : array_combine(
		wp_list_pluck( $templates, 'ID' ),
		wp_list_pluck( $templates, 'post_title' )
	);
	$default_option   = array( '0' => $default_option );

	return array_replace( $default_option, $template_options );

}

/**
 * Get the current page URL.
 *
 * This function is derived from edd_get_current_page_url().
 *
 * @since 4.12
 *
 * @return string
 */
function leco_cp_get_current_page_url() {

	global $wp;

	if ( get_option( 'permalink_structure' ) ) {

		$base = trailingslashit( home_url( $wp->request ) );

	} else {

		$base = add_query_arg( $wp->query_string, '', trailingslashit( home_url( $wp->request ) ) );
		$base = remove_query_arg( array( 'post_type', 'name' ), $base );

	}

	$scheme = is_ssl() ? 'https' : 'http';
	$uri    = set_url_scheme( $base, $scheme );

	if ( is_front_page() ) {
		$uri = home_url( '/' );
	}

	return apply_filters( 'leco_cp_get_current_page_url', $uri );

}

/**
 * Get the post tyeps CP registered.
 *
 * @since 4.14.0.1
 *
 * @return string[]
 */
function leco_cp_get_post_types() {

	return array( 'leco_client', 'leco_template' );

}

/**
 * Check if the give post type is one of the CP registered post types.
 *
 * @since 4.14.0.1
 *
 * @param string $post_type The post type in question.
 *
 * @return bool
 */
function leco_cp_in_post_types( $post_type ) {

	return in_array( $post_type, leco_cp_get_post_types(), true );

}
