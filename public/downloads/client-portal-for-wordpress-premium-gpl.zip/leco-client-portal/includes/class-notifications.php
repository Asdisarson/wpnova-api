<?php
/**
 * Notifications.
 *
 * This class defines notifications in Client Portal.
 *
 * @since      4.15
 * @subpackage Classes/Notifications
 * @copyright  Copyright (c) 2022, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

namespace LECO\Client_Portal;

use LECO\Client_Portal\Notifications\Notification;
use LECO\Client_Portal\Notifications\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LECO CP Notifications class.
 *
 * @since 4.15
 */
class Notifications {

	/**
	 * Holds an instance of the object
	 *
	 * @since 4.15
	 *
	 * @var Notifications
	 **/
	private static $instance = null;

	/**
	 * Notifications.
	 *
	 * @since 4.15
	 *
	 * @var Notification[]
	 */
	protected $notifications = [];

	/**
	 * Constructor.
	 *
	 * @since 4.15
	 */
	private function __construct() {

		$this->notifications[] = new Notification(
			'client_created',
			esc_html__( 'Client Created', 'leco-cp' )
		);

		$this->notifications[] = new Notification(
			'project_created',
			esc_html__( 'Project Created', 'leco-cp' )
		);

		$this->notifications[] = new Notification(
			'module_activated',
			esc_html__( 'Module Activated', 'leco-cp' )
		);

		$this->notifications[] = new Notification(
			'module_completed',
			esc_html__( 'Module Completed', 'leco-cp' )
		);

		$this->notifications[] = new Notification(
			'client_uploaded',
			esc_html__( 'Client Uploaded', 'leco-cp' )
		);

	}

	/**
	 * Returns the running object.
	 *
	 * @since 4.15
	 *
	 * @return Notifications
	 **/
	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;

	}

	/**
	 * Add hooks.
	 *
	 * @since 4.15
	 *
	 * @return void
	 */
	public function hooks() {

		new Hooks();

	}

	/**
	 * Get all notifications.
	 *
	 * @since 4.15
	 *
	 * @return Notification[]
	 */
	public function get_all() {

		return $this->notifications;

	}

	/**
	 * Get all events.
	 *
	 * @since 4.15
	 *
	 * @return string[]
	 */
	public function get_events() {

		return array_map( function( $notification ) {
			return $notification->event();
		}, $this->notifications );

	}

	/**
	 * Get a notification by event.
	 *
	 * @since 4.15
	 *
	 * @param string $event The notification event.
	 *
	 * @return Notification
	 */
	public function get_by_event( $event ) {

		return $this->notifications[ array_search( $event, $this->get_events() ) ];

	}

	/**
	 * Get the notification delay time.
	 *
	 * @since 4.9.6
	 * @since 4.15 Moved to class LECO\Client_Portal\Notifications.
	 *
	 * @return int
	 */
	public function get_notification_delay() {

		// Set the default delay to 10 minutes.
		return apply_filters( 'leco_cp_wait_till_send_notification', MINUTE_IN_SECONDS * 10, 'client_uploaded' );

	}

}
