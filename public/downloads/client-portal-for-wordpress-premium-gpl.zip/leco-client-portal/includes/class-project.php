<?php
/**
 * Project Object
 *
 * @package     LECO\Client_Portal
 * @copyright   Copyright (c) 2021, Laura Elizabeth
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       4.11
 */

namespace LECO\Client_Portal;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Error;
use LECO\Client_Portal\CMB2\Types\Due_Date;

/**
 * Class Project
 *
 * @package LECO\Client_Portal
 *
 * @since 4.11
 */
class Project {

	/**
	 * Create a new project.
	 *
	 * @since 4.11
	 *
	 * @param array $args {
	 *     Additional arguments.
	 *
	 *     @type string $template_id The template ID.
	 *     @type string $client_id   The client ID.
	 * }
	 *
	 * @return int|WP_Error
	 */
	public static function create( $args = array() ) {

		$post_args = array(
			'comment_status' => 'closed',
			'post_author'    => get_current_user_id(),
			'post_status'    => 'publish',
			'post_title'     => esc_html__( 'New Project', 'leco-cp' ),
			'post_type'      => 'leco_client',
			'meta_input'     => array(),
		);

		if ( isset( $args['template_id'] ) && ! empty( $args['template_id'] ) ) {
			$template = get_post( $args['template_id'] );
			if ( ! $template ) {
				return new WP_Error( 'leco_cp_no_template', esc_html__( 'The template doesn\'t exist,', 'leco-cp' ) );
			}

			$post_args['meta_input']['leco_cp_template'] = $args['template_id'];
		}

		if ( isset( $args['client_id'] ) && ! empty( $args['client_id'] ) ) {
			if ( ! user_can( $args['client_id'], 'leco_client' ) ) {
				return new WP_Error( 'leco_cp_not_leco_client', esc_html__( 'The user does not have a CP Client role. Cannot create a project for them.', 'leco-cp' ) );
			}

			$post_args['meta_input']['leco_cp_client'] = array( $args['client_id'] );
			// Get the client project title.
			if ( isset( $args['post_title'] ) ) {
				$post_args['post_title'] = $args['post_title'];
			} else {
				$project_title = get_user_meta( $args['client_id'], 'leco_cp_user_project_title', true );
				if ( ! empty( $project_title ) ) {
					$post_args['post_title'] = $project_title;
				}
			}

			// Set up the post name with an extra suffix.
			$post_args['post_name'] = sanitize_title( $post_args['post_title'] ) . '-' . wp_generate_password( 4, false );
		}

		remove_action( 'save_post', 'leco_cp_add_default_meta_values' );

		return wp_insert_post( $post_args );

	}

	/**
	 * Get all current published project.
	 *
	 * @since 4.12
	 *
	 * @return array
	 */
	public static function get_all() {

		$options = get_posts(
			array(
				'post_type'   => 'leco_client',
				'numberposts' => - 1,
				'post_status' => 'publish',
			)
		);

		return array_combine( wp_list_pluck( $options, 'ID' ), wp_list_pluck( $options, 'post_title' ) );

	}

	/**
	 * Get project URL.
	 *
	 * @since 4.15
	 *
	 * @param int    $project_id The project ID.
	 * @param string $type       The type of URL to get.
	 *
	 * @return false|string|WP_Error
	 */
	public static function get_project_url( $project_id, $type = 'client' ) {

		return 'admin' === $type ? add_query_arg(
			array(
				'action' => 'edit',
				'post'   => $project_id,
			),
			admin_url( 'post.php' )
		) : get_permalink( $project_id );

	}

	/**
	 * Get the phase title.
	 *
	 * @since 4.15
	 *
	 * @param int $project_id The project ID.
	 * @param int $phase_index The phase index.
	 *
	 * @return string
	 */
	public static function get_phase_title( $project_id, $phase_index ) {

		return get_post_meta( $project_id, "leco_cp_part_{$phase_index}_title", true );

	}

	/**
	 * Get modules.
	 *
	 * @since 4.15
	 *
	 * @param int $project_id  The project ID.
	 * @param int $phase_index The phase index.
	 *
	 * @return mixed
	 */
	public static function get_modules( $project_id, $phase_index ) {

		return get_post_meta( $project_id, "leco_cp_part_{$phase_index}_module", true );

	}

	/**
	 * Get the module info.
	 *
	 * @since 4.15
	 *
	 * @param int    $project_id   The project ID.
	 * @param int    $phase_index  The phase ID.
	 * @param int    $module_index The module ID.
	 * @param string $field        The field.
	 *
	 * @return false|mixed
	 */
	public static function get_module( $project_id, $phase_index, $module_index, $field = '' ) {

		$modules = self::get_modules( $project_id, $phase_index );

		if ( ! $field ) {
			return isset( $modules[ $module_index ] ) ? $modules[ $module_index ] : false;
		} else {
			return isset( $modules[ $module_index ] ) && isset( $modules[ $module_index ][ $field ] ) ? $modules[ $module_index ][ $field ] : false;
		}

	}

	/**
	 * Helper method to get module due date in timestamp format. Return 0 if no due date; return -1 if the due date has expired.
	 *
	 * @since 4.16
	 *
	 * @param int         $project_id The project ID.
	 * @param int         $phase      The phase index.
	 * @param int         $module     The module index.
	 * @param bool|string $formatted  If the value should be formatted. A PHP date format can be passed.
	 *
	 * @return int|string
	 */
	public static function get_module_due_date( $project_id, $phase, $module, $formatted = false ) {

		$due_date = self::get_module( $project_id, $phase, $module, 'due_date' );

		$has_due_date = $due_date && $due_date['enabled'] && $due_date['date'] && $due_date['time'] && ( '0' !== $due_date['reminder'] );

		if ( ! $has_due_date ) {
			return 0;
		}

		$utc_time = Due_Date::date_create_from_format( $due_date, wp_timezone() );

		if ( ! $utc_time ) {
			return 0;
		}

		$timestamp = $utc_time->getTimestamp();

		if ( $timestamp < time() ) {
			return -1;
		}

		if ( $formatted ) {

			if ( true === $formatted ) {
				$formatted = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
			}

			return wp_date( $formatted, $timestamp );

		}

		return $timestamp;

	}

	/**
	 * Check if it's a valid project.
	 *
	 * @since 4.16
	 *
	 * @param int $project_id The project ID.
	 *
	 * @return bool
	 */
	public static function is_valid( $project_id ) {

		$project = get_post( $project_id );
		if ( ! $project || 'publish' !== $project->post_status || 'leco_client' !== $project->post_type ) {
			return false;
		}

		return true;

	}

}
