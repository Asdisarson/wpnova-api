<?php
/**
 * User Object
 *
 * @since       4.11
 * @copyright   Copyright (c) 2021, Laura Elizabeth
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @package     LECO\Client_Portal
 */

namespace LECO\Client_Portal;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_User;

/**
 * Class User
 *
 * @since   4.11
 * @package LECO\Client_Portal
 */
class User {

	/**
	 * Holds an instance of the object
	 *
	 * @var User
	 **/
	private static $instance = null;

	/**
	 * The metabox prefix.
	 *
	 * @var string $prefix
	 */
	private $prefix = 'leco_cp_user_';

	/**
	 * Returns the running object.
	 *
	 * @since 4.11
	 *
	 * @return User
	 **/
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Hooks run when object initialized.
	 *
	 * @since 4.11
	 */
	public function hooks() {

		add_action( 'cmb2_admin_init', array( $this, 'register_user_profile_metabox' ) );
		add_action( 'edit_user_created_user', array( $this, 'create_project' ), 9 );
		add_action( 'edit_user_created_user', array( $this, 'action_attach_project' ), 9 );
		add_action( 'leco_cp_registered_user', array( $this, 'add_user_meta' ), 0, 2 );
		add_action( 'after_password_reset', array( $this, 'create_project' ), 9 );
		add_action( 'after_password_reset', array( $this, 'action_attach_project' ), 9 );
		add_filter( 'wp_new_user_notification_email', array( $this, 'new_user_notification_email' ), 10, 2 );
		add_action( 'leco_cp_updated_user', array( $this, 'add_user_meta' ), 0, 2 );
		add_action( 'leco_cp_updated_user', array( $this, 'create_project' ), 9 );
		add_action( 'leco_cp_updated_user', array( $this, 'action_attach_project' ), 9 );

		// Hook to the register form.
		add_action( 'leco_cp_register', array( $this, 'process_register_form' ) );

	}

	/**
	 * Hook in and add a metabox to add fields to the user profile pages
	 *
	 * @since 4.11
	 */
	public function register_user_profile_metabox() {

		$cmb_user = new_cmb2_box(
			array(
				'id'               => $this->prefix . 'new',
				'title'            => esc_html__( 'Client Portal Settings', 'leco-cp' ), // Doesn't output for user boxes.
				'object_types'     => array( 'user' ), // Tells CMB2 to use user_meta vs post_meta.
				'show_names'       => true,
				'new_user_section' => 'add-new-user', // where form will show on new user page. 'add-existing-user' is only other valid option.
				'show_on_cb'       => function() {
					global $pagenow;
					return 'user-new.php' === $pagenow;
				},
			)
		);

		$cmb_user->add_field(
			array(
				'name' => esc_html__( 'Client Portal Settings', 'leco-cp' ),
				'desc' => esc_html__( 'Custom settings for users in the CP Client role.', 'leco-cp' ),
				'id'   => $this->prefix . 'settings_title',
				'type' => 'title',
			)
		);

		$cmb_user->add_field(
			array(
				'name' => esc_html__( 'Organization', 'leco-cp' ),
				'id'   => $this->prefix . 'organization',
				'type' => 'text',
			)
		);

		// Add create template link.
		$options = leco_cp_get_project_template_options( esc_html__( 'Don\'t create new project', 'leco-cp' ) );
		$desc    = esc_html__( 'Select a project template and we will create a new project with the client. If you don\'t select one, no new project will be created.', 'leco-cp' );
		if ( count( $options ) === 1 ) {
			/* translators: 1. Open a tag; 2. Close a tag. */
			$desc = sprintf( esc_html__( 'You don\'t have any project template yet, please %1$screate one%2$s and come back to use this feature.', 'leco-cp' ), '<a href="' . admin_url( 'post-new.php?post_type=leco_template' ) . '" target="_blank">', '</a>' );
		}

		$cmb_user->add_field(
			array(
				'name'    => esc_html__( 'Create New Project', 'leco-cp' ),
				'desc'    => $desc,
				'id'      => $this->prefix . 'project_template',
				'type'    => 'select',
				'options' => $options,
			)
		);

		$cmb_user->add_field(
			array(
				'name'    => esc_html__( 'Attach a Project', 'leco-cp' ),
				'desc'    => esc_html__( 'You can attach a project to the client.', 'leco-cp' ),
				'id'      => $this->prefix . 'project',
				'type'    => 'select',
				'options' => array_replace( array( '0' => esc_html__( 'Don\'t attach any project.', 'leco-cp' ) ), Project::get_all() ),
			)
		);

		$cmb_user->add_field(
			array(
				'name'    => esc_html__( 'New Project Title', 'leco-cp' ),
				'desc'    => esc_html__( 'The title of your new project.', 'leco-cp' ),
				'id'      => $this->prefix . 'project_title',
				'type'    => 'text',
				'default' => esc_html__( 'New Project', 'leco-cp' ),
			)
		);

		$cmb_user->add_field(
			array(
				'name'    => esc_html__( 'User Notification Subject', 'leco-cp' ),
				'desc'    => esc_html__( 'The email subject of this notification.', 'leco-cp' ),
				'id'      => $this->prefix . 'email_subject',
				'type'    => 'text',
				'default' => leco_cp_settings()->get_notification( 'client_created', '', 'subject' ),
			)
		);

		$cmb_user->add_field(
			array(
				'name'    => esc_html__( 'User Notification Content', 'leco-cp' ),
				'desc'    => leco_cp_settings()->get_email_content_description(),
				'id'      => $this->prefix . 'email_content',
				'type'    => 'wysiwyg',
				'default' => leco_cp_settings()->get_notification( 'client_created', '', 'content' ),
				'options' => array(
					'textarea_rows' => 12,
				),
			)
		);

		$cmb_user = new_cmb2_box(
			array(
				'id'               => $this->prefix . 'edit',
				'title'            => esc_html__( 'Client Portal Settings', 'leco-cp' ),
				// Doesn't output for user boxes.
				'object_types'     => array( 'user' ),
				// Tells CMB2 to use user_meta vs post_meta.
				'show_names'       => true,
				'new_user_section' => 'add-existing-user',
				'show_on_cb'       => function () {
					if ( isset( $_GET['user_id'] ) && user_can( intval( $_GET['user_id'] ), 'leco_client' ) ) {
						return true;
					}

					return false;
				},
			)
		);

		$cmb_user->add_field(
			array(
				'name' => esc_html__( 'Client Portal Settings', 'leco-cp' ),
				'desc' => esc_html__( 'Custom settings for users in the CP Client role.', 'leco-cp' ),
				'id'   => $this->prefix . 'settings_title',
				'type' => 'title',
			)
		);

		$cmb_user->add_field(
			array(
				'name' => esc_html__( 'Organization', 'leco-cp' ),
				'id'   => $this->prefix . 'organization',
				'type' => 'text',
			)
		);

	}

	/**
	 * Create the new project after a user is created.
	 *
	 * @since 4.11
	 * @since 4.12 Support WP_User object in the param.
	 *
	 * @param int|WP_User $user_id_or_user The user ID or WP_User object.
	 */
	public function create_project( $user_id_or_user ) {

		if ( is_a( $user_id_or_user, 'WP_User' ) ) {
			$user_id = $user_id_or_user->ID;
		} else {
			$user_id = $user_id_or_user;
		}

		$template = get_user_meta( $user_id, $this->prefix . 'project_template', true );

		if ( empty( $template ) ) {
			return;
		}

		// Create the new project based on the template.
		Project::create(
			array(
				'template_id' => $template,
				'client_id'   => $user_id,
			)
		);

		// Delete user meta after fetching them.
		delete_user_meta( $user_id, $this->prefix . 'project_template' );
		delete_user_meta( $user_id, $this->prefix . 'project_title' );

	}

	/**
	 * Attach the project to the newly created user.
	 *
	 * @since 4.11
	 * @since 4.12 Support WP_User object in the param.
	 * @since 4.14 Rename from 'attach_project' to 'action_attach_project'.
	 *
	 * @param int|WP_User $user_id_or_user The user ID or WP_User object.
	 */
	public function action_attach_project( $user_id_or_user ) {

		if ( is_a( $user_id_or_user, 'WP_User' ) ) {
			$user_id = $user_id_or_user->ID;
		} else {
			$user_id = $user_id_or_user;
		}

		$project_id = (int) get_user_meta( $user_id, $this->prefix . 'project', true );

		if ( empty( $project_id ) ) {
			return;
		}

		$this->attach_project( $user_id, $project_id );

		// Delete user meta after fetching them.
		delete_user_meta( $user_id, $this->prefix . 'project' );

	}

	/**
	 * Send new user notification with project details.
	 *
	 * @since 4.11
	 *
	 * @param array   $email {
	 *     Used to build wp_mail().
	 *
	 *     @type string $to      The intended recipient - New user email address.
	 *     @type string $subject The subject of the email.
	 *     @type string $message The body of the email.
	 *     @type string $headers The headers of the email.
	 * }
	 * @param WP_User $user     User object for new user.
	 *
	 * @return array
	 */
	public function new_user_notification_email( $email, $user ) {

		// Fix sites with cache plugins cannot get this email as expected because the user data is cached.
		// In the case of W3TC, it's the user caps and roles have not been updated.
		// Retrieve the user data again.
		$user = new WP_User( $user->ID );

		// In multisite network, when the user is created, it doesn't have the role yet.
		if ( is_multisite() && isset( $_POST['role'] ) ) {
			if ( $_POST['role'] !== 'leco_client' ) {
				return $email;
			}
		} elseif ( ! user_can( $user, 'leco_client' ) ) {
			return $email;
		}

		$subject = get_user_meta( $user->ID, $this->prefix . 'email_subject', true );
		if ( empty( $subject ) ) {
			$subject = leco_cp_settings()->get_notification( 'client_created', '', 'subject' );
		}

		$message = get_user_meta( $user->ID, $this->prefix . 'email_content', true );
		if ( empty( $message ) ) {
			$message = leco_cp_settings()->get_notification( 'client_created', '', 'content' );
		}

		// Unset the data property. In unit tests you can carry the data from previous tests.
		leco_client_portal()->emails->__set( 'data', null );
		leco_client_portal()->emails->__set( 'user', $user );
		$message = leco_client_portal()->emails->parse_tags( $message );
		$message = leco_client_portal()->emails->build_email( $message );

		$email['subject'] = leco_client_portal()->emails->parse_tags( $subject );
		$email['message'] = $message;
		$email['headers'] = leco_client_portal()->emails->get_headers();

		// Delete user meta after fetching them.
		delete_user_meta( $user->ID, $this->prefix . 'email_subject' );
		delete_user_meta( $user->ID, $this->prefix . 'email_content' );

		return $email;

	}

	/**
	 * Process the Register Form.
	 *
	 * @since 4.12
	 *
	 * @param array $data Data sent from the register form.
	 *
	 * @return void
	 */
	public function process_register_form( $data ) {

		if ( empty( $_POST['leco_cp_register_submit'] ) ) {
			return;
		}

		$register_another_portal = false;

		if ( is_user_logged_in() ) {
			$register_another_portal = true;
		}

		do_action( 'leco_cp_pre_process_register_form' );

		if ( empty( $data['leco_cp_f_name'] ) ) {
			leco_cp_set_error( 'invalid_first_name', esc_html__( 'The first name cannot be empty.', 'leco-cp' ) );
		}

		if ( empty( $data['leco_cp_l_name'] ) ) {
			leco_cp_set_error( 'invalid_last_name', esc_html__( 'The last name cannot be empty.', 'leco-cp' ) );
		}

		if ( ! $register_another_portal && username_exists( $data['leco_cp_email'] ) ) {
			leco_cp_set_error( 'username_unavailable', esc_html__( 'Email address already taken.', 'leco-cp' ) );
		}

		if ( ! $register_another_portal && email_exists( $data['leco_cp_email'] ) ) {
			leco_cp_set_error( 'email_unavailable', esc_html__( 'Email address already taken.', 'leco-cp' ) );
		}

		if ( empty( $data['leco_cp_email'] ) || ! is_email( $data['leco_cp_email'] ) || ! validate_username( $data['leco_cp_email'] ) ) {
			leco_cp_set_error( 'email_invalid', esc_html__( 'Invalid email', 'leco-cp' ) );
		}

		if ( ! isset( $data['leco_cp_privacy'] ) ) {
			leco_cp_set_error( 'invalid_privacy_cosent', esc_html__( 'You must agree with our privacy terms to register.', 'leco-cp' ) );
		}

		if ( isset( $data['leco_cp_honeypot'] ) && ! empty( $data['leco_cp_honeypot'] ) ) {
			leco_cp_set_error( 'invalid_form_data', esc_html__( 'Registration form validation failed.', 'leco-cp' ) );
		}

		do_action( 'leco_cp_process_register_form' );

		// Check for errors and redirect if none present.
		$errors = leco_cp_get_errors();

		if ( empty( $errors ) ) {

			$redirect = apply_filters( 'leco_cp_register_redirect', $data['leco_cp_redirect'] );

			if ( ! $register_another_portal ) {
				$result = $this->register_user(
					array(
						'user_login'        => $data['leco_cp_email'],
						'user_email'        => $data['leco_cp_email'],
						'user_first'        => $data['leco_cp_f_name'],
						'user_last'         => $data['leco_cp_l_name'],
						'user_organization' => $data['leco_cp_organization'],
						'project'           => isset( $data['leco_cp_project'] ) ? $data['leco_cp_project'] : '',
						'template'          => isset( $data['leco_cp_template'] ) ? $data['leco_cp_template'] : '',
						'project_title'     => isset( $data['leco_cp_project_title'] ) ? $data['leco_cp_project_title'] : '',
					)
				);
			} else {
				$result = $this->update_user(
					array(
						'user_email'        => $data['leco_cp_email'],
						'user_first'        => $data['leco_cp_f_name'],
						'user_last'         => $data['leco_cp_l_name'],
						'user_organization' => $data['leco_cp_organization'],
						'project'           => isset( $data['leco_cp_project'] ) ? $data['leco_cp_project'] : '',
						'template'          => isset( $data['leco_cp_template'] ) ? $data['leco_cp_template'] : '',
						'project_title'     => isset( $data['leco_cp_project_title'] ) ? $data['leco_cp_project_title'] : '',
					)
				);
			}

			if ( $result ) {
				// If we get the POSTed value, it's a real POST request so do the redirect.
				// Otherwise it can be from our unit test etc.
				if ( isset( $_POST['leco_cp_email'] ) ) {
					wp_safe_redirect( $redirect );
					leco_cp_die();
				}
			} else {
				leco_cp_set_error( 'registration_failed', esc_html__( 'We cannot register the user at the moment, please try again later.', 'leco-cp' ) );
			}
		}
	}

	/**
	 * Register New User.
	 *
	 * @since 4.12
	 *
	 * @param array $user_data The data provided by the registration form.
	 *
	 * @return bool
	 */
	private function register_user( $user_data = array() ) {

		// Verify the array.
		if ( empty( $user_data ) ) {
			return false;
		}

		if ( leco_cp_get_errors() ) {
			return false;
		}

		$user_args = apply_filters(
			'leco_cp_insert_user_args',
			array(
				'user_login'      => isset( $user_data['user_login'] ) ? $user_data['user_login'] : '',
				'user_pass'       => isset( $user_data['user_pass'] ) ? $user_data['user_pass'] : wp_generate_password( 20 ),
				'user_email'      => isset( $user_data['user_email'] ) ? $user_data['user_email'] : '',
				'first_name'      => isset( $user_data['user_first'] ) ? $user_data['user_first'] : '',
				'last_name'       => isset( $user_data['user_last'] ) ? $user_data['user_last'] : '',
				'user_registered' => date( 'Y-m-d H:i:s' ),
				'role'            => 'leco_client',
			),
			$user_data
		);

		// Insert new user.
		$user_id = wp_insert_user( $user_args );

		// Validate inserted user.
		if ( is_wp_error( $user_id ) ) {
			return false;
		}

		// Allow themes and plugins to filter the user data.
		$user_data = apply_filters( 'leco_cp_registered_user_data', $user_data, $user_args );

		// Add our custom meta.
		add_user_meta( $user_id, $this->prefix . 'organization', $user_data['user_organization'] );

		// Allow themes and plugins to hook, and we also create/attach the project here.
		do_action( 'leco_cp_registered_user', $user_id, $user_data );

		// Set the successful registered session.
		leco_client_portal()->session->set( 'leco_cp_registered_user', $user_id );

		return true;
	}

	/**
	 * Update an existing User.
	 *
	 * @since 4.12
	 *
	 * @param array $user_data The data provided by the registration form.
	 *
	 * @return bool
	 */
	private function update_user( $user_data = array() ) {

		// Verify the array.
		if ( empty( $user_data ) ) {
			return false;
		}

		if ( leco_cp_get_errors() ) {
			return false;
		}

		$user_args = apply_filters(
			'leco_cp_update_user_args',
			array(
				'ID'         => get_current_user_id(),
				'user_email' => isset( $user_data['user_email'] ) ? $user_data['user_email'] : '',
				'first_name' => isset( $user_data['user_first'] ) ? $user_data['user_first'] : '',
				'last_name'  => isset( $user_data['user_last'] ) ? $user_data['user_last'] : '',
			),
			$user_data
		);

		// Update the user.
		$user_id = wp_update_user( $user_args );

		// Update the role.
		$this->add_role( $user_id );

		// Validate updated user.
		if ( is_wp_error( $user_id ) ) {
			return false;
		}

		// Allow themes and plugins to filter the user data.
		$user_data = apply_filters( 'leco_cp_updated_user_data', $user_data, $user_args );

		// Add our custom meta.
		update_user_meta( $user_id, $this->prefix . 'organization', $user_data['user_organization'] );

		// Allow themes and plugins to hook, and we also create/attach the project here.
		do_action( 'leco_cp_updated_user', $user_id, $user_data );

		// Set the successful registered session.
		leco_client_portal()->session->set( 'leco_cp_registered_user', $user_id );

		return true;
	}

	/**
	 * Add user meta so later on we can create or attach project to them.
	 *
	 * @since 4.12
	 *
	 * @param int   $user_id   The user ID.
	 * @param array $user_data The user data.
	 */
	public function add_user_meta( $user_id, $user_data ) {

		if ( isset( $user_data['project'] ) && get_post_type( $user_data['project'] ) === 'leco_client' ) {
			add_user_meta( $user_id, $this->prefix . 'project', $user_data['project'] );

			return;
		} else {
			$default_project = leco_cp_get_option( 'default_project', '', 'register-login' );
		}

		if ( isset( $user_data['template'] ) && get_post_type( $user_data['template'] ) === 'leco_template' ) {
			add_user_meta( $user_id, $this->prefix . 'project_template', $user_data['template'] );
			if ( isset( $user_data['project_title'] ) ) {
				add_user_meta( $user_id, $this->prefix . 'project_title', sanitize_text_field( $user_data['project_title'] ) );
			}

			return;
		} else {
			$default_project_template = leco_cp_get_option( 'default_project_template', '', 'register-login' );
			$default_project_title    = leco_cp_get_option( 'default_project_title', '', 'register-login' );
		}

		if ( ! empty( $default_project_template ) ) {
			add_user_meta( $user_id, $this->prefix . 'project_template', $default_project_template );
			add_user_meta( $user_id, $this->prefix . 'project_title', $default_project_title );
		} elseif ( ! empty( $default_project ) ) {
			add_user_meta( $user_id, $this->prefix . 'project', $default_project );
		}

	}

	/**
	 * Add the role to the user.
	 *
	 * @since 4.14
	 *
	 * @param int $user_id The user id.
	 *
	 * @return void
	 */
	public static function add_role( $user_id ) {

		$user = new WP_User( $user_id );
		$user->add_role( 'leco_client' );

		// We must flush the cache or the user role won't update in the runtime.
		clean_user_cache( $user );

	}

	/**
	 * Attach the project to the user and add the user to the project.
	 *
	 * @since 4.14
	 *
	 * @param int $user_id    The user id.
	 * @param int $project_id The project id.
	 *
	 * @return void
	 */
	public static function attach_project( $user_id, $project_id ) {

		// Add the client to project.
		$current_project_clients = get_post_meta( $project_id, 'leco_cp_client', true );
		if ( is_array( $current_project_clients ) ) {
			$current_project_clients[] = $user_id;
			// Ensure we don't duplicate the values.
			$current_project_clients = array_values( array_unique( $current_project_clients ) );
		} else {
			$current_project_clients = array( $user_id );
		}
		update_post_meta( $project_id, 'leco_cp_client', $current_project_clients );

		// Add the project to the client.
		leco_cp_set_user_projects( $user_id, $project_id );

	}

}
