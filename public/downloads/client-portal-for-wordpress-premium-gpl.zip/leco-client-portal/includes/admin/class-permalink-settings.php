<?php
/**
 * Adds settings to the permalinks admin settings page.
 *
 * This class is derived from WooCommerce.
 *
 * @class LECO_CP_Permalink_Settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LECO_CP_Permalink_Settings Class.
 */
class LECO_CP_Permalink_Settings {

	/**
	 * Permalink settings.
	 *
	 * @var array
	 */
	private $permalinks = array();

	/**
	 * Hook in tabs.
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'settings_init' ) );

		$this->settings_save();
	}

	/**
	 * Init our settings.
	 */
	public function settings_init() {
		add_settings_section( 'leco-cp-permalink', __( 'Client Portal permalinks', 'leco-cp' ), array( $this, 'settings' ), 'permalink' );

		$this->permalinks = leco_cp_get_permalink_structure();
	}

	/**
	 * Show the settings.
	 */
	public function settings() {
		/* translators: %s: Home URL */
		echo wp_kses_post( wpautop( sprintf( __( 'By default, the Client Portal project URL structure starts with <code>client</code>. You can change it to other values here. For example, using <code>project</code> would make your project links like <code>%sproject/sample-client/</code>.', 'leco-cp' ), esc_url( home_url( '/' ) ) ) ) );

		$project_base = _x( 'client', 'default-slug', 'leco-cp' );

		$structures = array(
			0 => '',
			1 => '/' . trailingslashit( $project_base ),
		);
		?>
		<table class="form-table leco-cp-permalink-structure">
			<tbody>
			<tr>
				<th><label><input name="project_permalink" type="radio" value="<?php echo esc_attr( $structures[0] ); ?>" class="lecotog" <?php checked( $structures[0], $this->permalinks['project_base'] ); ?> /> <?php esc_html_e( 'Default', 'leco-cp' ); ?></label></th>
				<td><code class="default-example"><?php echo esc_html( home_url() ); ?>/?client=sample-client</code> <code class="non-default-example"><?php echo esc_html( home_url() ); ?>/<?php echo esc_html( $project_base ); ?>/sample-client/</code></td>
			</tr>
			<tr>
				<th><label><input name="project_permalink" id="leco_cp_custom_selection" type="radio" value="custom" class="tog" <?php checked( in_array( $this->permalinks['project_base'], $structures, true ), false ); ?> />
						<?php esc_html_e( 'Custom base', 'leco-cp' ); ?></label></th>
				<td>
					<input name="project_permalink_structure" id="leco_cp_permalink_structure" type="text" value="<?php echo esc_attr( $this->permalinks['project_base'] ? trailingslashit( $this->permalinks['project_base'] ) : '' ); ?>" class="regular-text code"> <span class="description"><?php esc_html_e( 'Enter a custom base to use. A base must be set or WordPress will use default instead.', 'leco-cp' ); ?></span>
				</td>
			</tr>
			</tbody>
		</table>
		<?php wp_nonce_field( 'leco-cp-permalinks', 'leco-cp-permalinks-nonce' ); ?>
		<script type="text/javascript">
			jQuery( function() {
				jQuery('input.lecotog').change(function() {
					jQuery('#leco_cp_permalink_structure').val( jQuery( this ).val() );
				});
				jQuery('.permalink-structure input').change(function() {
					jQuery('.leco-cp-permalink-structure').find('code.non-default-example, code.default-example').hide();
					if ( jQuery(this).val() ) {
						jQuery('.leco-cp-permalink-structure code.non-default-example').show();
						jQuery('.leco-cp-permalink-structure input').removeAttr('disabled');
					} else {
						jQuery('.leco-cp-permalink-structure code.default-example').show();
						jQuery('.leco-cp-permalink-structure input:eq(0)').click();
						jQuery('.leco-cp-permalink-structure input').attr('disabled', 'disabled');
					}
				});
				jQuery('.permalink-structure input:checked').change();
				jQuery('#leco_cp_permalink_structure').focus( function(){
					jQuery('#leco_cp_custom_selection').click();
				} );
			} );
		</script>
		<?php
	}

	/**
	 * Save the settings.
	 */
	public function settings_save() {
		if ( ! is_admin() ) {
			return;
		}

		if ( ! isset( $_POST['permalink_structure'], $_POST['leco-cp-permalinks-nonce'] ) ) {
			return;
		}

		if ( ! function_exists( 'wp_verify_nonce' ) ) {
			require( ABSPATH . WPINC . '/pluggable.php' );
		}

		// We need to save the options ourselves; settings api does not trigger save for the permalinks page.
		if ( wp_verify_nonce( wp_unslash( $_POST['leco-cp-permalinks-nonce'] ), 'leco-cp-permalinks' ) ) { // WPCS: input var ok, sanitization ok.

			$permalinks = (array) get_option( 'leco_cp_permalinks', array() );
			// Generate project base.
			$project_base = isset( $_POST['project_permalink'] ) ? sanitize_text_field( wp_unslash( $_POST['project_permalink'] ) ) : ''; // WPCS: input var ok, sanitization ok.

			if ( 'custom' === $project_base ) {
				if ( isset( $_POST['project_permalink_structure'] ) ) { // WPCS: input var ok.
					$project_base = preg_replace( '#/+#', '/', '/' . str_replace( '#', '', trim( wp_unslash( $_POST['project_permalink_structure'] ) ) ) ); // WPCS: input var ok, sanitization ok.
				} else {
					$project_base = '/';
				}
			} elseif ( empty( $project_base ) ) {
				$project_base = _x( 'client', 'slug', 'leco-cp' );
			}

			$permalinks['project_base'] = leco_cp_sanitize_permalink( $project_base );

			update_option( 'leco_cp_permalinks', $permalinks );
		}
	}
}

new LECO_CP_Permalink_Settings();
