<?php
/**
 * Settings
 *
 * @since   1.0.0
 * @package ClientPortal\Settings
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LECO\Client_Portal\Login;
use LECO\Client_Portal\Project;
use LECO\Client_Portal\Notifications;

/**
 * CMB2 Theme Options
 *
 * @since 0.1.0
 *
 * @property string $key The key prop.
 */
class LECO_CP_Settings {
	/**
	 * Holds an instance of the object
	 *
	 * @var LECO_CP_Settings
	 **/
	private static $instance = null;
	/**
	 * Options Page title
	 *
	 * @var string
	 */
	protected $title = '';
	/**
	 * License Page title
	 *
	 * @var string
	 */
	protected $license_page_title = '';
	/**
	 * Options Page hook
	 *
	 * @var string
	 */
	protected $options_page = '';
	/**
	 * Option key, and option page slug
	 *
	 * @var string
	 */
	private $key = 'leco_cp_options';
	/**
	 * License page key, and page slug
	 *
	 * @var string
	 */
	private $license_page_key = 'leco_cp_license';
	/**
	 * Options page metabox id
	 *
	 * @var string
	 */
	private $metabox_id = 'leco_cp_option_metabox';

	/**
	 * The notification settings.
	 *
	 * @since 4.15
	 *
	 * @var Notifications\Settings
	 */
	private $notification_settings;

	/**
	 * Constructor
	 *
	 * @since 0.1.0
	 */
	private function __construct() {
		// Set our title.
		$this->title              = __( 'Client Portal Settings', 'leco-cp' );
		$this->license_page_title = __( 'Client Portal License', 'leco-cp' );

		$notifications               = leco_client_portal()->notifications();
		$this->notification_settings = new Notifications\Settings( $notifications );

	}

	/**
	 * Returns the running object
	 *
	 * @return LECO_CP_Settings
	 **/
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	 * Initiate our hooks
	 *
	 * @since 0.1.0
	 */
	public function hooks() {
		add_action( 'admin_init', array( $this, 'init' ) );
		add_action( 'admin_init', array( $this, 'activate_license' ) );
		add_action( 'admin_init', array( $this, 'deactivate_license' ) );
		add_action( 'admin_notices', array( $this, 'license_page_notices' ) );
		add_action( 'admin_menu', array( $this, 'add_options_page' ) );
		add_action( 'admin_menu', array( $this, 'add_license_page' ) );
		add_action( 'cmb2_admin_init', array( $this, 'add_options_page_metabox' ) );
		add_action( 'cmb2_before_form', array( $this, 'notification_sent_notices' ), 10, 2 );
	}

	/**
	 * Register our setting to WP
	 *
	 * @since  0.1.0
	 */
	public function init() {
		register_setting( $this->key, $this->key );
		register_setting( $this->license_page_key, 'leco_cp_license_key', array( $this, 'sanitize_license_key' ) );
	}

	/**
	 * Add menu options page
	 *
	 * @since 0.1.0
	 */
	public function add_options_page() {
		$this->options_page = add_submenu_page(
			'edit.php?post_type=leco_client',
			$this->title,
			$this->title,
			'manage_options',
			$this->key,
			array(
				$this,
				'admin_page_display',
			)
		);
		// Include CMB CSS in the head to avoid FOUC.
		add_action( "admin_print_styles-{$this->options_page}", array( 'CMB2_hookup', 'enqueue_cmb_css' ) );
	}

	/**
	 * Add menu options page
	 *
	 * @since 0.1.0
	 */
	public function add_license_page() {
		$this->options_page = add_submenu_page(
			'edit.php?post_type=leco_client',
			$this->license_page_title,
			$this->license_page_title,
			'manage_options',
			$this->license_page_key,
			array(
				$this,
				'license_page_display',
			)
		);
	}

	/**
	 * Admin page markup. Mostly handled by CMB2
	 *
	 * @since  0.1.0
	 */
	public function admin_page_display() {
		?>
		<div class="wrap cmb2-options-page <?php echo esc_attr( $this->key ); ?>">
			<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>
			<?php
			$tabs = $this->get_tabs();
			$url  = menu_page_url( $this->key, false );
			$tab  = '';

			$_tab     = isset( $_GET['tab'] ) ? $_GET['tab'] : ''; // phpcs:ignore.
			$_section = isset( $_GET['section'] ) ? $_GET['section'] : ''; // phpcs:ignore.
			$sections = array();
			if ( ! $_tab ) {
				?>
			<div class="notice notice-warning">
				<p>We treat the settings on this page as the default values when you create a new portal. They are also
					the fallback values when fields are left empty.
				</p>
				<p>If you want to leave empty fields blank in your portals, make sure you select “No” under “Use default
					settings for empty fields“.
				</p>
			</div>
			<?php } ?>
			<h2 class="nav-tab-wrapper">
				<?php
				foreach ( $tabs as $option_key => $tab_data ) {
					$tab_title = $tab_data['title'];

					if ( $option_key !== $this->key ) {
						$tab = str_replace( $this->key . '_', '', $option_key );
						$url = add_query_arg( array( 'tab' => $tab ) );
					}
					?>
					<a class="nav-tab
					<?php
					if ( empty( $_tab ) && $option_key === $this->key || ( $option_key !== $this->key && $tab === $_tab ) ) :
						$sections = $tab_data['sections'];
						?>
						nav-tab-active<?php endif; ?>"
							href="<?php echo esc_url( $url ); ?>"><?php echo wp_kses_post( $tab_title ); ?></a>
				<?php } ?>
			</h2>
			<?php
			if ( ! empty( $_tab ) ) {
				$tab = '_' . sanitize_text_field( $_tab );
			} else {
				$tab = '';
			}

			// Get sections (groups) menu.
			$number_of_sections = count( $sections );
			$number             = 0;
			if ( $number_of_sections > 1 ) {
				echo '<div class="wp-clearfix"><ul class="subsubsub">';
				foreach ( $sections as $section_id => $section_name ) {
					$section_id = str_replace( $this->metabox_id . '_' . sanitize_text_field( $_tab ) . '_', '', $section_id );
					echo '<li>';
					$number ++;
					$tab_url = add_query_arg(
						array(
							'settings-updated' => false,
							'tab'              => sanitize_text_field( $_tab ),
							'section'          => $section_id,
						)
					);
					$class   = '';
					if ( ( empty( $_section ) && 1 === $number ) || $_section == $section_id ) {
						$class = 'current';
					}
					echo '<a class="' . $class . '" href="' . esc_url( $tab_url ) . '">' . $section_name . '</a>';

					if ( $number != $number_of_sections ) {
						echo ' | ';
					}
					echo '</li>';
				}
				echo '</ul></div>';
			}

			cmb2_metabox_form( $this->metabox_id . $tab, $this->key . $tab, array( 'save_button' => esc_html__( 'Save Changes', 'leco-cp' ) ) );
			?>
		</div>
		<?php
	}

	/**
	 * Gets navigation tabs array for CMB2 options pages which share the given display_cb param.
	 *
	 * @since 4.9
	 */
	private function get_tabs() {
		$tabs = array();

		$metaboxes = CMB2_Boxes::get_all();
		foreach ( $metaboxes as $cmb ) {
			if ( in_array( $cmb->prop( 'tab_group' ), array( $this->key ), true ) ) {
				$tabs[ $cmb->options_page_keys()[0] ] = array(
					'title'    => $cmb->prop( 'tab_title' ) ? $cmb->prop( 'tab_title' ) : $cmb->prop( 'title' ),
					'sections' => array(),
				);

				$fields = $cmb->prop( 'fields' );
				foreach ( $fields as $field ) {
					if ( 'group' === $field['type'] ) {
						$tabs[ $cmb->options_page_keys()[0] ]['sections'][ $field['id'] ] = $field['options']['group_title'];
					}
				}
			}
		}

		return $tabs;
	}

	/**
	 * License page markup.
	 *
	 * @since 3.0.0
	 */
	public function license_page_display() {
		$license = get_option( 'leco_cp_license_key' );
		$status  = get_option( 'leco_cp_license_status' );
		?>
		<div class="wrap">
			<h2><?php esc_html_e( 'Client Portal License', 'leco-cp' ); ?></h2>
			<form method="post" action="options.php">
				<?php settings_fields( $this->license_page_key ); ?>
				<table class="form-table">
					<tbody>
					<tr valign="top">
						<th scope="row" valign="top">
							<?php esc_html_e( 'License Key', 'leco-cp' ); ?>
						</th>
						<td>
							<input id="leco_cp_license_key" name="leco_cp_license_key" type="password"
									class="regular-text" value="<?php echo esc_attr( $license ); ?>"/>
							<label class="description"
									for="leco_cp_license_key"><?php esc_html_e( 'Enter your license key', 'leco-cp' ); ?></label>
						</td>
					</tr>
					<?php if ( ! empty( $license ) ) { ?>
						<tr valign="top">
							<th scope="row" valign="top">
								<?php esc_html_e( 'License Status', 'leco-cp' ); ?>
							</th>
							<td>
								<?php if ( 'valid' === $status ) { ?>
									<span style="color:green;"><?php esc_html_e( 'active', 'leco-cp' ); ?></span>
									<?php wp_nonce_field( 'leco_cp_nonce', 'leco_cp_nonce' ); ?>
									<input type="submit" class="button-secondary" name="leco_cp_license_deactivate"
											value="<?php esc_attr_e( 'Deactivate License', 'leco-cp' ); ?>"/>
								<?php } ?>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
				<?php submit_button( esc_html__( 'Save Changes', 'leco-cp' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Add the options metabox to the array of metaboxes
	 *
	 * @since  0.1.0
	 */
	public function add_options_page_metabox() {
		// hook in our save notices.
		add_action( "cmb2_save_options-page_fields_{$this->metabox_id}", array( $this, 'settings_notices' ), 10, 2 );
		$cmb = new_cmb2_box(
			array(
				'id'         => $this->metabox_id,
				'hookup'     => false,
				'cmb_styles' => false,
				'tab_group'  => $this->key,
				'tab_title'  => esc_html__( 'General', 'leco-cp' ),
				'show_on'    => array(
					// These are important, don't remove.
					'key'   => 'options-page',
					'value' => array( $this->key ),
				),
			)
		);
		// Set our CMB2 fields.
		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Use default settings for empty fields', 'leco-cp' ),
				'desc'    => esc_html__( 'If you select “Yes”, we’ll load the values from Client Portal Settings into the empty fields in your portal. If you select “No”, we will leave all empty fields blank. You can also change this in the Custom Branding section in each portal.', 'leco-cp' ),
				'id'      => 'fallback_values',
				'type'    => 'select',
				'options' => array(
					'yes' => esc_html__( 'Yes', 'leco-cp' ),
					'no'  => esc_html__( 'No', 'leco-cp' ),
				),
			)
		);

		$cmb->add_field(
			array(
				'name' => __( 'Your Name', 'leco-cp' ),
				'id'   => 'name',
				'type' => 'text',
			)
		);

		$cmb->add_field(
			array(
				'name'       => esc_html__( 'Your Logo', 'leco-cp' ),
				'desc'       => esc_html__( 'Upload an image or enter a URL.', 'leco-cp' ),
				'id'         => 'logo',
				'type'       => 'file',
				'query_args' => array(
					// Or only allow gif, jpg, or png images
					'type' => array(
						'image/gif',
						'image/jpeg',
						'image/png',
						'image/svg+xml',
					),
				),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Fixed logo width', 'leco-cp' ),
				'desc'    => esc_html__( 'If select "Yes", we\'ll set the logo image width to 270px.', 'leco-cp' ),
				'id'      => 'logo_fixed_width',
				'type'    => 'select',
				'options' => array(
					'yes' => esc_html__( 'Yes', 'leco-cp' ),
					'no'  => esc_html__( 'No', 'leco-cp' ),
				),
			)
		);

		$cmb->add_field(
			array(
				'name' => esc_html__( 'Header Image', 'leco-cp' ),
				'desc' => esc_html__( 'Upload an image or enter a URL.', 'leco-cp' ),
				'id'   => 'header_background_image',
				'type' => 'file',
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Primary Background Color', 'leco-cp' ),
				'id'      => 'primary_color',
				'type'    => 'colorpicker',
				'default' => '#52cdf5',
				'classes' => array( 'color', 'leco-cp-background' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Primary Text Color', 'leco-cp' ),
				'id'      => 'primary_text_color',
				'type'    => 'colorpicker',
				'default' => '#ffffff',
				'classes' => array( 'color' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Secondary Background Color', 'leco-cp' ),
				'id'      => 'secondary_color',
				'type'    => 'colorpicker',
				'default' => '#ff5f5f',
				'classes' => array( 'color', 'leco-cp-background' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Secondary Text Color', 'leco-cp' ),
				'id'      => 'secondary_text_color',
				'type'    => 'colorpicker',
				'default' => '#ffffff',
				'classes' => array( 'color' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Tertiary Background Color', 'leco-cp' ),
				'id'      => 'tertiary_color',
				'type'    => 'colorpicker',
				'default' => '#3c5063',
				'classes' => array( 'color', 'leco-cp-background' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Tertiary Text Color', 'leco-cp' ),
				'id'      => 'tertiary_text_color',
				'type'    => 'colorpicker',
				'default' => '#ffffff',
				'classes' => array( 'color' ),
			)
		);

		$cmb->add_field(
			array(
				/* translators: 1. Open code tag 2. Close code tag */
				'name' => sprintf( esc_html__( 'Custom Scripts in %1$shead%2$s', 'leco-cp' ), '<code>', '</code>' ),
				'desc' => __( 'You may need some custom scripts for your portals. For example, the embed code from Typekit or Google Fonts. You can add them here.', 'leco-cp' ),
				'id'   => 'head',
				'type' => 'textarea_code',
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Theme', 'leco-cp' ),
				'desc'    => esc_html__( 'You can switch to the Legacy theme if you encounter issues with the latest Default theme.', 'leco-cp' ) . ' <strong>' . esc_html__( 'Note that Legacy theme does not support features released after version 4.7.', 'leco-cp' ) . '</strong>',
				'id'      => 'template',
				'type'    => 'select',
				'options' => array(
					'default'  => esc_html__( 'Legacy', 'leco-cp' ),
					'tailwind' => esc_html__( 'Default', 'leco-cp' ),
				),
				'default' => 'tailwind',
			)
		);

		$desc = sprintf(
		/* translators: 1. br tag 2. Open code tag 3. Close code tag */
			esc_html__( 'Add your own custom CSS to style the portal. %1$s Each project has a "postid-{ID}" class in the %2$sbody%3$s element. %1$s So you can do things like %2$s.postid-212 h2 {color: red}%3$s to specify styles for a certain project.', 'leco-cp' ),
			'<br />',
			'<code>',
			'</code>'
		);

		$cmb->add_field(
			array(
				'name'            => esc_html__( 'Custom CSS - Legacy theme', 'leco-cp' ),
				'desc'            => $desc,
				'id'              => 'css',
				'type'            => 'textarea_code',
				'classes'         => array( 'custom-css' ),
				'sanitization_cb' => false,
			)
		);

		$cmb->add_field(
			array(
				'name'            => esc_html__( 'Custom CSS - Default theme', 'leco-cp' ),
				'desc'            => $desc,
				'id'              => 'css_tailwind',
				'type'            => 'textarea_code',
				'classes'         => array( 'custom-css' ),
				'sanitization_cb' => false,
			)
		);

		$cmb->add_field(
			array(
				'name' => esc_html__( 'Your Phone', 'leco-cp' ),
				'id'   => 'phone',
				'type' => 'text_medium',
			)
		);

		$cmb->add_field(
			array(
				'name' => esc_html__( 'Your Email', 'leco-cp' ),
				'id'   => 'email',
				'type' => 'text_email',
			)
		);

		$general_information = wpautop(
			'Hello and welcome! Here you can find everything you need during our project from all your files to how to contact me. You\'ll have full access to this area throughout the whole project and for 6 months after completion. However all of your files will still live on in <a href="#">your project folder.</a>
<h2>How to contact me</h2>
If you have any small questions or comments throughout the project, you can <a class="email" href="mailto:#">email me.</a> For anything larger it\'s best to wait until our next catch up call so we can go through it properly. Our call is scheduled for every <strong>[date-time]</strong>
<h2>Availability</h2>
My working week is <strong>[your-working-hours]</strong>

Occasionally I take time off for holidays so if this is due to happen during our project I will let you know in good time. Other than that you can expect intermittent availability around all major holidays including Christmas, New Year, Easter and (ok, not a major holiday) my birthday - [your-birthday-if-you-like]'
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'General Information', 'leco-cp' ),
				'id'      => 'general_information',
				'desc'    => esc_html__( 'Write some general information about a project, including: welcome messages, contact information and your availability.', 'leco-cp' ),
				'type'    => 'wysiwyg',
				'options' => array( 'textarea_rows' => 12 ),
				'default' => $general_information,
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Show project status?', 'leco-cp' ),
				'desc'    => esc_html__( 'This will hide the "Project Status" section (Current/Next Phase & Estimated Completion Date). The default is "Yes".', 'leco-cp' ),
				'id'      => 'show_project_status',
				'type'    => 'select',
				'options' => array(
					'show' => esc_html__( 'Yes', 'leco-cp' ),
					'hide' => esc_html__( 'No', 'leco-cp' ),
				),
			)
		);

		$cmb->add_field(
			array(
				'name'    => __( 'Phase X Text', 'leco-cp' ),
				/* translators: 1. Open link tag 2. Close link tag */
				'desc'    => sprintf( __( 'Fancy to change the "Phase 1, 2, 3" terminology to something else? You can replace it here. Say if you enter "Section", you\'ll get them to be "Section 1, 2, 3" in all your portals, unless you give different values in portal settings. You can also remove the numbers (1, 2, 3...) from it with CSS, %1$shere\'s how%2$s.', 'leco-cp' ), '<a href="https://client-portal.io/client/client-portal-support/module/how-do-i-edit-the-phase-1-2-3-etc-text/" target="_blank">', '</a>' ),
				'id'      => 'phase_x_text',
				'type'    => 'text',
				'default' => __( 'Phase', 'leco-cp' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Show the mark as complete ticks?', 'leco-cp' ),
				'desc'    => esc_html__( 'This will enable the client side "Mark as Complete" feature for each module. The default is "Show for modules with a due date".', 'leco-cp' ),
				'id'      => 'show_mark_as_complete',
				'type'    => 'select',
				'options' => array(
					'show_with_due_date' => esc_html__( 'Show for modules with a due date', 'leco-cp' ),
					'show'               => esc_html__( 'Show for all modules', 'leco-cp' ),
					'hide'               => esc_html__( 'No', 'leco-cp' ),
				),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Open Link in New Tab?', 'leco-cp' ),
				'desc'    => esc_html__( 'Set if the module URL should be opened in new tab. The default is "Yes".', 'leco-cp' ),
				'id'      => 'new_tab',
				'type'    => 'select',
				'options' => array(
					'new_tab' => esc_html__( 'Yes', 'leco-cp' ),
					'current' => esc_html__( 'No', 'leco-cp' ),
				),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Collapse all modules?', 'leco-cp' ),
				'desc'    => esc_html__( 'All modules are collapsed by default. Select "No" if you\'d like them to be expanded.', 'leco-cp' ),
				'id'      => 'module_status',
				'type'    => 'select',
				'options' => array(
					'closed' => esc_html__( 'Yes', 'leco-cp' ),
					'opened' => esc_html__( 'No', 'leco-cp' ),
				),
			)
		);

		add_action( "cmb2_save_options-page_fields_{$this->metabox_id}_notifications", array( $this, 'settings_notices' ), 10, 2 );
		$cmb = new_cmb2_box(
			array(
				'id'          => $this->metabox_id . '_notifications',
				'hookup'      => false,
				'cmb_styles'  => false,
				'parent_slug' => $this->key,
				'tab_group'   => $this->key,
				'tab_title'   => esc_html__( 'Notifications', 'leco-cp' ),
				'show_on'     => array(
					'key'   => 'options-page',
					'value' => array( $this->key . '_notifications' ),
				),
			)
		);

		$group_field_id = $cmb->add_field(
			array(
				'id'         => 'general',
				'desc'       => esc_html__( 'General settings for notifications.', 'leco-cp' ),
				'type'       => 'group',
				'repeatable' => false,
				'options'    => array(
					'group_title' => esc_html__( 'General', 'leco-cp' ),
				),
				'show_on_cb' => array( $this, 'get_active_section' ),
			)
		);

		$cmb->add_group_field(
			$group_field_id,
			array(
				'name' => esc_html__( 'Notifications Configuration', 'leco-cp' ),
				'desc' => esc_html__( 'General settings that will apply as default values for all notifications.', 'leco-cp' ),
				'id'   => 'title',
				'type' => 'title',
			)
		);

		$cmb->add_group_field(
			$group_field_id,
			array(
				'name'    => esc_html__( 'Email Format', 'leco-cp' ),
				'desc'    => esc_html__( 'Select HTML or plain text emails.', 'leco-cp' ),
				'id'      => 'template',
				'type'    => 'select',
				'options' => array(
					'default' => esc_html__( 'HTML', 'leco-cp' ),
					'none'    => esc_html__( 'Plain Text', 'leco-cp' ),
				),
				'default' => 'default',
			)
		);

		$cmb->add_group_field(
			$group_field_id,
			array(
				'name'       => esc_html__( 'Logo', 'leco-cp' ),
				'desc'       => esc_html__( 'Upload an image or enter a URL.', 'leco-cp' ),
				'id'         => 'logo',
				'type'       => 'file',
				// query_args are passed to wp.media's library query.
				'query_args' => array(
					// Or only allow gif, jpg, or png images
					'type' => array(
						'image/gif',
						'image/jpeg',
						'image/png',
						'image/svg+xml',
					),
				),
				'default'    => $this->get_option( 'logo' ),
			)
		);

		$cmb->add_group_field(
			$group_field_id,
			array(
				'name'    => esc_html__( 'From Name', 'leco-cp' ),
				'desc'    => esc_html__( 'Set up the from name. The default is your site name.', 'leco-cp' ),
				'id'      => 'name',
				'type'    => 'text',
				'default' => get_bloginfo( 'name' ),
			)
		);

		$cmb->add_group_field(
			$group_field_id,
			array(
				'name'    => esc_html__( 'From Email', 'leco-cp' ),
				'desc'    => esc_html__( 'Set up the from email address. The default is the WordPress admin email. This is also where the admin notifications will sent to.', 'leco-cp' ),
				'id'      => 'from',
				'type'    => 'text',
				'default' => get_bloginfo( 'admin_email' ),
			)
		);

		$cmb->add_group_field(
			$group_field_id,
			array(
				'name'    => esc_html__( 'Link Color', 'leco-cp' ),
				'id'      => 'link_color',
				'type'    => 'colorpicker',
				'desc'    => esc_html__( 'Setting up link color in your email. Note that not all email client supports link colors. For example, you may still see good old blue links in Gmail.', 'leco-cp' ),
				'default' => leco_cp_get_option( 'secondary_color', '#ff5f5f' ),
			)
		);

		$this->notification_settings->add_groups( $cmb );

		add_action( "cmb2_save_options-page_fields_{$this->metabox_id}_register-login", array( $this, 'settings_notices' ), 10, 2 );
		$cmb = new_cmb2_box(
			array(
				'id'          => $this->metabox_id . '_register-login',
				'hookup'      => false,
				'cmb_styles'  => false,
				'parent_slug' => $this->key,
				'tab_group'   => $this->key,
				'tab_title'   => esc_html__( 'Register / Login', 'leco-cp' ),
				'show_on'     => array(
					'key'   => 'options-page',
					'value' => array( $this->key . '_register-login' ),
				),
			)
		);

		$cmb->add_field(
			array(
				'name' => esc_html__( 'Registration Configuration', 'leco-cp' ),
				'desc' => esc_html__( 'Registration is only enabled when you have a selected value in Create New Project or Attach a Project field below.', 'leco-cp' ),
				'id'   => 'registration_configuration',
				'type' => 'title',
			)
		);

		$pages  = get_pages();
		$titles = wp_list_pluck( $pages, 'post_title' );
		$ids    = wp_list_pluck( $pages, 'ID' );
		$pages  = array_combine( $ids, $titles );

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Client Portal Login Page', 'leco-cp' ),
				/* translators: 1. Open code tag; 2. Close code tag. */
				'desc'    => sprintf( esc_html__( 'By default, a page titled "Client Portal Login" is created and set for you. You can select a different page as the Client Portal Login page, the page must have the %1$s[client_portal_login]%2$s shortcode or the Client Portal Login Form block in it.', 'leco-cp' ), '<code>', '</code>' ),
				'id'      => 'client_portal_login',
				'type'    => 'select',
				'options' => $pages,
				'default' => leco_cp_get_option( 'client_portal_login', Login::default_login_page(), 'register-login' ),
			)
		);

		$options = leco_cp_get_project_template_options( esc_html__( 'Don\'t create new project', 'leco-cp' ) );
		/* translators: 1. Open code tag; 2. Close code tag. */
		$desc = sprintf( esc_html__( 'Choose a project template. When a new client registered from the %1$s[client_portal_register]%2$s shortcode or the Client Portal Register Form block, a new project will be created and attached to them.', 'leco-cp' ), '<code>', '</code>' );
		if ( count( $options ) === 1 ) { // Add create template link.
			/* translators: 1. Open a tag; 2. Close a tag. */
			$desc = sprintf( esc_html__( 'You don\'t have any project template yet, please %1$screate one%2$s and come back to use this feature.', 'leco-cp' ), '<a href="' . admin_url( 'post-new.php?post_type=leco_template' ) . '" target="_blank">', '</a>' );
		}

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Create New Project', 'leco-cp' ),
				'desc'    => $desc,
				'id'      => 'default_project_template',
				'type'    => 'select',
				'options' => $options,
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Attach a Project', 'leco-cp' ),
				/* translators: 1. Open code tag; 2. Close code tag. */
				'desc'    => sprintf( esc_html__( 'You can attach a default project to the newly registered client. When a new client registered from the %1$s[client_portal_register]%2$s shortcode or the Client Portal Register Form block, the project will attach to them.', 'leco-cp' ), '<code>', '</code>' ),
				'id'      => 'default_project',
				'type'    => 'select',
				'options' => array_replace( array( '0' => esc_html__( 'Don\'t attach any project', 'leco-cp' ) ), Project::get_all() ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'New Project Title', 'leco-cp' ),
				'desc'    => esc_html__( 'The title of the new project.', 'leco-cp' ),
				'id'      => 'default_project_title',
				'type'    => 'text',
				'default' => esc_html__( 'New Project', 'leco-cp' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Enable Brand Colors', 'leco-cp' ),
				'desc'    => esc_html__( 'The form elements in shortcodes and blocks should come with the branding colors in the General Settings.', 'leco-cp' ),
				'id'      => 'enable_branding',
				'type'    => 'select',
				'options' => array(
					'yes' => esc_html__( 'Yes', 'leco-cp' ),
					'no'  => esc_html__( 'No', 'leco-cp' ),
				),
				'default' => leco_cp_get_option( 'enable_branding', 'yes', 'register-login' ),
			)
		);

		add_action( "cmb2_save_options-page_fields_{$this->metabox_id}_misc", array( $this, 'settings_notices' ), 10, 2 );
		$cmb = new_cmb2_box(
			array(
				'id'          => $this->metabox_id . '_misc',
				'hookup'      => false,
				'cmb_styles'  => false,
				'parent_slug' => $this->key,
				'tab_group'   => $this->key,
				'tab_title'   => esc_html__( 'Misc', 'leco-cp' ),
				'show_on'     => array(
					'key'   => 'options-page',
					'value' => array( $this->key . '_misc' ),
				),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Display CP Projects column on Content Pages', 'leco-cp' ),
				'desc'    => esc_html__( 'If your Content Pages are linked to many Projects and the admin list page loads very slow, change this option to "No" should help.', 'leco-cp' ),
				'id'      => 'cp_projects_column',
				'type'    => 'select',
				'options' => array(
					'show' => esc_html__( 'Yes', 'leco-cp' ),
					'hide' => esc_html__( 'No', 'leco-cp' ),
				),
				'default' => leco_cp_get_option( 'cp_projects_column', 'show', 'misc' ),
			)
		);

		$cmb->add_field(
			array(
				'name'    => esc_html__( 'Display the "Powered By" link', 'leco-cp' ),
				'desc'    => esc_html__( 'There will be a "Powered by Client Portal" link in the footer of your projects. The default is "Yes".', 'leco-cp' ),
				'id'      => 'powered_by',
				'type'    => 'select',
				'options' => array(
					'show' => esc_html__( 'Yes', 'leco-cp' ),
					'hide' => esc_html__( 'No', 'leco-cp' ),
				),
				'default' => leco_cp_get_option( 'powered_by', 'show' ),
			)
		);
	}

	/**
	 * Register settings notices for display
	 *
	 * @since  unknown
	 * @since  4.15 Update the notification digest cron job when saving their settings.
	 *
	 * @param int   $object_id Option key.
	 * @param array $updated   Array of updated fields.
	 *
	 * @return void
	 */
	public function settings_notices( $object_id, $updated ) {

		if ( strpos( $object_id, $this->key ) === false || empty( $updated ) ) {
			return;
		}
		add_settings_error( $this->key . '-notices', $this->key, esc_html__( 'Settings updated.', 'leco-cp' ), 'updated' );
		settings_errors( $this->key . '-notices' );

		if ( 'leco_cp_options_notifications' === $object_id && ( isset( $_GET['section'] ) && $_GET['section'] === 'digest' ) ) { // phpcs:ignore.

			// Unschedule the digest cron job.
			as_unschedule_all_actions( 'leco_cp_notification_digest_cron', array(), 'leco-client-portal' );

			// Parsing the settings.
			$options = leco_cp_settings()->get_notification( 'digest' );
			$day     = $options[0]['schedule_on_day'];

			if ( $day === 'none' ) {
				return;
			}

			list( $hour, $min ) = explode( ':', $options[0]['schedule_on_time'] );

			$hour = (int) $hour;
			$min  = (int) $min;

			// Turn the hour into UTC value.
			$hour -= (int) get_option( 'gmt_offset' );

			if ( $hour > 24 ) {
				$hour = $hour - 24;

				switch ( $day ) {
					case '7':
						$day = '1';
						break;
					case '*':
						$day = '*';
						break;
					default:
						$day = (int) $day + 1;
				}
			}

			// Add/update the cron schedule.
			// Cron example: 0 2 * * *. Every day at 2:00 am.
			// Cron example: 0 2 * * 3. Wednesday at 2:00 am.

			$schedule = implode( ' ', array( $min, $hour, '*', '*', $day ) );

			as_schedule_cron_action( time() + 10, $schedule, 'leco_cp_notification_digest_cron', array(), 'leco-client-portal' );

		}

	}

	/**
	 * Display the notification sent notices.
	 *
	 * @since 4.9.7
	 *
	 * @param string $cmb_id    The CMB ID.
	 * @param string $object_id The object ID.
	 */
	public function notification_sent_notices( $cmb_id, $object_id ) {

		if ( $object_id === $this->key . '_notifications' ) {
			$result = get_transient( 'leco_cp_notification_sent' );

			if ( $result ) {
				$message = $result == 1 ? esc_html__( 'Test notification sent.', 'leco-cp' ) : $result;
				$type    = $result == 1 ? 'success' : 'error';

				add_settings_error( $this->key . '-notices', $this->key, $message, $type );
				settings_errors( $this->key . '-notices' );

				delete_transient( 'leco_cp_notification_sent' );
			}

		}

	}

	/**
	 * Catching errors from the activation method above and displaying it to the customer
	 *
	 * @since 3.0.0
	 */
	public function license_page_notices() {
		if ( isset( $_GET['sl_activation'] ) && ! empty( $_GET['message'] ) ) { // phpcs:ignore.
			switch ( $_GET['sl_activation'] ) { // phpcs:ignore.
				case 'false':
					$message = urldecode( $_GET['message'] ); // phpcs:ignore.
					?>
					<div class="error">
						<p><?php echo $message; ?></p>
					</div>
					<?php
					break;
				case 'true':
				default:
					// Developers can put a custom success message here for when activation is successful if they way.
					break;
			}
		}
	}

	/**
	 * Delete license status if the old key is not matched with the new one.
	 *
	 * @since unknown
	 *
	 * @param $new string New license key.
	 *
	 * @return string New license key
	 */
	public function sanitize_license_key( $new ) {
		$old = get_option( 'leco_cp_license_key' );
		if ( $old && $old != $new ) {
			delete_option( 'leco_cp_license_status' ); // new license has been entered, so must reactivate
		}

		return $new;
	}

	/**
	 * Activate license
	 */
	public function activate_license() {
		if ( ! isset( $_POST['option_page'] ) || 'leco_cp_license' != $_POST['option_page'] ) {
			return;
		}

		if ( empty( $_POST['leco_cp_license_key'] ) ) {
			return;
		}

		if ( 'valid' == get_option( 'leco_cp_license_status' ) || isset( $_POST['leco_cp_license_deactivate'] ) ) {
			return;
		}

		// retrieve the license from the database.
		$license      = sanitize_text_field( $_POST['leco_cp_license_key'] );
		$license_data = new stdClass();

		// data to send in our API request
		$api_params = array(
			'edd_action' => 'activate_license',
			'license'    => $license,
			'item_name'  => rawurlencode( LECO_CLIENT_PORTAL_ITEM_NAME ), // the name of our product in EDD.
			'url'        => home_url(),
		);

		// Call the custom API.
		$response = wp_remote_post(
			LECO_CLIENT_PORTAL_STORE_URL,
			array(
				'timeout'   => 15,
				'sslverify' => true,
				'body'      => $api_params,
			)
		);

		// make sure the response came back okay.
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again.', 'leco-cp' );
			}
		} else {
			$license_data = json_decode( wp_remote_retrieve_body( $response ) );
			if ( false === $license_data->success ) {
				switch ( $license_data->error ) {
					case 'expired':
						$message = sprintf(
							/* translators: Expiration date */
							__( 'Your license key expired on %s.', 'leco-cp' ),
							date_i18n( get_option( 'date_format' ), strtotime( $license_data->expires, current_time( 'timestamp' ) ) ) // phpcs:ignore.
						);
						break;
					case 'revoked':
						$message = __( 'Your license key has been disabled.', 'leco-cp' );
						break;
					case 'missing':
						$message = __( 'Invalid license.', 'leco-cp' );
						break;
					case 'invalid':
					case 'site_inactive':
						$message = __( 'Your license is not active for this URL.', 'leco-cp' );
						break;
					case 'item_name_mismatch':
						/* translators: Client Portal */
						$message = sprintf( __( 'This appears to be an invalid license key for %s.', 'leco-cp' ), LECO_CLIENT_PORTAL_ITEM_NAME );
						break;
					case 'no_activations_left':
						$message = __( 'Your license key has reached its activation limit.', 'leco-cp' );
						break;
					default:
						$message = __( 'An error occurred, please try again.', 'leco-cp' );
						break;
				}
			}
		}

		// Check if anything passed on a message constituting a failure.
		if ( ! empty( $message ) ) {
			$base_url = admin_url( 'edit.php?post_type=leco_client&page=' . $this->license_page_key );
			$redirect = add_query_arg(
				array(
					'sl_activation' => 'false',
					'message'       => rawurlencode( $message ),
				),
				$base_url
			);

			wp_safe_redirect( $redirect );
			exit();
		}

		// $license_data->license will be either "valid" or "invalid"
		update_option( 'leco_cp_license_status', $license_data->license );
	}

	/**
	 * Deactivate license.
	 *
	 * @since unknown
	 */
	public function deactivate_license() {
		// listen for our activate button to be clicked.
		if ( isset( $_POST['leco_cp_license_deactivate'] ) ) {
			// run a quick security check.
			if ( ! check_admin_referer( 'leco_cp_nonce', 'leco_cp_nonce' ) ) {
				return;
			} // get out if we didn't click the Activate button.
			// retrieve the license from the database.
			$license = trim( get_option( 'leco_cp_license_key' ) );

			// data to send in our API request.
			$api_params = array(
				'edd_action' => 'deactivate_license',
				'license'    => $license,
				'item_name'  => rawurlencode( LECO_CLIENT_PORTAL_ITEM_NAME ), // the name of our product in EDD
				'url'        => home_url(),
			);

			// Call the custom API.
			$response = wp_remote_post(
				LECO_CLIENT_PORTAL_STORE_URL,
				array(
					'timeout'   => 15,
					'sslverify' => true,
					'body'      => $api_params,
				)
			);

			// make sure the response came back okay.
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
				if ( is_wp_error( $response ) ) {
					$message = $response->get_error_message();
				} else {
					$message = __( 'An error occurred, please try again.' );
				}

				$base_url = admin_url( 'edit.php?post_type=leco_client&page=' . $this->license_page_key );
				$redirect = add_query_arg(
					array(
						'sl_activation' => 'false',
						'message'       => rawurlencode( $message ),
					),
					$base_url
				);

				wp_safe_redirect( $redirect );
				exit();
			}

			// decode the license data
			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			// $license_data->license will be either "deactivated" or "failed"
			if ( $license_data->license == 'deactivated' ) {
				delete_option( 'leco_cp_license_status' );
				delete_option( 'leco_cp_license_key' );
			}

			wp_safe_redirect( admin_url( 'edit.php?post_type=leco_client&page=' . $this->license_page_key ) );
			exit();
		}
	}

	/**
	 * Get the active tab.
	 *
	 * @since 4.9
	 *
	 * @param CMB2_Field $field A CMB2 field.
	 *
	 * @return false|int
	 */
	public function get_active_section( $field ) {
		$id = $field->prop( 'id' );

		if ( empty( $_GET['section'] ) ) { // phpcs:ignore.
			$pos = strpos( $id, 'general' );
		} else {
			$pos = strpos( $id, sanitize_text_field( $_GET['section'] ) ); // phpcs:ignore.
		}

		return is_int( $pos );
	}

	/**
	 * Public getter method for retrieving protected/private variables
	 *
	 * @since  0.1.0
	 *
	 * @param string $field Field to retrieve.
	 *
	 * @return string          Field value.
	 * @throws Exception          The exception.
	 */
	public function __get( $field ) {
		// Allowed fields to retrieve.
		if ( in_array( $field, array( 'key', 'metabox_id', 'title', 'options_page' ), true ) ) {
			return $this->{$field};
		}
		throw new Exception( 'Invalid property: ' . $field );
	}

	/**
	 * Get settings default values.
	 *
	 * @since 4.9
	 * @since 4.11 Added params $key and $field.
	 *
	 * @param string $tab   The settings tab.
	 * @param string $group The notification group.
	 * @param string $field The field.
	 *
	 * @return string[][][]|string
	 */
	public function get_defaults( $tab = '', $group = '', $field = '' ) {

		$defaults = array(
			'notifications' => array(
				'general' => array(
					'template'   => 'default',
					'logo'       => $this->get_option( 'logo' ),
					'name'       => get_bloginfo( 'name' ),
					'from'       => get_bloginfo( 'admin_email' ),
					'link_color' => leco_cp_get_option( 'secondary_color', '#ff5f5f' ),
				),
			),
		);

		foreach ( leco_client_portal()->notifications()->get_all() as $notification ) {
			$defaults['notifications'][ $notification->event() ] = $notification->settings()->defaults();
		}

		$defaults['notifications']['digest'] = LECO\Client_Portal\Notifications\Digest\Settings::defaults();

		$defaults['notifications']['reminder'] = LECO\Client_Portal\Notifications\Reminder\Settings::defaults();

		if ( ! $tab ) {
			return $defaults;
		}

		return $defaults[ $tab ][ $group ][ $field ];
	}

	/**
	 * Get option.
	 *
	 * @since 4.9
	 *
	 * @param string $field_id The field or group ID.
	 * @param string $default  The default value.
	 * @param string $tab      The tab name (the suffix of the metabox id).
	 *
	 * @return mixed
	 */
	public function get_option( $field_id = '', $default = '', $tab = '' ) {

		// Fix a weird issue that PHP fatal errors thrown for cmb2_get_option() is not defined.
		if ( ! function_exists( 'cmb2_get_option' ) ) {
			CMB2_Bootstrap_2100_Develop::initiate()->include_cmb();
		}

		$option_name = $this->key;

		if ( ! empty( $tab ) ) {
			$option_name .= "_$tab";
		}

		return cmb2_get_option( $option_name, $field_id, $default );
	}

	/**
	 * Get the notifications option.
	 *
	 * @since 4.9
	 *
	 * @param string       $group   The group ID (field ID of a group field).
	 * @param string|array $default The default value.
	 * @param string       $field   The sub field ID in a group field.
	 *
	 * @return mixed|null
	 */
	public function get_notification( $group, $default = null, $field = '' ) {
		$option_exists = get_option( 'leco_cp_options_notifications' );

		if ( ! isset( $option_exists[ $group ] ) && ! empty( $field ) ) {
			return $this->get_defaults( 'notifications', $group, $field );
		}

		$notifications = $this->get_option( $group, '', 'notifications' );

		if ( ! empty( $field ) ) {
			$value = isset( $notifications[0][ $field ] ) ? $notifications[0][ $field ] : '';
		} else {
			$value = $notifications;
		}

		if ( $group === 'digest' ) {
			$defaults = LECO\Client_Portal\Notifications\Digest\Settings::defaults();
			$default  = isset( $defaults[ $field ] ) ? $defaults[ $field ] : $default;
		}

		if ( $group === 'reminder' ) {
			$defaults = LECO\Client_Portal\Notifications\Reminder\Settings::defaults();
			$default  = isset( $defaults[ $field ] ) ? $defaults[ $field ] : $default;
		}

		if ( empty( $value ) ) {
			return ( ! empty( $default ) ) ? $default : $value;
		}

		return $value;
	}

	/**
	 * A custom field type to display action buttons.
	 *
	 * @since 4.9
	 *
	 * @param array $field_args The field arguments.
	 */
	public function render_row_cb_actions( $field_args ) {

		$test_action_url = wp_nonce_url(
			add_query_arg(
				array(
					'leco_cp_action' => str_replace( 'preview', 'test', $field_args['action'] ),
				)
			),
			'leco-cp-test-notification'
		);

		?>
		<div class="cmb-row leco-cp-actions">
			<div class="cmb-th"></div>
			<div class="cmb-td">
				<p><a href="<?php echo home_url( '?leco_cp_action=' . $field_args['action'] ); ?>"
							class="button-secondary" target="_blank"><?php esc_html_e( 'Preview Notification', 'leco-cp' ); ?></a> <a href="<?php echo $test_action_url; ?>"
							class="button-secondary"><?php esc_html_e( 'Send Test Notification', 'leco-cp' ); ?></a></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Get the content field description, including all the supported template tags.
	 *
	 * @since 4.11
	 *
	 * @return string
	 */
	public function get_email_content_description() {

		/* translators: 1. BR tag 2. Open code tag 3. Close code tag */
		$content_description = sprintf( esc_html__( 'The email content of this notification. Supported template tags:
		%1$s%2$s{sitename}%3$s - the name of the website.
		%1$s%2$s{siteurl}%3$s - the URL of the website.
		%1$s%2$s{login_url}%3$s - the login URL of the website.
		%1$s%2$s{set_password_url}%3$s - the URL for a new CP Client account to create their password.
		%1$s%2$s{project_admin_url}%3$s - the project admin URL in your WP Dashboard. It will be replaced with {project_url} when the notification is sent to clients.
		%1$s%2$s{project_url}%3$s - the project URL.
		%1$s%2$s{project}%3$s - the project title.
		%1$s%2$s{phase}%3$s - the phase title.
		%1$s%2$s{module}%3$s - the module title.
		%1$s%2$s{file_list}%3$s - the file list in the module.
		%1$s%2$s{username}%3$s - the CP Client account\'s username, required for logged in.
		%1$s%2$s{first_name}%3$s or %2$s{name}%3$s - the recipient\'s first name.
		%1$s%2$s{last_name}%3$s - the recipient\'s last name.', 'leco-cp' ), '<br />', '<code>', '</code>' );

		return $content_description;

	}

}

/**
 * Helper function to get/return the LECO_CP_Settings object
 *
 * @since  0.1.0
 * @return LECO_CP_Settings object
 */
function leco_cp_settings() {
	return LECO_CP_Settings::get_instance();
}
