<?php
/**
 * Render a Due Date field.
 *
 * @since   4.16
 *
 * @package LECO\Client_Portal
 */

namespace LECO\Client_Portal\CMB2\Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Due_Date
 *
 * @since 4.16
 */
class Due_Date {

	const DATE_FORMAT = 'Y-m-d';

	const TIME_FORMAT = 'H:i';

	/**
	 * Render the field markup.
	 *
	 * @since 4.16
	 *
	 * @param \CMB2_Field $field             The passed in `CMB2_Field` object.
	 * @param mixed       $escaped_value     The value of this field escaped.
	 * @param int         $object_id         The ID of the current object.
	 * @param string      $object_type       The type of object you are working with.
	 *                                       Most commonly, `post` (this applies to all post-types),
	 *                                       but could also be `comment`, `user` or `options-page`.
	 * @param object      $field_type_object This `CMB2_Types` object.
	 *
	 * @return void
	 */
	public static function render( $field, $escaped_value, $object_id, $object_type, $field_type_object ) {

		$escaped_value = wp_parse_args(
			$escaped_value,
			array(
				'enabled' => '',
				'date'    => '',
				'time'    => '',
			)
		);

		echo '<div class="leco-cp-due-date">';

		self::render_inputs( $field, $escaped_value, $field_type_object );

		echo '</div>';

		printf( esc_html__( 'Tick the checkbox to set the due date here. You can also choose when to send the reminder. The default is "1 Day before" and you can change it %1$shere%2$s.', 'leco-cp' ), '<a href="' . esc_url( admin_url( 'edit.php?post_type=leco_client&page=leco_cp_options&tab=notifications&section=reminder
' ) ) . '" target="_blank">', '</a>' );

	}

	/**
	 * Render the single entry markup.
	 *
	 * @since 4.16
	 *
	 * @param \CMB2_Field $field             The passed in `CMB2_Field` object.
	 * @param array       $value             The field value.
	 * @param object      $field_type_object This `CMB2_Types` object.
	 *
	 * @return void
	 */
	private static function render_inputs( $field, $value, $field_type_object ) {

		$id = $field->id() . '_enabled';
		$args = array(
			'type'  => 'checkbox',
			'id'    => $id,
			'name'  => $field->_name() . '[enabled]',
			'value' => 1,
		);
		if ( $value['enabled'] ) {
			$args['checked'] = 'checked';
		}
		$input = $field_type_object->input( $args );
		echo $input; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$timestamp = self::get_due_date_timestamp( $value );

		$id    = $field->id();
		$input = $field_type_object->text_datetime_timestamp(
			array(
				'id'    => $id,
				'name'  => $id,
				'value' => $timestamp,
			)
		);
		echo $input; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$id = $field->id() . '_reminder';
		printf( '<label for="%s">%s</label>', esc_attr( $id ), esc_html__( 'Reminder:', 'leco-cp' ) );
		$input = $field_type_object->select(
			array(
				'id'   => $id,
				'name' => $field->_name() . '[reminder]',
			)
		);

		// Select the reminder with their latest value.
		if ( isset( $value['reminder'] ) ) {
			$selected_value = $value['reminder'];
		} else {
			$selected_value = leco_cp_settings()->get_notification( 'reminder', '24', 'send_before_due_date' );
		}
		$input = preg_replace( '/(value="' . $selected_value . '")/', '$1 selected="selected"', $input );

		echo $input; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	}

	/**
	 * Sanitize the value.
	 *
	 * @todo Whitelist the reminder value.
	 *
	 * @since 4.16
	 *
	 * @param bool|mixed $override_value Sanitization/Validation override value to return.
	 *                                   Default: null. false to skip it.
	 * @param mixed      $value          The value to be saved to this field.
	 * @param int        $object_id      The ID of the object where the value will be saved.
	 * @param array      $field_args     The current field's arguments.
	 *
	 * @return mixed
	 */
	public static function sanitize_callback( $override_value, $value, $object_id, $field_args ) {

		$default_reminder = leco_cp_settings()->get_notification( 'reminder', '24', 'send_before_due_date' );

		return array(
			'enabled'  => isset( $value['enabled'] ) ? $value['enabled'] : '',
			'date'     => isset( $value['date'] ) ? sanitize_text_field( $value['date'] ) : '',
			'time'     => isset( $value['time'] ) ? sanitize_text_field( $value['time'] ) : '',
			'reminder' => isset( $value['reminder'] ) ? $value['reminder'] : $default_reminder,
		);

	}

	/**
	 * Return the unescaped array value when rendering the field.
	 *
	 * @since 4.16
	 *
	 * @param bool|mixed $override_value Escaping override value to return.
	 *                                   Default: null. false to skip it.
	 * @param mixed      $meta_value     The value to be output.
	 * @param array      $field_args     The current field's arguments.
	 * @param object     $field          This `CMB2_Field` object.
	 *
	 * @return mixed
	 */
	public static function escape_callback( $override_value, $meta_value, $field_args, $field ) {

		if ( ! empty( $meta_value ) ) {

			return $field->value();
		}

		return $meta_value;

	}

	/**
	 * Helper to wrap PHP built-in date_create_from_format().
	 *
	 * @since 4.16.0.1
	 *
	 * @param array              $value    The date to be converted.
	 * @param \DateTimeZone|null $timezone The timezone.
	 *
	 * @return \DateTime|false
	 */
	public static function date_create_from_format( $value, $timezone = null ) {

		if ( isset( $value['date_format'] ) ) {
			return date_create_from_format( $value['date_format'] . ' ' . $value['time_format'], $value['date'] . ' ' . $value['time'], $timezone );
		}

		return date_create_from_format( self::DATE_FORMAT . ' ' . self::TIME_FORMAT, $value['date'] . ' ' . $value['time'], $timezone );

	}

	/**
	 * Get the due date timestamp.
	 *
	 * @since 4.16.0.1
	 *
	 * @param array $value The due date value.
	 *
	 * @return int
	 */
	private static function get_due_date_timestamp( $value ) {

		$timestamp = 0;
		if ( $value['date'] && $value['time'] ) {
			// In the post edit screen, always assume the timezone is UTC+0.
			$date = self::date_create_from_format( $value );

			if ( $date ) {
				$timestamp = $date->getTimestamp();
			}
		}

		return $timestamp;

	}

}
