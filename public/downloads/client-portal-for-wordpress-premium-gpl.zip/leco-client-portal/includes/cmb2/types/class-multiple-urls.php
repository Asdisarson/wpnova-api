<?php
/**
 * Render a multiple URL field.
 *
 * @since   4.15.2
 *
 * @package LECO\Client_Portal
 */

namespace LECO\Client_Portal\CMB2\Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Multiple_Urls
 *
 * @since 4.15.2
 */
class Multiple_Urls {

	/**
	 * Render the field markup.
	 *
	 * @since 4.15.2
	 *
	 * @param \CMB2_Field $field             The passed in `CMB2_Field` object.
	 * @param mixed       $escaped_value     The value of this field escaped.
	 * @param int         $object_id         The ID of the current object.
	 * @param string      $object_type       The type of object you are working with.
	 *                                       Most commonly, `post` (this applies to all post-types),
	 *                                       but could also be `comment`, `user` or `options-page`.
	 * @param object      $field_type_object This `CMB2_Types` object.
	 *
	 * @return void
	 */
	public static function render( $field, $escaped_value, $object_id, $object_type, $field_type_object ) {

		$escaped_value = $escaped_value ? $escaped_value : array( array( 'url' => '', 'title' => '' ) );

		$index = 0;

		echo '<div class="leco-cp-multiple-urls">';

		foreach ( $escaped_value as $value ) {
			self::render_fieldset( $field, $index, $value, $field_type_object );
			$index++;
		}

		echo '</div>';

		printf( '<a class="leco-cp-add-url" href="#">%s</a>', esc_html__( 'Add Link', 'leco-cp' ) );

	}

	/**
	 * Render the single entry markup.
	 *
	 * @since 4.15.2
	 *
	 * @param \CMB2_Field $field             The passed in `CMB2_Field` object.
	 * @param int         $index             The field index.
	 * @param array       $value             The field value.
	 * @param object      $field_type_object This `CMB2_Types` object.
	 *
	 * @return void
	 */
	private static function render_fieldset( $field, $index, $value, $field_type_object ) {

		echo $index === 0 ? '<fieldset class="leco-cp-multiple-urls__template">' : '<fieldset class="leco-cp-multiple-urls__row">';

		printf( '<legend>%s</legend> <a href="%s" class="leco-cp-remove-url">%s</a>', esc_html__( 'Link', 'leco-cp' ), '#', esc_html__( 'Remove', 'leco-cp' ) );

		$id = $field->id() . "_{$index}_url";
		printf( '<label for="%s">%s*</label>', esc_attr( $id ), esc_html__( 'URL', 'leco-cp' ) );
		$input = $field_type_object->input(
			array(
				'type'  => 'url',
				'id'    => $id,
				'name'  => $field->_name() . "[$index][url]",
				'value' => $value['url'],
			)
		);
		echo $input; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$id = $field->id() . "_{$index}_title";
		printf( '<label for="%s">%s</label>', esc_attr( $id ), esc_html__( 'Title', 'leco-cp' ) );
		$input = $field_type_object->input(
			array(
				'type'  => 'text',
				'id'    => $id,
				'name'  => $field->_name() . "[$index][title]",
				'value' => $value['title'],
			)
		);
		echo $input; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		echo '</fieldset>';

	}

	/**
	 * Sanitize the value.
	 *
	 * @since 4.15.2
	 *
	 * @param bool|mixed $override_value Sanitization/Validation override value to return.
	 *                                   Default: null. false to skip it.
	 * @param mixed      $value      The value to be saved to this field.
	 *
	 * @return mixed
	 */
	public static function sanitize_callback( $override_value, $value ) {

		foreach ( $value as $key => $val ) {

			$url = esc_url_raw( $val['url'] );

			if ( empty( $url ) ) {
				unset( $value[ $key ] );

				continue;
			}

			$value[ $key ] = array(
				'url'   => $url,
				'title' => sanitize_text_field( $val['title'] ),
			);

		}

		return $value;

	}

	/**
	 * Return the unescaped array value when rendering the field.
	 *
	 * @since 4.15.2
	 *
	 * @param bool|mixed $override_value Escaping override value to return.
	 *                                   Default: null. false to skip it.
	 * @param mixed      $meta_value     The value to be output.
	 * @param array      $field_args     The current field's arguments.
	 * @param object     $field          This `CMB2_Field` object.
	 *
	 * @return mixed
	 */
	public static function escape_callback( $override_value, $meta_value, $field_args, $field ) {

		if ( ! empty( $meta_value ) ) {

			return $field->value();
		}

		return $meta_value;

	}

}
