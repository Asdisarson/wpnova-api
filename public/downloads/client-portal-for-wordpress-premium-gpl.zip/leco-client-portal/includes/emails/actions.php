<?php

/**
 * Displays the email preview.
 *
 * @since 4.9
 *
 * @return void
 */
function leco_cp_display_email_template_preview() {

	if ( empty( $_GET['leco_cp_action'] ) ) { // phpcs:ignore
		return;
	}

	list( $action, $group ) = explode( '-', sanitize_text_field( $_GET['leco_cp_action'] ) ); // phpcs:ignore

	$groups = leco_client_portal()->notifications()->get_events();
	$groups = array_merge( $groups, array( 'digest', 'reminder' ) );

	if ( ! in_array( $group, $groups, true ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	echo leco_client_portal()->emails->build_email( leco_cp_settings()->get_notification( $group, '', 'content' ) ); // phpcs:ignore.

	exit;

}

add_action( 'template_redirect', 'leco_cp_display_email_template_preview' );

/**
 * Send test notification hook function.
 *
 * @since 4.9
 *
 * @param array $data The GET data sent.
 */
function leco_cp_send_test_notification( $data ) {

	if ( ! wp_verify_nonce( $data['_wpnonce'], 'leco-cp-test-notification' ) ) {
		return;
	}

	$action = str_replace( 'test-', '', $data['leco_cp_action'] );

	// Send a test email.
	$subject     = leco_cp_settings()->get_notification( $action, '', 'subject' );
	$admin_email = apply_filters( 'leco_cp_admin_email_to', get_option( 'admin_email' ), null, '', '' );
	$content     = leco_cp_settings()->get_notification( $action, '', 'content' );

	$emails = leco_client_portal()->emails;
	$sent   = $emails->send( $admin_email, $subject, $content );

	// Set a transient to display the notices.
	$result = $sent ? true : esc_html__( 'The test email has not been sent. Please check your mail settings on the server and try again.', 'leco-cp' );
	set_transient( 'leco_cp_notification_sent', $result, MINUTE_IN_SECONDS );

	// Remove the test email query arg.
	wp_safe_redirect( remove_query_arg( 'leco_cp_action' ) );
	exit();

}
