<?php
/**
 * Emails
 *
 * Mostly borrowed from EDD.
 *
 * This class handles all emails sent through Client Portal.
 *
 * @since      4.9
 * @subpackage Classes/Emails
 * @copyright  Copyright (c) 2020, Laura Elizabeth
 * @license    http://opensource.org/licenses/gpl-4.9.php GNU Public License
 * @package    LECO_Client_Portal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use LECO\Client_Portal\Login;
use LECO\Client_Portal\Project;

/**
 * LECO_CP_Emails Class
 *
 * @since 4.9
 */
class LECO_CP_Emails {

	/**
	 * Holds the from address
	 *
	 * @since 4.9
	 */
	private $from_address;

	/**
	 * Holds the from name
	 *
	 * @since 4.9
	 */
	private $from_name;

	/**
	 * Holds the email content type
	 *
	 * @since 4.9
	 */
	private $content_type;

	/**
	 * Holds the email headers
	 *
	 * @since 4.9
	 */
	private $headers;

	/**
	 * Whether to send email in HTML
	 *
	 * @since 4.9
	 */
	private $html = true;

	/**
	 * The CP template to use.
	 *
	 * @since 4.9
	 */
	private $leco_cp_template;

	/**
	 * The email template to use
	 *
	 * @since 4.9
	 */
	private $template;

	/**
	 * The header text for the email
	 *
	 * @since  4.9
	 */
	private $heading = '';

	/**
	 * The email data.
	 *
	 * @since  4.9
	 */
	private $data;

	/**
	 * The user.
	 *
	 * @since  4.9
	 *
	 * @var WP_User
	 */
	private $user = null;

	/**
	 * Get things going
	 *
	 * @since 4.9
	 */
	public function __construct() {

		$this->leco_cp_template = apply_filters( 'leco_cp_get_template', leco_cp_get_option( 'template', 'tailwind' ) );

		if ( 'tailwind' !== $this->leco_cp_template || 'none' === $this->get_template() ) {
			$this->html = false;
		}

		add_action( 'leco_cp_email_send_before', array( $this, 'send_before' ) );
		add_action( 'leco_cp_email_send_after', array( $this, 'send_after' ) );

	}

	/**
	 * Set a property
	 *
	 * @since 4.9
	 *
	 * @param string $key   The property key.
	 * @param mixed  $value The property value.
	 */
	public function __set( $key, $value ) {
		$this->$key = $value;
	}

	/**
	 * Get a property.
	 *
	 * @since 4.9
	 *
	 * @param string $key The property key.
	 *
	 * @return mixed
	 */
	public function __get( $key ) {
		return $this->$key;
	}

	/**
	 * Get the email from name
	 *
	 * @since 4.9
	 */
	public function get_from_name() {
		if ( ! $this->from_name ) {
			$this->from_name = leco_cp_settings()->get_notification( 'general', get_bloginfo( 'name' ), 'name' );
		}

		return apply_filters( 'leco_cp_email_from_name', wp_specialchars_decode( $this->from_name ), $this );
	}

	/**
	 * Get the email from address
	 *
	 * @since 4.9
	 */
	public function get_from_address() {
		if ( ! $this->from_address ) {
			$this->from_address = leco_cp_settings()->get_notification( 'general', get_option( 'admin_email' ), 'from' );
		}

		if ( ! is_email( $this->from_address ) ) {
			$this->from_address = get_option( 'admin_email' );
		}

		return apply_filters( 'leco_cp_email_from_address', $this->from_address, $this );
	}

	/**
	 * Get the email content type
	 *
	 * @since 4.9
	 */
	public function get_content_type() {
		if ( ! $this->content_type && $this->html ) {
			$this->content_type = apply_filters( 'leco_cp_email_default_content_type', 'text/html', $this );
		} elseif ( ! $this->html ) {
			$this->content_type = 'text/plain';
		}

		return apply_filters( 'leco_cp_email_content_type', $this->content_type, $this );
	}

	/**
	 * Get the email headers
	 *
	 * @since 4.9
	 */
	public function get_headers() {
		if ( ! $this->headers ) {
			$this->headers  = "From: {$this->get_from_name()} <{$this->get_from_address()}>\r\n";
			$this->headers .= "Reply-To: {$this->get_from_address()}\r\n";
			$this->headers .= "Content-Type: {$this->get_content_type()}; charset=utf-8\r\n";
		}

		return apply_filters( 'leco_cp_email_headers', $this->headers, $this );
	}

	/**
	 * Get the enabled email template
	 *
	 * @since 4.9
	 *
	 * @return string|null
	 */
	public function get_template() {
		if ( ! $this->template ) {
			$this->template = leco_cp_settings()->get_notification( 'general', 'default', 'template' );
		}

		return apply_filters( 'leco_cp_email_template', $this->template );
	}

	/**
	 * Get the header text for the email
	 *
	 * @since 4.9
	 */
	public function get_heading() {
		return apply_filters( 'leco_cp_email_heading', $this->heading );
	}

	/**
	 * Get the default email data.
	 *
	 * @since 4.9
	 */
	public function get_default_data() {

		return array(
			'sitename'    => get_option( 'blogname' ),
			'siteurl'     => home_url(),
			'admin_email' => leco_cp_settings()->get_notification( 'general', '', 'from' ),
		);

	}

	/**
	 * Get the email data.
	 *
	 * @since 4.9
	 *
	 * @return array
	 */
	public function get_data() {

		if ( ! $this->data ) {
			$this->data = $this->get_default_data();
		} else {
			$this->data = wp_parse_args( $this->data, $this->get_default_data() );
		}

		return apply_filters( 'leco_cp_email_data', $this->data );

	}

	/**
	 * Get the user.
	 *
	 * @since 4.9
	 *
	 * @return WP_User|null
	 */
	public function get_user() {

		return apply_filters( 'leco_cp_email_user', $this->user );

	}

	/**
	 * Parse email template tags
	 *
	 * @since 4.9
	 *
	 * @param string $content The email content.
	 *
	 * @return string
	 */
	public function parse_tags( $content ) {

		$data = $this->get_data();
		$user = $this->get_user();

		$content = str_replace( '{sitename}', wp_specialchars_decode( $data['sitename'], ENT_QUOTES ), $content );

		if ( ! empty( $data['post_id'] ) ) {
			$project = get_post( $data['post_id'] );
			$content = str_replace( '{project}', $project->post_title, $content );
		}

		if ( isset( $data['phase'] ) ) { // $data['phase'] can be 0, so empty check would fail.
			$phase   = Project::get_phase_title( $data['post_id'], $data['phase'] );
			$content = str_replace( '{phase}', $phase, $content );
		}

		if ( ! empty( $data['modules'] ) ) {
			$content = str_replace( '{module}', $data['modules'][ $data['module'] ]['title'], $content );

			$module = $data['modules'][ $data['module'] ];
			$type   = ! empty( $module['type'] ) ? $module['type'] : 'url';
			$files  = array();

			if ( 'files' === $type ) {
				$files = $module['files'];
			} elseif ( 'private-files' === $type ) {
				foreach ( (array) $module['private_files'] as $ID => $file ) {
					$filearray    = explode( '/', $file );
					$files[ $ID ] = str_replace( end( $filearray ), '', $file );
				}
			} elseif ( 'client-uploads' === $type ) {
				if ( ! empty( $module['client_uploads'] ) ) {
					$files = $module['client_uploads'];
				}
			}

			if ( ! empty( $files ) ) {
				$files = $data['modules'][ $data['module'] ]['client_uploads'];

				$file_list = '<ul>';

				foreach ( $files as $ID => $file ) {
					$file_url = ( isset( $file['name'] ) ) ? trailingslashit( get_permalink( $data['post_id'] ) . 'file/' . $ID ) : $file;
					$file_name = ( isset( $file['name'] ) ) ? $file['name'] : get_the_title( $ID );

					$file_list .= '<li>';
					$file_list .= '<a href="' . $file_url . '">';
					$file_list .= $file_name;
					$file_list .= '</a>';
					$file_list .= '</li>';
				}

				$file_list .= '</ul>';

				$content = str_replace( '{file_list}', $file_list, $content );
			}
		}

		if ( ! empty( $data['project_admin_url'] ) ) {
			$content = str_replace( '{project_admin_url}', esc_url_raw( $data['project_admin_url'] ), $content );
		}

		if ( ! empty( $data['project_url'] ) ) {
			$content = str_replace( '{project_url}', esc_url_raw( $data['project_url'] ), $content );
		}

		if ( ! empty( $data['module_due_date'] ) ) {
			$content = str_replace( '{module_due_date}', $data['module_due_date'], $content );
		}

		// Replace user data.
		if ( $user instanceof WP_User ) {
			$content = str_replace( '{first_name}', $user->first_name, $content );
			$content = str_replace( '{last_name}', $user->last_name, $content );
			$content = str_replace( '{nickname}', $user->nickname, $content );
			$content = str_replace( '{name}', $user->first_name, $content );
			$content = str_replace( '{display_name}', $user->display_name, $content );
			$content = str_replace( '{username}', $user->user_login, $content );

			// Check if {set_password_url} is used so we don't generate the password reset key twice.
			if ( strpos( $content, '{set_password_url}' ) !== false ) {
				$content = str_replace( '{set_password_url}', Login::set_password_url( $user ), $content );
			}
		}

		$content = str_replace( '{siteurl}', esc_url_raw( $data['siteurl'] ), $content );
		$content = str_replace( '{login_url}', esc_url_raw( leco_cp_login_url() ), $content );

		return $this->parse_digest_tags( $content );

	}

	/**
	 * Parse the digest tags.
	 *
	 * @since 4.15
	 *
	 * @param string $content The digest content.
	 *
	 * @return string
	 */
	private function parse_digest_tags( $content ) {

		$data = $this->get_data();

		if ( isset( $data['latest_activity'] ) && ! empty( $data['latest_activity'] ) ) {

			$content = str_replace( '{latest_activity}', $data['latest_activity'], $content );

		}

		return $content;

	}

	/**
	 * Build the final email
	 *
	 * @since 4.9
	 *
	 * @param string $message The message.
	 *
	 * @return string
	 */
	public function build_email( $message ) {

		if ( false === $this->html ) {
			return apply_filters( 'leco_cp_email_message', wp_strip_all_tags( $message ), $this );
		}

		$message = $this->text_to_html( $message );

		ob_start();

		require LECO_CLIENT_PORTAL_DIR . "templates/{$this->leco_cp_template}/emails/header.php";

		/**
		 * Hooks into the email header
		 *
		 * @since 4.9
		 */
		do_action( 'leco_cp_email_header', $this );

		if ( has_action( 'leco_cp_email_template_' . $this->get_template() ) ) {
			/**
			 * Hooks into the template of the email
			 *
			 * @since 4.9
			 *
			 * @param string $this ->template Gets the enabled email template
			 */
			do_action( 'leco_cp_email_template_' . $this->get_template() );
		} else {
			require LECO_CLIENT_PORTAL_DIR . "templates/{$this->leco_cp_template}/emails/body.php";
		}

		/**
		 * Hooks into the body of the email
		 *
		 * @since 4.9
		 */
		do_action( 'leco_cp_email_body', $this );

		require LECO_CLIENT_PORTAL_DIR . "templates/{$this->leco_cp_template}/emails/footer.php";

		/**
		 * Hooks into the footer of the email
		 *
		 * @since 4.9
		 */
		do_action( 'leco_cp_email_footer', $this );

		$body    = ob_get_clean();
		$message = str_replace( '{email}', $message, $body );

		return apply_filters( 'leco_cp_email_message', $message, $this );
	}

	/**
	 * Send the email.
	 *
	 * @since 4.9
	 *
	 * @param string       $to          The To address to send to.
	 * @param string       $subject     The subject line of the email to send.
	 * @param string       $message     The body of the email to send.
	 * @param string|array $attachments Attachments to the email in a format supported by wp_mail().
	 *
	 * @return boolean
	 */
	public function send( $to, $subject, $message, $attachments = '' ) {

		/**
		 * Hooks before the email is sent
		 *
		 * @since 4.9
		 */
		do_action( 'leco_cp_email_send_before', $this );

		$subject = wp_specialchars_decode( $this->parse_tags( $subject ), ENT_QUOTES );
		$message = $this->parse_tags( $message );

		$message = $this->build_email( $message );

		$attachments = apply_filters( 'leco_cp_email_attachments', $attachments, $this );

		$sent       = wp_mail( $to, $subject, $message, $this->get_headers(), $attachments );
		$log_errors = apply_filters( 'leco_cp_log_email_errors', true, $to, $subject, $message );

		if ( ! $sent && true === $log_errors ) {
			if ( is_array( $to ) ) {
				$to = implode( ',', $to );
			}

			$log_message = sprintf(
				esc_html__( "Email from Client Portal failed to send.\nSend time: %1\$s\nTo: %2\$s\nSubject: %3\$s\n\n", 'leco-cp' ),
				date_i18n( 'F j Y H:i:s', current_time( 'timestamp' ) ),
				$to,
				$subject
			);

			error_log( $log_message );
		}

		/**
		 * Hooks after the email is sent
		 *
		 * @since 4.9
		 */
		do_action( 'leco_cp_email_send_after', $this );

		return $sent;

	}

	/**
	 * Add filters / actions before the email is sent
	 *
	 * @since 4.9
	 */
	public function send_before() {
		add_filter( 'wp_mail_from', array( $this, 'get_from_address' ) );
		add_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
		add_filter( 'wp_mail_content_type', array( $this, 'get_content_type' ) );
	}

	/**
	 * Remove filters / actions after the email is sent
	 *
	 * @since 4.9
	 */
	public function send_after() {
		remove_filter( 'wp_mail_from', array( $this, 'get_from_address' ) );
		remove_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
		remove_filter( 'wp_mail_content_type', array( $this, 'get_content_type' ) );

		// Reset heading to an empty string.
		$this->heading = '';
	}

	/**
	 * Converts text to formatted HTML. This is primarily for turning line breaks into <p> and <br/> tags.
	 *
	 * @since 4.9
	 *
	 * @param string $message The message text.
	 *
	 * @return string
	 */
	public function text_to_html( $message ) {

		if ( 'text/html' == $this->content_type || true === $this->html ) {
			$message = apply_filters( 'leco_cp_email_template_wpautop', true ) ? wpautop( $message ) : $message;
			$message = apply_filters( 'leco_cp_email_template_make_clickable', true ) ? make_clickable( $message ) : $message;
			$message = str_replace( '&#038;', '&amp;', $message );
		}

		return $message;
	}

	/**
	 * Send emails to the clients in a portal.
	 *
	 * @since 4.15
	 *
	 * @param int          $project_id  The project ID.
	 * @param string       $subject     The subject line of the email to send.
	 * @param string       $content     The body of the email to send.
	 * @param string|array $attachments Attachments to the email in a format supported by wp_mail().
	 *
	 * @return bool
	 */
	public function send_to_client( $project_id, $subject, $content, $attachments = '' ) {

		$client_id = get_post_meta( $project_id, 'leco_cp_client', true );
		$sent      = false;

		if ( ! $client_id ) {
			return true;
		}

		if ( leco_cp_is_public_portal( $project_id ) ) {
			return true;
		}

		$content = str_replace( '{project_admin_url}', '{project_url}', $content );

		if ( is_string( $client_id ) ) {
			$client_id = array( $client_id );
		}

		foreach ( $client_id as $user_id ) {
			$client = get_user_by( 'id', $user_id );
			if ( isset( $client->user_email ) ) {
				$this->__set( 'user', $client );

				$sent = $this->send( $client->user_email, $subject, $content, $attachments );
			}
		}

		return $sent;

	}

}
