( function ( $ ) {
	const $template = $( 'select#leco_cp_template' );

	if ( ! $template.length ) {
		return;
	}

	const $project = $( 'select#leco_cp_project' );
	const $projectTitle = $( 'input#leco_cp_project_title' );
	const $skipCreation = $( 'input#leco_cp_skip_if_purchased' );

	const toggleTemplateOptions = ( field ) => {
		field
			.parent()
			.toggleClass(
				'hidden',
				parseInt( $project.val(), 10 ) !== 0 ||
					parseInt( $template.val(), 10 ) === 0
			);
	};

	const toggleDropdown = ( field ) => {
		let $dropdown = $template;
		let $condition = $project;

		if ( field === 'project' ) {
			$dropdown = $project;
			$condition = $template;
		}

		$dropdown
			.parent()
			.toggleClass( 'hidden', parseInt( $condition.val(), 10 ) !== 0 );
	};

	toggleTemplateOptions( $projectTitle );
	toggleTemplateOptions( $skipCreation );
	toggleDropdown( 'template' );
	toggleDropdown( 'project' );

	$( document )
		.on( 'change', 'select#leco_cp_project', function () {
			toggleDropdown( 'template' );
			toggleTemplateOptions( $projectTitle );
			toggleTemplateOptions( $skipCreation );
		} )
		.on( 'change', 'select#leco_cp_template', function () {
			toggleDropdown( 'project' );
			toggleTemplateOptions( $projectTitle );
			toggleTemplateOptions( $skipCreation );
		} );
} )( jQuery );
