window.LecoCPSettings = null;

( function ( $ ) {
	var LecoCPSettings = function () {
		var self = this;

		this.init = function () {
			this.template = $( '#template' ).val();

			$( document ).on( 'cmb_init', function () {
				self.toggleCustomCSS( self.template );
				if ( $( '#leco_cp_user_project_template, #default_project_template' ).val() === '0' ) {
					$( '.cmb2-id-leco-cp-user-project-title, .cmb2-id-default-project-title' ).addClass( 'hidden' );
				} else {
					$( '.cmb2-id-default-project' ).addClass( 'hidden' );
				}

				if ( $( '#default_project' ).val() !== '0' ) {
					$( '.cmb2-id-default-project-title, .cmb2-id-default-project-template' ).addClass( 'hidden' );
				}
			} ).on( 'tinymce-editor-init', function () {
				if ( $( '#role' ).val() !== 'leco_client' ) {
					$( '#cmb2-metabox-leco_cp_user_new' ).parent().addClass( 'hidden' );
				}
			} ).on( 'change', '#template', function () {
				self.toggleCustomCSS( $( this ).val() );
			} ).on( 'change', '#role', function () {
				$( '#cmb2-metabox-leco_cp_user_new' ).parent().toggleClass( 'hidden', $( this ).val() !== 'leco_client' );
			} ).on( 'change', '#send_user_notification', function () {
				$( '.leco-cp-actions, .cmb2-id-leco-cp-user-email-subject, .cmb2-id-leco-cp-user-email-content' ).toggleClass( 'hidden', ! $( this ).prop( 'checked' ) );
			} ).on( 'change', '#leco_cp_user_project_template, #default_project_template', function () {
				$( '.cmb2-id-leco-cp-user-project-title, .cmb2-id-default-project-title' ).toggleClass( 'hidden', $( this ).val() === '0' );
				$( '.cmb2-id-leco-cp-user-project, .cmb2-id-default-project' ).toggleClass( 'hidden', $( this ).val() !== '0' );
			} ).on( 'change', '#leco_cp_user_project, #default_project', function () {
				$( '.cmb2-id-leco-cp-user-project-template, .cmb2-id-default-project-template' ).toggleClass( 'hidden', $( this ).val() !== '0' );
			} );

			this.dismissNotice();
		};

		this.toggleCustomCSS = function ( template ) {
			template = ( template === 'default' ) ? '' : '-' + template

			$( '.custom-css' ).hide();
			$( '.cmb2-id-css' + template ).show();
		};

		this.dismissNotice = function () {
			$( '.leco-cp-notice.is-dismissible' ).on( 'click', '.notice-dismiss', function () {
				var notice_el = $( this ).closest( '.leco-cp-notice' );

				var notice = notice_el.attr( 'id' );
				var notice_nonce = notice_el.attr( 'data-nonce' );
				$.post(
					ajaxurl,
					{
						action: 'leco_cp_dismiss_notice',
						nonce: notice_nonce,
						notice: notice
					}
				)
			} );
		};

		this.init();
	}

	$( document ).ready( LecoCPSettings );
} )( jQuery );
